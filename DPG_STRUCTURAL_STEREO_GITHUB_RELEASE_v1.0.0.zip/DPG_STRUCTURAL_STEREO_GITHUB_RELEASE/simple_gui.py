#!/usr/bin/env python3
"""Stereo boundary alignment GUI: seven workflows and one dataset export.

Source data, stereo/geometric solver, metadata and GT are separated:
GT is never passed to segmentation or stereo solvers, only measured post hoc.
"""
from __future__ import annotations
import json,queue,threading,traceback,subprocess,sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from release_info import __version__
from dataset_io import Dataset
from workflow_jobs import run_workflow,detect_gt,MODES
from result_browser import _PicturePane,ResultBrowser,image_for,export_frame,gt_summary,METHODS
from diagnostic_windows import Results,PairInspector,TransformInspector
from viewer3d import Viewer3D
from temporal_gui import TimelineInspector


class App:
    MODES=[
      ('dpg_one','1 - DPG / selected frame'),
      ('dpg_time','2 - DPG temporal / L-L and R-R'),
      ('compare_one','3 - DPG and disparity / selected frame'),
      ('disparity_range','4 - Disparity PNG / frame range'),
      ('all_one','5 - All 3 segmentations / selected frame'),
      ('all_range','6 - All 3 segmentations / frame range'),
      ('all_one_left_overlay','7 - All 3 / left-camera overlay PDFs'),
    ]
    def __init__(self):
        self.win=tk.Tk();self.win.title(f'Structural Stereo {__version__} - Boundary Alignment')
        self.win.geometry('1480x900');self.win.minsize(1020,620)
        self.dataset=tk.StringVar(value='')
        self.output_root=tk.StringVar(value=str(ROOT/'results'))
        self.single=tk.StringVar(value='290');self.start=tk.StringVar(value='200');self.end=tk.StringVar(value='600')
        self.solver=tk.StringVar(value='Experimental')
        self.disp=tk.StringVar(value='256');self.block=tk.StringVar(value='5')
        self.preview_view=tk.StringVar(value='Midpoint')
        self.preview_frame=tk.StringVar(value='')
        self.status=tk.StringVar(value='Select a stereo dataset and choose a workflow.')
        self.dataset_details=tk.StringVar(value='Camera calibration and GT are detected from the dataset.')
        self.active=False;self.events=queue.Queue();self.stop=threading.Event()
        self.job=None;self.manifest=None;self.current_record={};self.folders={};self.current_temporal=None
        self._windows=[];self._build()
        self.win.after(100,self._poll)
        self.win.protocol('WM_DELETE_WINDOW',self._on_close)
    def _build(self):
        self.win.columnconfigure(0,weight=0,minsize=350)
        self.win.columnconfigure(1,weight=1);self.win.rowconfigure(0,weight=1)
        side=ttk.Frame(self.win,width=390);side.grid(row=0,column=0,sticky='nsew')
        side.grid_propagate(False)
        scrolling=tk.Canvas(side,highlightthickness=0,width=390)
        scroll=ttk.Scrollbar(side,orient='vertical',command=scrolling.yview)
        scrolling.configure(yscrollcommand=scroll.set)
        scrolling.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        controls=ttk.Frame(scrolling,padding=9)
        anchor=scrolling.create_window((0,0),window=controls,anchor='nw')
        controls.bind('<Configure>',lambda e:scrolling.configure(scrollregion=scrolling.bbox('all')))
        scrolling.bind('<Configure>',lambda e:scrolling.itemconfigure(anchor,width=e.width))
        def wheel(e):
            if e.delta:scrolling.yview_scroll(int(-e.delta/120)*3,'units')
        scrolling.bind('<MouseWheel>',wheel)
        controls.bind('<MouseWheel>',wheel)
        row=0
        group=ttk.LabelFrame(controls,text='Dataset',padding=8);group.grid(row=row,column=0,sticky='ew',pady=4);row+=1
        group.columnconfigure(0,weight=1)
        ttk.Entry(group,textvariable=self.dataset).grid(row=0,column=0,columnspan=2,sticky='ew',pady=3)
        ttk.Button(group,text='Open ZIP',command=self.pick_zip).grid(row=1,column=0,sticky='ew',padx=(0,3),pady=2)
        ttk.Button(group,text='Open folder',command=self.pick_folder).grid(row=1,column=1,sticky='ew',padx=(3,0),pady=2)
        ttk.Label(group,textvariable=self.dataset_details,wraplength=335,justify='left').grid(row=2,column=0,columnspan=2,sticky='ew',pady=3)
        self.subset_button=ttk.Button(group,text='Export dataset subset (frame range)...',command=self.export_dataset_subset)
        self.subset_button.grid(row=3,column=0,columnspan=2,sticky='ew',pady=(6,2))
        group=ttk.LabelFrame(controls,text='Frames',padding=8);group.grid(row=row,column=0,sticky='ew',pady=4);row+=1
        ttk.Label(group,text='Selected frame').grid(row=0,column=0,sticky='w')
        ttk.Entry(group,textvariable=self.single,width=10).grid(row=0,column=1,sticky='w',padx=8)
        ttk.Separator(group,orient='horizontal').grid(row=1,column=0,columnspan=3,sticky='ew',pady=8)
        ttk.Label(group,text='Frame range').grid(row=2,column=0,sticky='w')
        ttk.Label(group,text='Start').grid(row=3,column=0,sticky='w')
        ttk.Entry(group,textvariable=self.start,width=9).grid(row=3,column=1,sticky='w')
        ttk.Label(group,text='End').grid(row=4,column=0,sticky='w')
        ttk.Entry(group,textvariable=self.end,width=9).grid(row=4,column=1,sticky='w')
        ttk.Label(group,text='Start and end frames are included.',wraplength=330).grid(row=5,column=0,columnspan=3,sticky='ew')
        group=ttk.LabelFrame(controls,text='Workflows',padding=8);group.grid(row=row,column=0,sticky='ew',pady=4);row+=1
        group.columnconfigure(0,weight=1)
        self.run_buttons=[]
        for k,(mode,label) in enumerate(self.MODES):
            b=ttk.Button(group,text=label,command=lambda m=mode:self.run(m))
            b.grid(row=k,column=0,sticky='ew',pady=3)
            self.run_buttons.append(b)
        self.stop_button=ttk.Button(group,text='Stop current job',command=self.stop_work, state='disabled')
        self.stop_button.grid(row=len(self.MODES),column=0,sticky='ew',pady=(9,2))
        group=ttk.LabelFrame(controls,text='Settings (automatic GT and calibration)',padding=8)
        group.grid(row=row,column=0,sticky='ew',pady=4);row+=1
        ttk.Label(group,text='Stereo solver').grid(row=0,column=0,sticky='w')
        ttk.Combobox(group,textvariable=self.solver,values=['Conservative','Experimental','Automatic'],state='readonly',width=17).grid(row=0,column=1,sticky='ew')
        ttk.Label(group,text='Disparity search').grid(row=1,column=0,sticky='w')
        ttk.Combobox(group,textvariable=self.disp,values=['64','128','192','256','384','512'],width=9,state='readonly').grid(row=1,column=1,sticky='w')
        ttk.Label(group,text='Disparity block').grid(row=2,column=0,sticky='w')
        ttk.Combobox(group,textvariable=self.block,values=['3','5','7','9'],width=9,state='readonly').grid(row=2,column=1,sticky='w')
        ttk.Label(group,text='Ground truth is used only for evaluation, never for solving.',wraplength=333,justify='left').grid(row=3,column=0,columnspan=2,sticky='w',pady=(6,0))
        group=ttk.LabelFrame(controls,text='Output directory',padding=8);group.grid(row=row,column=0,sticky='ew',pady=4);row+=1
        group.columnconfigure(0,weight=1)
        ttk.Entry(group,textvariable=self.output_root).grid(row=0,column=0,sticky='ew')
        ttk.Button(group,text='Change folder',command=self.pick_result_root).grid(row=0,column=1,padx=4)
        ttk.Button(group,text='Browse previous results / export PDFs',command=self.open_browser).grid(row=1,column=0,columnspan=2,sticky='ew',pady=(7,1))
        controls.columnconfigure(0,weight=1)
        right=ttk.Frame(self.win,padding=(5,8));right.grid(row=0,column=1,sticky='nsew')
        right.columnconfigure(0,weight=1);right.rowconfigure(2,weight=1)
        tools=ttk.Frame(right);tools.grid(row=0,column=0,sticky='ew')
        ttk.Label(tools,text='Results preview',font=('TkDefaultFont',11,'bold')).pack(side='left',padx=(2,15))
        ttk.Label(tools,text='Frame').pack(side='left')
        self.frame_combo=ttk.Combobox(tools,textvariable=self.preview_frame,width=9,state='readonly')
        self.frame_combo.pack(side='left',padx=3)
        self.frame_combo.bind('<<ComboboxSelected>>',lambda e:self.show_frame())
        ttk.Label(tools,text='View').pack(side='left',padx=(8,2))
        view=ttk.Combobox(tools,textvariable=self.preview_view,values=('Midpoint','Midpoint + boundaries','Left RGB + boundaries','Right RGB + boundaries','Left-camera overlay (B/G/R)','GT error map','Visibility'),state='readonly',width=28)
        view.pack(side='left');view.bind('<<ComboboxSelected>>',lambda e:self.show_frame())
        toolbar2=ttk.Frame(right);toolbar2.grid(row=1,column=0,sticky='ew',pady=4)
        ttk.Button(toolbar2,text='Element pairs',command=self.open_pairs).pack(side='left',padx=2)
        ttk.Button(toolbar2,text='Transform colors',command=self.open_transforms).pack(side='left',padx=2)
        ttk.Button(toolbar2,text='3D',command=self.open_3d).pack(side='left',padx=2)
        ttk.Button(toolbar2,text='Temporal tracking',command=self.open_temporal).pack(side='left',padx=2)
        ttk.Button(toolbar2,text='Export selected frame as PDFs',command=self.export_current).pack(side='right',padx=2)
        frame=ttk.Frame(right);frame.grid(row=2,column=0,sticky='nsew')
        self.preview_frame_holder=frame
        for i in range(4): frame.columnconfigure(i,weight=1,uniform='preview')
        for i in range(3): frame.rowconfigure(i,weight=1,uniform='preview_rows')
        self.panes={}
        for method in METHODS:
            p=_PicturePane(frame,method)
            self.panes[method]=p
        self._relayout_preview()
        footer=ttk.Frame(right);footer.grid(row=3,column=0,sticky='ew',pady=(5,0))
        self.progress=ttk.Progressbar(footer,mode='indeterminate')
        self.progress.pack(fill='x')
        ttk.Label(footer,textvariable=self.status,wraplength=900,justify='left').pack(fill='x',pady=2)
    def pick_zip(self):
        path=filedialog.askopenfilename(title='Select dataset ZIP',filetypes=[('ZIP','*.zip')])
        if path:self._set_dataset(path)
    def pick_folder(self):
        path=filedialog.askdirectory(title='Select stereo dataset folder')
        if path:self._set_dataset(path)
    def _set_dataset(self,path):
        self.dataset.set(path)
        try:
            ds=Dataset(path)
            frames=ds.frames
            self.single.set(str(frames[0]));self.start.set(str(frames[0]));self.end.set(str(frames[-1]))
            gt,reason=detect_gt(ds,frames[0]);c=ds.calibration
            cal='f={:.2f} px, B={:.5f} m'.format(c['focal_px'],c['baseline_m']) if 'focal_px' in c and 'baseline_m' in c else 'camera calibration: incomplete metadata'
            gt_line='GT: '+(gt['kind']+' / '+gt['side'] if gt else 'not verified: '+reason)
            rect='Rectification: '+('verified' if c.get('rectified') is True else 'unverified')
            self.dataset_details.set(f'{len(frames)} stereo pairs | {frames[0]}-{frames[-1]}\n{cal}\n{rect}\n{gt_line}')
            self.status.set(f'Dataset ladattu: {Path(path).name}, {len(frames)} stereoparia')
        except Exception as exc:
            self.dataset_details.set('Failed to read dataset: '+str(exc))
            messagebox.showerror('Open dataset',str(exc))
    def pick_result_root(self):
        p=filedialog.askdirectory(title='Select output directory')
        if p:self.output_root.set(p)
    def _set_busy(self,state):
        self.active=state
        for b in self.run_buttons:b.configure(state='disabled' if state else 'normal')
        self.subset_button.configure(state='disabled' if state else 'normal')
        self.stop_button.configure(state='normal' if state else 'disabled')
        if state:self.progress.start(15)
        else:self.progress.stop()
    def run(self,mode):
        if self.active:return
        p=Path(self.dataset.get().strip(' "'))
        if not p.exists():messagebox.showerror('Dataset missing','Select a dataset folder or ZIP.');return
        try:
            single=int(self.single.get());start=int(self.start.get());end=int(self.end.get())
            if start>end:raise ValueError('Start frame must be less than or equal to end frame.')
            disp=int(self.disp.get());block=int(self.block.get())
        except ValueError as exc:
            messagebox.showerror('Frame range',str(exc));return
        self.stop.clear();self._set_busy(True)
        labels=dict(self.MODES)
        self.status.set('Running: '+labels.get(mode,mode))
        cfg={'solver_mode':{'Conservative':'conservative','Experimental':'experimental','Automatic':'auto'}[self.solver.get()],
             'disp_search':disp,'disp_block':block}
        output_root=self.output_root.get()
        def worker():
            try:
                folder,manifest=run_workflow(mode,p,single,start,end,output_root,cancel=self.stop.is_set,
                    progress=lambda x:self.events.put(('progress',x)),**cfg)
                self.events.put(('done',(folder,manifest)))
            except Exception:self.events.put(('error',traceback.format_exc()))
        threading.Thread(target=worker,daemon=True).start()
    def export_dataset_subset(self):
        """Export the inclusive range without re-encoding original recordings."""
        if self.active:
            return
        dataset_path=Path(self.dataset.get().strip(' "'))
        if not dataset_path.exists():
            messagebox.showerror('Dataset missing','Select a dataset folder or ZIP.')
            return
        try:
            first,last=int(self.start.get()),int(self.end.get())
            if first>last:
                raise ValueError('Start frame must not exceed end frame')
        except ValueError as exc:
            messagebox.showerror('Frame range',str(exc))
            return
        from workflow_jobs import dataset_label
        initial=f'{dataset_label(dataset_path)}_frames_{first:06d}_{last:06d}.zip'
        dest=filedialog.asksaveasfilename(title='Save dataset subset ZIP',
            defaultextension='.zip',filetypes=[('ZIP archive','*.zip')],initialfile=initial)
        if not dest:
            return
        self.stop.clear()
        self._set_busy(True)
        self.status.set(f'Exporting original frame indexes {first}-{last} ...')
        def worker():
            try:
                from dataset_subset import export_subset
                report=export_subset(dataset_path,first,last,dest,
                    stop_requested=self.stop.is_set,
                    progress=lambda msg:self.events.put(('progress',msg)))
                self.events.put(('subset_done',report))
            except Exception:
                self.events.put(('error',traceback.format_exc()))
        threading.Thread(target=worker,daemon=True).start()

    def stop_work(self):
        self.stop.set();self.status.set('Stop requested. Already completed results will be retained.')
    def _poll(self):
        try:
            for i in range(100):
                kind,val=self.events.get_nowait()
                if kind=='progress':self.status.set(str(val))
                elif kind=='error':
                    self._set_busy(False);self.status.set('Job failed; see error details.')
                    messagebox.showerror('Processing error',val)
                elif kind=='subset_done':
                    self._set_busy(False)
                    self.status.set(f'Dataset subset: {val.selected_pairs} stereo pairs; '+
                                    f'{val.selected_depth_files} depth images. Saved to {val.output}')
                    if val.warnings:
                        messagebox.showwarning('Dataset subset warnings','\n'.join(val.warnings))
                elif kind=='done':
                    self._set_busy(False);folder,manifest=val
                    self.job=Path(folder);self.manifest=manifest
                    self.current_temporal=manifest.get('temporal_session')
                    frames=manifest.get('completed',[])
                    self.frame_combo.configure(values=[str(f) for f in frames])
                    if frames:self.preview_frame.set(str(frames[-1]));self.show_frame()
                    failed=len(manifest.get('failures',[]))
                    self.status.set(f'Job {manifest.get("state")}: {folder} | {len(frames)} frames | {failed} errors | PDF files: figures/')
        except queue.Empty:pass
        self.win.after(100,self._poll)
    def show_frame(self):
        if not self.manifest:return
        try:frame=int(self.preview_frame.get())
        except ValueError:return
        rec=self.manifest.get('outputs',{}).get(str(frame),{})
        self.current_record={k:Path(v) for k,v in rec.items() if k in METHODS}
        if not self.current_record and 'frame_folder' in rec:
            # Large frame-range jobs retain PDFs only to save disk space.
            folder=Path(rec['frame_folder'])
            if not folder.is_dir() and self.job is not None:
                folder=self.job/'frames'/f'frame_{frame:06d}'
            self.current_record={m:folder/f'{m}__midpoint.pdf'
                                 for m in ('dpg','felzenszwalb','slic')
                                 if (folder/f'{m}__midpoint.pdf').is_file()}
        self._relayout_preview()
        for method,pane in self.panes.items():
            path=self.current_record.get(method)
            try:
                image=image_for(method,path,self.preview_view.get()) if path is not None else None
                gt=gt_summary(method,path) if path is not None else ''
                pane.set_picture(image,gt)
            except Exception as exc:
                pane.set_picture(None,'Image loading error: '+str(exc))
    def _relayout_preview(self):
        available=[m for m in METHODS if m in self.current_record]
        for pane in self.panes.values():pane.grid_remove()
        if not available:
            self.panes['dpg'].grid(row=0,column=0,rowspan=2,columnspan=2,sticky='nsew',padx=2,pady=2)
            return
        if len(available)==1:
            self.panes[available[0]].grid(row=0,column=0,rowspan=2,columnspan=3,sticky='nsew',padx=2,pady=2)
        elif len(available)==2:
            for i,m in enumerate(available):
                self.panes[m].grid(row=0,column=i,columnspan=1,rowspan=2,sticky='nsew',padx=2,pady=2)
        elif len(available)==3:
            for i,m in enumerate(available):
                self.panes[m].grid(row=0,column=i,sticky='nsew',padx=2,pady=2)
        else:
            for i,m in enumerate(available):
                self.panes[m].grid(row=i//2,column=i%2,sticky='nsew',padx=2,pady=2)
    def _selected_dpg(self):
        for method in ('dpg','felzenszwalb','slic'):
            path=self.current_record.get(method)
            if path is not None and path.is_dir() and (path/'world.npz').is_file():return path
        return None
    def open_pairs(self):
        folder=self._selected_dpg()
        if folder is None:messagebox.showinfo('Element pairs','Select a completed frame first.');return
        try:self._windows.append(PairInspector(self.win,Results(folder)))
        except Exception:messagebox.showerror('Element pairs',traceback.format_exc())
    def open_transforms(self):
        folder=self._selected_dpg()
        if folder is None:messagebox.showinfo('Transform colors','Select a completed frame first.');return
        try:self._windows.append(TransformInspector(self.win,Results(folder)))
        except Exception:messagebox.showerror('Transform colors',traceback.format_exc())
    def open_3d(self):
        folder=self._selected_dpg()
        if folder is None:messagebox.showinfo('3D','Select a completed frame first.');return
        try:self._windows.append(Viewer3D(self.win,folder))
        except Exception:messagebox.showerror('3D',traceback.format_exc())
    def open_temporal(self):
        session=self.current_temporal
        if not session:
            session=filedialog.askdirectory(title='Open folder containing temporal SESSION.json')
            if not session:return
        try:self._windows.append(TimelineInspector(self.win,session))
        except Exception:messagebox.showerror('Temporal tracking',traceback.format_exc())
    def open_browser(self):
        try:self._windows.append(ResultBrowser(self.win,self.output_root.get()))
        except Exception:messagebox.showerror('Result browser',traceback.format_exc())
    def export_current(self):
        if not self.current_record:messagebox.showinfo('PDF','Select a completed frame first.');return
        try:
            fr=int(self.preview_frame.get())
            folder=self.job/'figures' if self.job else ROOT/'results'/'figures'
            paths=export_frame(self.current_record,self.manifest.get('dataset_name','dataset'),fr,folder,include_details=True)
            self.status.set(f'Exported {len(paths)} PDF files to {folder}')
        except Exception:messagebox.showerror('PDF',traceback.format_exc())
    def _on_close(self):
        if self.active and not messagebox.askyesno('Job running','A job is still running. Stop it and close the application?'):return
        self.stop.set();self.win.destroy()
    def main(self):self.win.mainloop()

if __name__=='__main__':App().main()
