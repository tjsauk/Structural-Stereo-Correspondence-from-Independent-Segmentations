Small 240x144 synthetic stereo images used by integration tests only.
No real research dataset, GT sequence or generated solver result is included.
