"""Regression: EuRoC frame index differs from native 19-digit image/GT timestamp."""
import csv
import io
import json
import sys
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dataset_io import Dataset
from workflow_jobs import detect_gt,run_workflow
from gt_element_eval import _read_field


def _fixture(tmp_path):
    root=tmp_path/'rig_test'
    stamp='1760000000123456789'
    for side in ('cam0','cam1'):
        path=root/'mav0'/side/'data'
        path.mkdir(parents=True,exist_ok=True)
        content=Image.open(ROOT/'tests'/'fixtures'/('left.png' if side=='cam0' else 'right.png'))
        content.save(path/(stamp+'.png'))
    depth=root/'mav0'/'depth0'/'data'
    depth.mkdir(parents=True,exist_ok=True)
    with Image.open(root/'mav0'/'cam0'/'data'/(stamp+'.png')) as im:
        w,h=im.size
    d=np.full((h,w),3000,np.uint16)
    d[0,0]=0
    Image.fromarray(d).save(depth/(stamp+'.png'))
    (root/'mav0'/'depth0'/'sensor.yaml').write_text('depth_scale: 1000\n')
    (root/'clip_manifest.json').write_text(json.dumps({'pair_source_ids':[
        {'pair_index':290,'left':f'mav0/cam0/data/{stamp}.png',
         'right':f'mav0/cam1/data/{stamp}.png'}]}))
    return root,stamp


def test_gt_identified_by_native_timestamp_folder_and_zip(tmp_path):
    folder,stamp=_fixture(tmp_path)
    zipped=tmp_path/'rig_test.zip'
    with zipfile.ZipFile(zipped,'w') as z:
        for p in folder.rglob('*'):
            if p.is_file():z.write(p,p.relative_to(folder))
    for source in (folder,zipped):
        ds=Dataset(source)
        assert ds.frames==[290]
        gt,reason=detect_gt(ds,290)
        assert reason is None
        assert gt['kind']=='depth_mm'
        assert gt['side']=='left'
        assert gt['file'].endswith(stamp+'.png')
        cached=ds._gt_latest_resolved
        data=_read_field(cached['raw'],cached['name'])
        assert data.dtype==np.uint16
        assert data[5,5]==3000


def test_frame_range_writes_numeric_gt_metrics(tmp_path):
    folder,_=_fixture(tmp_path)
    job,manifest=run_workflow('all_range',folder,290,290,290,tmp_path/'results',
                              solver_mode='conservative',evaluate_gt=True,
                              progress=lambda _:None)
    assert manifest['state']=='completed'
    assert all(x['available'] for x in manifest['gt'])
    with (job/'frame_summary.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    assert len(rows)==1
    row=rows[0]
    assert row['frame']=='290'
    for name in ('dpg','felzenszwalb','slic'):
        assert int(row[f'{name}_evaluated_pixels'])>0
        assert float(row[f'{name}_mae_px'])>=0
        assert row[f'{name}_gt_status']=='OK'
        assert row[f'{name}_pair_extrap_weighted_mae_px']
    pdfs=list((job/'frames'/'frame_000290').glob('*.pdf'))
    assert len(pdfs)==6
    from result_browser import scan_results,image_for,export_frame
    index=scan_results(job)
    assert len(index)==1
    item=index[next(iter(index))]
    for method in ('dpg','felzenszwalb','slic'):
        assert method in item
        assert item[method].suffix=='.pdf'
        assert image_for(method,item[method],'Midpoint').size==(240,144)
        assert image_for(method,item[method],'Midpoint + boundaries').size==(240,144)
    exported=export_frame(item,'test_bundle',290,tmp_path/'pdf_export',include_details=True)
    assert len(exported)==6
    assert all(f.name.isascii() for f in exported)
