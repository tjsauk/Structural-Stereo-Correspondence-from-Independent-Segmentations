from pathlib import Path
import sys
import numpy as np
import json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from workflow_jobs import run_workflow,detect_gt
from dataset_io import Dataset


def _demo_dataset(tmp_path):
    dataset=tmp_path/'stereo_data'
    from shutil import copy2
    for side,source in (('cam0','left.png'),('cam1','right.png')):
        p=dataset/'mav0'/side/'data'
        p.mkdir(parents=True,exist_ok=True)
        copy2(ROOT/'tests'/'fixtures'/source,p/'0.png')
    return dataset

def test_v8_all_one_three_methods_and_latex_pdfs(tmp_path):
    folder,report=run_workflow('all_one',_demo_dataset(tmp_path),0,0,0,tmp_path,
                               evaluate_gt=False,progress=lambda _:None)
    assert report['state']=='completed'
    assert set(k for k in report['outputs']['0'] if k in ('dpg','slic','felzenszwalb')) == {'dpg','slic','felzenszwalb'}
    pdfs=list(folder.glob('figures/**/*.pdf'))
    assert len(pdfs)>8
    assert (folder/'figures/PDF_INDEX.csv').exists()
    from PIL import Image
    for method in ('dpg','slic','felzenszwalb'):
        with Image.open(folder/'frame_000000'/method/'midpoint.png') as im:
            assert im.size==(240,144)

def test_v8_no_gt_does_not_fail(tmp_path):
    folder,report=run_workflow('dpg_one',_demo_dataset(tmp_path),0,0,0,tmp_path,
                               evaluate_gt=True,progress=lambda _:None)
    assert report['state']=='completed'
    assert report['gt'] and report['gt'][0]['available'] is False
    assert (folder/'frame_000000/dpg/GT_AUTO_STATUS.json').exists()

def test_v8_dataset_calibration_and_gt_inference(tmp_path):
    import shutil
    target=tmp_path/'ds'
    shutil.copytree(_demo_dataset(tmp_path),target)
    depth=target/'mav0/depth_cam1/data'
    depth.mkdir(parents=True)
    np.save(depth/'0.npy',np.full((144,240),2.1,np.float32))
    (target/'calibration.json').write_text(json.dumps({'focal_px':230.,'baseline_m':.12,
        'cx':120.,'cy':72.,'rectified':True}),encoding='utf-8')
    ds=Dataset(target)
    assert ds.calibration['focal_px']==230.
    found,reason=detect_gt(ds,0)
    assert not reason and found['side']=='right' and found['kind']=='depth_m'


def test_left_camera_rgb_overlay_pdfs_are_ascii_and_native_resolution(tmp_path):
    """All three methods export one left-camera-coordinate PDF per frame."""
    folder,manifest=run_workflow('all_one_left_overlay',_demo_dataset(tmp_path),0,0,0,
        tmp_path/'out',solver_mode='experimental',evaluate_gt=False,
        progress=lambda _:None)
    assert manifest['state']=='completed'
    pdfs=sorted(folder.glob('figures/**/*.pdf'))
    assert len(pdfs)==3
    assert all(p.name.isascii() and 'left_coordinate_boundaries' in p.stem for p in pdfs)
    import pypdfium2 as pdfium
    for p in pdfs:
        doc=pdfium.PdfDocument(str(p))
        assert len(doc)==1
        assert tuple(round(x) for x in doc[0].get_size())==(240,144)
        doc.close()
