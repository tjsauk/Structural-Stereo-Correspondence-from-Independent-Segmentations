"""Regression tests for original frame indexes and untouched sensor/depth data."""
import io
import json
import sys
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dataset_io import Dataset
from dataset_subset import export_subset
from gt_element_eval import discover_gt


def make_dataset(root:Path, frames:int=9) -> list[str]:
    """Build a EuRoC/ZED-like timestamp-indexed camera/depth/IMU test rig."""
    (root/'mav0/cam0/data').mkdir(parents=True)
    (root/'mav0/cam1/data').mkdir(parents=True)
    (root/'mav0/depth0/data').mkdir(parents=True)
    (root/'mav0/imu0').mkdir(parents=True)
    (root/'lio_odom').mkdir(parents=True)
    times=[str(1791365593052814610+i*66666666) for i in range(frames)]
    for k,stamp in enumerate(times):
        for cam in ('cam0','cam1'):
            img=np.full((6,9,3),k%256,np.uint8)
            Image.fromarray(img).save(root/f'mav0/{cam}/data/{stamp}.png')
        depth=np.full((6,9),1000+k,np.uint16)
        Image.fromarray(depth).save(root/f'mav0/depth0/data/{stamp}.png')
    for channel in ('cam0','cam1','depth0'):
        (root/f'mav0/{channel}/data.csv').write_text('#timestamp [ns],filename\n'+
             ''.join(f'{t},{t}.png\n' for t in times),encoding='utf8')
        (root/f'mav0/{channel}/sensor.yaml').write_text('sensor_type: camera\nresolution: [9, 6]\n',encoding='utf8')
    (root/'mav0/imu0/data.csv').write_text('#timestamp [ns],wx,wy,wz\n'+
       ''.join(f'{t},1,2,3\n' for t in times),encoding='utf8')
    (root/'lio_odom/zed_left_camera_frame_optical.txt').write_text('# TUM trajectory\n'+
       ''.join(f'{int(t)/1e9:.9f} 0 0 0 0 0 0 1\n' for t in times),encoding='utf8')
    (root/'export_report.json').write_text(json.dumps({'original_dataset':'test','notes':'keep unchanged'}))
    (root/'notes.txt').write_text('This is a static data collection note')
    (root/'mav0/imu0/sensor.yaml').write_text('sensor_type: imu\n')
    return times


def test_folder_subset_preserves_frame_indices_and_gt(tmp_path):
    source=tmp_path/'rig_20261007_124954'
    stamps=make_dataset(source,9)
    clip=tmp_path/'clip_000002_000005.zip'
    report=export_subset(source,2,5,clip)
    assert report.selected_pairs==4
    assert report.selected_depth_files==4
    with zipfile.ZipFile(clip) as z:
        files=set(z.namelist())
        assert f'mav0/cam0/data/{stamps[2]}.png' in files
        assert f'mav0/cam1/data/{stamps[5]}.png' in files
        assert f'mav0/depth0/data/{stamps[5]}.png' in files
        assert f'mav0/cam0/data/{stamps[0]}.png' not in files
        assert f'mav0/depth0/data/{stamps[0]}.png' not in files
        assert 'mav0/cam0/sensor.yaml' in files
        assert 'mav0/imu0/sensor.yaml' in files
        assert 'export_report.json' in files
        assert 'lio_odom/zed_left_camera_frame_optical.txt' in files
        assert 'notes.txt' in files
        assert len(z.read('mav0/imu0/data.csv').decode('utf8').splitlines())==7  # header + 4 selected + two IMU margin samples 
        assert z.read('mav0/cam0/data.csv').decode().count('.png') == 4
        assert z.read('mav0/depth0/data.csv').decode().count('.png') == 4
    clip_ds=Dataset(clip)
    assert clip_ds.frames==[2,3,4,5]
    assert Path(clip_ds.pairs[2][0]).stem==stamps[2]
    n,raw=discover_gt(clip,5,'left',dataset=clip_ds)
    assert Path(n).stem==stamps[5]
    assert np.asarray(Image.open(io.BytesIO(raw)))[0,0] == 1005
    original=source/f'mav0/depth0/data/{stamps[5]}.png'
    assert raw==original.read_bytes()


def test_nested_zip_source_keeps_root_prefix_and_original_indexes(tmp_path):
    source=tmp_path/'rig_20261007_124954'
    stamps=make_dataset(source,7)
    original=tmp_path/'original.zip'
    with zipfile.ZipFile(original,'w',compression=zipfile.ZIP_STORED) as z:
        for p in source.rglob('*'):
            if p.is_file():
                z.write(p,(source.name+'/'+p.relative_to(source).as_posix()))
    result=tmp_path/'subset.zip'
    export_subset(original,2,4,result)
    with zipfile.ZipFile(result) as z:
        assert f'{source.name}/clip_manifest.json' in z.namelist()
        assert f'{source.name}/mav0/depth0/data/{stamps[2]}.png' in z.namelist()
    ds=Dataset(result)
    assert ds.frames==[2,3,4]
    assert Path(discover_gt(result,4,'left',dataset=ds)[0]).stem==stamps[4]


def test_output_cannot_replace_source_or_existing_file(tmp_path):
    source=tmp_path/'rig'
    make_dataset(source,4)
    result=tmp_path/'subset.zip'
    result.write_bytes(b'Existing file')
    import pytest
    with pytest.raises(FileExistsError):
        export_subset(source,1,2,result)


def test_original_frame_range_200_to_600(tmp_path):
    """The intended 401-pair public dataset keeps frame IDs and timestamps."""
    source=tmp_path/'rig_full'
    stamps=make_dataset(source,601)
    target=tmp_path/'rig_200_600.zip'
    report=export_subset(source,200,600,target)
    ds=Dataset(target)
    assert len(ds.frames)==401
    assert ds.frames==list(range(200,601))
    assert report.selected_pairs==401
    assert report.selected_depth_files==401
    assert Path(ds.pairs[200][0]).stem==stamps[200]
    assert Path(ds.pairs[600][0]).stem==stamps[600]
    assert Path(discover_gt(target,200,'left',dataset=ds)[0]).stem==stamps[200]
    assert Path(discover_gt(target,600,'left',dataset=ds)[0]).stem==stamps[600]
    with zipfile.ZipFile(target) as archive:
        names=archive.namelist()
        assert len([n for n in names if n.startswith('mav0/cam0/data/')])==401
        assert len([n for n in names if n.startswith('mav0/cam1/data/')])==401
        assert len([n for n in names if n.startswith('mav0/depth0/data/')])==401
        assert 'mav0/cam0/data.csv' in names
        assert (archive.read('mav0/depth0/sensor.yaml') ==
                (source/'mav0/depth0/sensor.yaml').read_bytes())
