"""GT-only original-segment boundary reprojection validation."""
import sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from gt_boundary_eval import evaluate_boundary_projection,gt_pair_support


def _scene():
    h,w=50,90
    yy,xx=np.indices((h,w))
    labels={'L':np.where(xx<38,1,2).astype(np.int32),
            'VC':np.zeros((h,w),np.int32),'CC':np.zeros((h,w),np.int32)}
    ref=(xx+5).astype(np.float32)
    good=np.ones((h,w),bool)
    good[0:5]=False
    good[-5:]=False
    return labels,ref,good


def test_original_boundary_exact_reprojection_has_zero_error_and_full_f1():
    labels,reference,good=_scene()
    result=evaluate_boundary_projection(labels,reference,reference.copy(),good,np.ones_like(good))
    assert result['symmetric_boundary_mae_px']==0
    assert result['boundary_f1_1px_pct']==100
    assert result['GT_observable_boundary_pct']<100
    assert result['measured_boundary_pct']==result['GT_observable_boundary_pct']
    assert result['checked_boundary_pixels']>0


def test_boundary_error_and_coverage_different_from_missing_GT():
    labels,reference,good=_scene()
    prediction=reference+4
    pred_valid=np.ones_like(good)
    pred_valid[10:15,:]=False
    result=evaluate_boundary_projection(labels,reference,prediction,good,pred_valid)
    assert 3.9<result['symmetric_boundary_mae_px']<4.1
    assert 3.9<result['source_indexed_error']['mae_px']<4.1
    assert result['GT_observable_boundary_pct']>result['measured_boundary_pct']
    assert result['boundary_f1_3px_pct']<10


def test_duplicate_domain_seam_is_counted_once_for_coverage():
    labels,ref,good=_scene()
    both={k:v.copy() for k,v in labels.items()}
    both['VC']=labels['L'].copy()
    a=evaluate_boundary_projection(labels,ref,ref,good,np.ones_like(good))
    b=evaluate_boundary_projection(both,ref,ref,good,np.ones_like(good))
    assert b['total_source_boundary_pixels']==a['total_source_boundary_pixels']
    assert b['GT_observable_boundary_pct']==a['GT_observable_boundary_pct']


def test_accepted_matches_are_checked_only_where_gt_is_valid():
    labels,ref,good=_scene()
    matches={'right_xy':np.array([[37,10],[37,20],[37,3]],np.float32),
             'left_xy':np.array([[42,10],[48,20],[42,3]],np.float32),
             'confidence':np.array([.8,.8,.8],np.float32),
             'kind':np.zeros(3,np.uint8)}
    info=gt_pair_support(matches,ref,good)
    assert info['accepted_pair_samples']==3
    assert info['GT_checked_pair_samples']==2
    assert info['GT_consistent_pair_pct']==50.
