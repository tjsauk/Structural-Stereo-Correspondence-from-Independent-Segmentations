#!/usr/bin/env python3
"""Command-line entry point for exporting an indexed, timestamp-preserving clip."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from dataset_subset import export_subset


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset',required=True,help='Original rig folder or ZIP')
    parser.add_argument('--start',required=True,type=int,help='Original start frame index (inclusive)')
    parser.add_argument('--end',required=True,type=int,help='Original end frame index (inclusive)')
    parser.add_argument('--output',required=True,type=Path,help='New ZIP path')
    args=parser.parse_args()
    report=export_subset(args.dataset,args.start,args.end,args.output,progress=print)
    print(json.dumps(report.__dict__,indent=2))


if __name__=='__main__':
    main()
