#!/usr/bin/env python3
"""Run DPG stereo for a finite inclusive range, then match element shapes
LEFT(t)->LEFT(t+1) and RIGHT(t)->RIGHT(t+1) without GT or neural flow.

Results are stored frame-by-frame. Each temporal edge contains native DPG
IDs, confidence, support and continuous 2D affine coordinate transforms.
"""
from __future__ import annotations
import argparse,sys,json,time,subprocess,os,traceback
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from release_info import __version__
from dataset_io import Dataset
from temporal_links import match_camera_frames,save_links


def _write_session(folder, info):
    path=Path(folder)/'SESSION.json'
    path.write_text(json.dumps(info,indent=2,ensure_ascii=False),encoding='utf-8')


def run_sequence(dataset,start,end,folder,*,solver_mode='experimental',focal=None,baseline=None,
                 stop_requested=lambda:False,progress=print, use_precomputed=False):
    dataset=Path(dataset).resolve();folder=Path(folder).resolve()
    folder.mkdir(parents=True,exist_ok=True)
    ds=Dataset(dataset)
    sequence=[f for f in ds.frames if int(start)<=f<=int(end)]
    if not sequence:raise ValueError('No images in the requested frame range')
    info={'version':__version__,'dataset':str(dataset),'start':int(start),'end':int(end),
          'requested_frames':sequence,'completed_frames':[],'processed_links':[],
          'solver_mode':solver_mode,'GT_used':False,'trained_model':False,
          'tracking':'DPG element overlap + global 2D affine + per-element local correction',
          'temporal_camera_link_types':['left_to_left','right_to_right'],
          'state':'running','time_created':time.strftime('%Y-%m-%d %H:%M:%S')}
    _write_session(folder,info)
    for frame in sequence:
        if stop_requested():break
        result=folder/f'frame_{frame:06d}'
        complete=(result/'REPORT.json').is_file() and (result/'dpg_labels.npz').is_file()
        if not complete:
            result.mkdir(parents=True,exist_ok=True)
            cmd=[sys.executable,'-u',str(ROOT/'run_element_stereo.py'),
                 '--dataset',str(dataset),'--frame',str(frame),'--output',str(result),
                 '--solver-mode',solver_mode]
            if focal is not None:cmd+=['--focal',str(focal)]
            if baseline is not None:cmd+=['--baseline',str(baseline)]
            progress(f'Frame {frame}: DPG segmentation and shared stereo 3D')
            with subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                   text=True,errors='replace',bufsize=1,
                                   env=dict(os.environ,PYTHONIOENCODING='utf-8')) as p:
                for line in p.stdout:
                    if line.strip():progress(f'[{frame}] {line.strip()}')
                    if stop_requested():
                        p.terminate();break
                code=p.wait()
                if code!=0 and not stop_requested():raise RuntimeError(f'Frame {frame} failed (exit={code})')
        if stop_requested():break
        info['completed_frames'].append(frame)
        _write_session(folder,info)
        if len(info['completed_frames'])<2:continue
        a=info['completed_frames'][-2];b=frame
        previous=folder/f'frame_{a:06d}'
        progress(f'Temporal DPG matching {a} -> {b}: left-to-left and right-to-right')
        with np.load(previous/'dpg_labels.npz',allow_pickle=False) as z:
            old={k:z[k].copy() for k in z.files}
        with np.load(result/'dpg_labels.npz',allow_pickle=False) as z:
            new={k:z[k].copy() for k in z.files}
        records=[];mats={}
        for si,side in enumerate(('left','right')):
            ia=np.asarray(Image.open(previous/(side+'.png')).convert('RGB'))
            ib=np.asarray(Image.open(result/(side+'.png')).convert('RGB'))
            matches,M,extra=match_camera_frames(ia,ib,old,new,side)
            records.extend([(*e,si) for e in matches]);mats[side]=M
            progress(f'{side}: {len(matches)} correspondence hypotheses; camera affine shift {M[:,2].round(2).tolist()} px')
        report=save_links(folder/'temporal'/f'links_{a:06d}_{b:06d}.npz',records,
                          mats['left'],mats['right'],{'start':a,'end':b})
        info['processed_links'].append(report)
        _write_session(folder,info)
    info['state']='stopped' if stop_requested() else 'completed'
    _write_session(folder,info)
    return info


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',required=True)
    p.add_argument('--start',required=True,type=int)
    p.add_argument('--end',required=True,type=int)
    p.add_argument('--output',required=True)
    p.add_argument('--solver-mode',choices=['conservative','experimental','auto'],default='experimental')
    p.add_argument('--focal',type=float)
    p.add_argument('--baseline',type=float)
    args=p.parse_args()
    run_sequence(args.dataset,args.start,args.end,args.output,solver_mode=args.solver_mode,
                 focal=args.focal,baseline=args.baseline)
if __name__=='__main__':main()
