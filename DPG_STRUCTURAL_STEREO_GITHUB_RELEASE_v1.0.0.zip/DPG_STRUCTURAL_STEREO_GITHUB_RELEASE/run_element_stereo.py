#!/usr/bin/env python3
"""DPG element-boundary → joint planar 3D world → virtual midpoint.

This is an experimental, non-neural STRUCTURAL solver, not a dense pixel
stereo matcher. GT depth is NEVER read, used for fit, or used for selection.
"""
from __future__ import annotations
import argparse,json,os,sys,time,traceback,subprocess,shutil
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from release_info import __version__
from dataset_io import Dataset
from observations import extract
from segmentation_baselines import build_observations, METHODS as SEGMENTATION_METHODS
from boundary_matching import BoundaryMatches
from bidirectional_matching import match_both
from sheet_solver import solve as solve_world,Camera
from world_render import render_midpoint,render_surface_atlas,project_boundary_masks,opposite_visibility
from interior_correspondence import discover as find_interior
from direct_boundary_interior import discover_independent,combine as combine_matches
from visibility_joint import refine as refine_visibility
from world_confidence import classify as classify_confidence,project_provenance
from surface_identity import assign_surfaces,build_surface_atlas
from visibility_joint import check_pair_visibility

# Source-vetted, ALREADY RECTIFIED 1280x720 reference values from the user-provided
# base script. For other datasets provide --focal and --baseline explicitly.
REF_FOCAL=536.255
REF_CX=622.712
REF_CY=341.639
REF_BASELINE=.119741


def camera_parameters(shape,calibration=None, focal=None, baseline=None, cx=None, cy=None):
    """Use dataset calibration before the legacy 1280x720 reference.

    Existing images are assumed rectified. Only a declared rectified P1/P2
    calibration proves rectification; sensor.yaml alone does not.
    """
    h,w=shape
    is_ref=(h,w)==(720,1280)
    c=calibration or {}
    src_cam=(c.get('cameras') or [{}])[0]
    meta_fx=c.get('focal_px')
    if meta_fx is None:
        meta_fx=(src_cam.get('focal_px') or [None])[0]
    meta_b=c.get('baseline_m')
    meta_cx=c.get('cx')
    meta_cy=c.get('cy')
    if meta_cx is None:
        meta_cx=(src_cam.get('principal_px') or [None,None])[0]
    if meta_cy is None:
        meta_cy=(src_cam.get('principal_px') or [None,None])[1]
    # Explicit user override always wins. Otherwise use dataset measurements,
    # then legacy reference only as a clearly reported fallback.
    f=float(focal if focal is not None else
            (meta_fx if meta_fx is not None else (REF_FOCAL if is_ref else w*.8)))
    b=float(baseline if baseline is not None else
            (meta_b if meta_b is not None else (REF_BASELINE if is_ref else 1.0)))
    px=float(cx if cx is not None else
             (meta_cx if meta_cx is not None else (REF_CX if is_ref else (w-1)/2)))
    py=float(cy if cy is not None else
             (meta_cy if meta_cy is not None else (REF_CY if is_ref else (h-1)/2)))
    if f<=0 or b<=0:raise ValueError('Focal length and baseline must be positive')
    if meta_fx is not None or meta_b is not None:
        source=c.get('provenance','dataset_metadata')
    elif is_ref:
        source='legacy_rectified_1280x720_reference_fallback'
    else:
        source='UNVERIFIED_fallback_no_dataset_calibration'
    return Camera(f,px,py,b),{
        'rectification_assumed':True,
        'rectification_verified':bool(c.get('rectified') is True),
        'calibration_source':source,
        'dataset_calibration_source_file':c.get('source_file'),
        'dataset_calibration_used':bool(meta_fx is not None or meta_b is not None),
        'user_override_focal':focal is not None,
        'user_override_baseline':baseline is not None,
        'right_cx':c.get('right_cx'),
        'verify_parallel_epipolar_lines_before_metric_interpretation':not bool(c.get('rectified') is True),
        'calibration_warning':('Dataset calibration not verified as rectified; 2D disparity formula assumes rectified images.'
             if not bool(c.get('rectified') is True) else None)}


def _evaluate_saved_world(folder):
    """GT-blind original-view reprojection for a completely finished model."""
    from native_validation import evaluate
    from sheet_solver import SheetSolution
    with np.load(Path(folder)/'world.npz',allow_pickle=False) as z:
        camera=Camera(float(z['focal']),float(z['cx']),float(z['cy']),float(z['baseline']))
        world=SheetSolution(z['planes'].copy(),z['left_plane'].copy(),z['right_plane'].copy(),
           z['left_patch'].copy(),z['right_patch'].copy(),z['left_patch_plane'].copy(),
           z['right_patch_plane'].copy(),z['sample_plane'].copy(),camera,[],{})
    return evaluate(world)


def _solve_auto(dataset,frame,out,*,cached_labels=None,focal=None,baseline=None,cx=None,cy=None,
                progress=print,matcher_stride=3,max_match_samples=24000,segmentation_method='dpg'):
    """CPU-safe hypothesis selection: one independent subprocess per solve.

    The old in-process dual-solve can retain both full-sized native graphs,
    causing excessive memory pressure during result serialization on Windows.
    Competing hypotheses are generated entirely inside the original stereo
    solver, validated against both native camera observations, and only THEN
    their output is selected. No GT and no post-hoc geometry correction.
    """
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    base=out/'_hypotheses';base.mkdir(exist_ok=True)
    records={}
    samples=Path(cached_labels).resolve() if cached_labels else None
    for name in ('conservative','experimental'):
        target=base/name
        cmd=[sys.executable,'-u',str(ROOT/'run_element_stereo.py'),
             '--dataset',str(dataset),'--frame',str(int(frame)),
             '--output',str(target),'--solver-mode',name,
             '--sample-stride',str(int(matcher_stride)),
             '--max-match-samples',str(int(max_match_samples)),
             '--segmentation-method', str(segmentation_method)]
        if samples is not None:cmd+=['--cached-labels',str(samples)]
        for flag,val in (('--focal',focal),('--baseline',baseline),('--cx',cx),('--cy',cy)):
            if val is not None:cmd.extend((flag,str(float(val))))
        progress('V4 AUTO: erillinen '+name+'-ratkaisuprosessi alkaa')
        env=dict(os.environ,PYTHONIOENCODING='utf-8')
        try:
            proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                  encoding='utf-8',errors='replace',env=env)
            assert proc.stdout is not None
            for line in proc.stdout:
                if line.strip():progress(name+': '+line.rstrip())
            rc=proc.wait()
            if rc!=0:raise RuntimeError('Solver exited with code '+str(rc))
            with open(target/'REPORT.json',encoding='utf8') as f:
                report=json.load(f)
            stats,tiles=_evaluate_saved_world(target)
            records[name]={'report':report,'stats':stats,'tiles':tiles,'path':target}
            if name=='conservative' and samples is None:
                samples=target/'dpg_labels.npz'
        except Exception as exc:
            if name=='conservative':raise
            progress('AUTO: experimental hypothesis failed: '+str(exc))
            records[name]={'error':str(exc)}
    from native_validation import accept_candidate
    accepted=False;reasons=['experimental_failed']
    if 'report' in records['experimental']:
        stable=records['conservative'];trial=records['experimental']
        accepted,reasons=accept_candidate(stable['stats'],trial['stats'],stable['tiles'],trial['tiles'])
        # Native observation preservation is not the only property: do not
        # trade away a large fraction of supported 3D boundary evidence.
        if trial['report']['jointly_supported_boundary_samples']<.9*max(
                1,stable['report']['jointly_supported_boundary_samples']):
            accepted=False;reasons.append('joint_boundary_support_regression')
    choice='experimental' if accepted else 'conservative'
    progress('V4 AUTO: valittu '+choice+ ('; '+', '.join(reasons) if reasons and not accepted else ''))
    src=records[choice]['path']
    for f in src.iterdir():
        if f.is_file() and f.name!='REPORT.json':shutil.copy2(f,out/f.name)
    report=dict(records[choice]['report'])
    report['solver_requested_mode']='auto';report['solver_selected_mode']=choice
    report['solver_hypothesis_validation']={
        k:({'native_reprojection':r['stats'],
            'jointly_supported_boundary_samples':r['report']['jointly_supported_boundary_samples']}
            if 'report' in r else {'error':r['error']}) for k,r in records.items()}
    report['solver_hypothesis_validation']['auto_decision']={
        'experimental_accepted':bool(accepted),'reasons':reasons,
        'original_camera_reprojection_gt_blind':True,
        'separate_processes_to_limit_peak_cpu_memory':True}
    (out/'REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    shutil.rmtree(base)
    return report


def solve(dataset,frame,out,*,cached_labels=None,focal=None,baseline=None,cx=None,cy=None,
          progress=print,matcher_stride=3,max_match_samples=24000,solver_mode="experimental", segmentation_method='dpg'):
    if solver_mode=='auto':
        return _solve_auto(dataset,frame,out,cached_labels=cached_labels,focal=focal,
            baseline=baseline,cx=cx,cy=cy,progress=progress,
            matcher_stride=matcher_stride,max_match_samples=max_match_samples,
            segmentation_method=segmentation_method)
    t0=time.monotonic()
    def say(s):progress(f'[{time.monotonic()-t0:.1f}s] {s}')
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    ds=Dataset(dataset)
    if int(frame) not in ds.frames:raise ValueError(f'Frame {frame} puuttuu, dataset: {ds.frames[:20]}')
    say('Loading stereo pair (without GT)')
    left,right=ds.load(int(frame))
    if left.shape!=right.shape:raise ValueError('Vasemman ja oikean kuvan koot poikkeavat')
    shape=left.shape[:2]
    camera,cal_info=camera_parameters(shape,ds.calibration,focal,baseline,cx,cy)
    Image.fromarray(left).save(out/'left.png')
    Image.fromarray(right).save(out/'right.png')
    if cached_labels is None:
        if segmentation_method=='dpg':
            say('DPG elements at native resolution')
        else:
            say('Segmentation at native resolution: '+str(SEGMENTATION_METHODS.get(segmentation_method, segmentation_method)))
        obs=build_observations((left,right), segmentation_method, progress=say)
    else:
        say('Using previously computed original segment labels')
        with np.load(cached_labels,allow_pickle=False) as cache:
            obs={k:cache[k].copy() for k in cache.files}
        for s in ('left','right'):
            for d in ('L','VC','CC'):
                if obs[f'{s}_{d}'].shape!=shape:raise ValueError('Segment label resolution mismatch')
    stage_times={'segmentation_and_input_seconds':round(time.monotonic()-t0,4)}
    np.savez_compressed(out/'dpg_labels.npz',**obs)
    from native_validation import evaluate as validate_native,accept_candidate
    if solver_mode not in ('auto','conservative','experimental'):
        raise ValueError('solver_mode: auto / conservative / experimental')
    # All three are evaluated at the ORIGINAL stereo-solver stage, before
    # making physical 3D samples, RGB atlas or midpoint; no post-hoc warp.
    # AUTO retains the V3.1 geometry path as a regression guard if a new
    # structural hypothesis contradicts native camera observations.
    variants=('conservative','experimental') if solver_mode=='auto' else (solver_mode,)
    proposals=[];selection={}
    tick=time.monotonic()
    extra=discover_independent((left,right),obs,progress=say)
    stage_times['independent_boundary_interior_seconds']=round(time.monotonic()-tick,4)
    extra.save(out/'boundary_interior_independent.npz')
    stage_times['stereo_boundary_matching_seconds']=0.
    stage_times['joint_geometry_seconds']=0.
    for variant in variants:
        say('Elementtien stereoehdokkaat: '+variant)
        match_tick=time.monotonic()
        matched=match_both((left,right),obs,progress=say,
            sample_stride=int(matcher_stride),max_matches=int(max_match_samples),
            matcher_mode=variant)
        stage_times['stereo_boundary_matching_seconds']+=time.monotonic()-match_tick
        if len(matched.left_xy)<8:
            if variant=='experimental' and proposals:
                selection[variant]={'error':'too_few_boundary_matches'};continue
            raise RuntimeError('Insufficient stereo boundary evidence')
        allmatches=combine_matches(matched,extra)
        say('Yhteisen 3D-rajaverkon optimointi: '+variant)
        try:
            geometry_tick=time.monotonic()
            if variant=='conservative':
                from legacy_v31.visibility_joint import refine as frozen_refine_v31
                geometry,vr,discarded=frozen_refine_v31(obs,allmatches,camera,say,max_rounds=1)
            else:
                geometry,vr,discarded=refine_visibility(obs,allmatches,camera,say,
                    max_rounds=1,geometry_mode=variant)
            say('Validating original camera observations: '+variant)
            stats,tiles=validate_native(geometry)
            say('Original camera validation complete: '+variant)
            stage_times['joint_geometry_seconds']+=time.monotonic()-geometry_tick
            selection[variant]={'native_reprojection':stats,
                'joint_boundary_samples':int((geometry.sample_plane>=0).sum()),
                'source_boundary_samples':len(allmatches.left_xy)}
            proposals.append((variant,matched,allmatches,geometry,vr,discarded,stats,tiles))
        except Exception as exc:
            if variant=='experimental' and proposals:
                selection[variant]={'error':str(exc)};say('Experimental solution rejected: '+str(exc))
            else:raise
    if not proposals:raise RuntimeError('No geometry hypothesis was solved')
    best=proposals[0]
    if solver_mode=='auto' and len(proposals)>1:
        incumbent=proposals[0];challenger=proposals[1]
        accepted,reasons=accept_candidate(incumbent[6],challenger[6],incumbent[7],challenger[7])
        selection['auto_decision']={'experimental_accepted':bool(accepted),
                                    'reason_if_rejected':reasons}
        if accepted:best=challenger
        else:say('Experimental hypothesis rejected: '+', '.join(reasons))
    variant,boundary_matches,matches,world,visibility_joint_report,match_rejections,_,_=best
    # Two full-resolution candidate geometry graphs can consume substantial
    # RAM on Windows CPU-only machines. Release the rejected graph BEFORE
    # building the atlas and continuous raster.
    del best, proposals
    if solver_mode=='auto' and len(variants)>1:
        del incumbent, challenger
    import gc
    gc.collect()
    say('Valittu 3D-ratkaisutila: '+variant)
    render_tick=time.monotonic()
    boundary_matches.save(out/'boundary_boundary_matches.npz')
    planes=world.world_planes
    matches.save(out/'boundary_matches.npz')
    np.savez_compressed(out/'match_visibility.npz',rejected=match_rejections.astype(np.uint8),
                        match_kind=matches.kind,confidence=matches.confidence)
    planes=world.world_planes
    # V4 correction belongs to the joint solver: independent boundary-to-
    # interior observations already enter `matches` BEFORE plane fitting.
    # Disable V3's second, post-solve RGB patch reassignment. Reassigning
    # sheets after global fitting can break the newly solved visibility order.
    bi_refinement=dict(strategy='integrated_before_joint_plane_fitting',
        v3_postsolve_patch_reassignment_disabled=True,
        independently_accepted_samples=int(len(extra.left_xy)),
        source_gt_unused=True)
    say('Assigning shared surface identities to geometrically validated observations')
    say('Pintaidentiteetti: kamerapalojen komponentit')
    identities,ident_report=assign_surfaces(world,matches)
    say('Surface identity complete; computing observation-based confidence')
    confidence,confidence_report=classify_confidence(obs,matches,world)
    say('Luottamuskartta valmis')
    np.savez_compressed(out/'world_confidence.npz',**confidence)
    say('Building one 3D surface atlas and deduplicating common camera observations')
    atlas,geom,atlas_report=build_surface_atlas((left,right),world,identities,confidence,say)
    # Leave the large atlas uncompressed on disk: on CPU-only machines,
    # compressing >1M irregular RGB/XYZ samples can dominate run time.
    np.savez(out/'surface_atlas.npz',**atlas)
    np.savez_compressed(out/'surface_identity.npz',**{
        f'{s}_surface_id':np.asarray(identities[s],np.int32) for s in ('left','right')})
    say('Rendering virtual midpoint using surface IDs, depth and native RGB')
    from projective_raster import render_continuous_midpoint
    rgb,visible,render_report,mid_conf=render_continuous_midpoint(
        (left,right),world,identities,confidence,say)
    Image.fromarray(rgb).save(out/'midpoint.png')
    np.save(out/'midpoint_visibility.npy',visible)
    plane_map={'left':world.left_plane,'right':world.right_plane}
    say('DPG-elementtirajojen projektio 3D-maailman kautta')
    overlays=project_boundary_masks(obs,planes,plane_map,camera,geom,matches,world.sample_plane,identities)
    np.savez_compressed(out/'midpoint_boundaries.npz',**overlays)
    say('Luotettavuus: stereo / saman elementin jatko / heikko hypoteesi')
    np.save(out/'midpoint_confidence.npy',mid_conf)
    say('Checking occluded regions and boundary-to-interior candidates')
    occlusion=opposite_visibility(plane_map,planes,camera)
    np.savez_compressed(out/'visibility_by_source.npz',**occlusion)
    interior,interior_stats=find_interior((left,right),obs,world)
    np.savez_compressed(out/'boundary_to_interior.npz',**interior)
    post_reject=check_pair_visibility(world,matches)[0]
    np.savez_compressed(out/'match_visibility.npz',rejected=post_reject.astype(np.uint8),
                        match_kind=matches.kind,confidence=matches.confidence)
    np.savez_compressed(out/'world.npz',planes=planes,
        left_plane=world.left_plane.astype(np.int32),right_plane=world.right_plane.astype(np.int32),
        left_patch=world.left_patch.astype(np.int32),right_patch=world.right_patch.astype(np.int32),
        left_patch_plane=world.left_patch_planes.astype(np.int32),
        right_patch_plane=world.right_patch_planes.astype(np.int32),
        sample_plane=world.sample_plane.astype(np.int32),
        focal=np.float32(camera.focal),cx=np.float32(camera.cx),cy=np.float32(camera.cy),
        baseline=np.float32(camera.baseline))
    # Report genuine discontinuities in the ALREADY SOLVED source plane maps.
    # They cannot be fixed by RGB resampling without inventing geometry.
    from surface_integrity import diagnose
    internal=diagnose(obs,plane_map)
    np.savez_compressed(out/'native_internal_plane_transitions.npz',
        left=internal.pop('left_mask'),right=internal.pop('right_mask'))
    say('Interior seam diagnostics: left '+str(internal['left']['internal_native_membership_plane_transitions'])+
        ', right '+str(internal['right']['internal_native_membership_plane_transitions']))
    stage_times['world_atlas_render_and_diagnostics_seconds']=round(time.monotonic()-render_tick,4)
    stage_times['stereo_boundary_matching_seconds']=round(stage_times['stereo_boundary_matching_seconds'],4)
    stage_times['joint_geometry_seconds']=round(stage_times['joint_geometry_seconds'],4)
    obs_count={f'{s}_{d}':int(np.unique(obs[f'{s}_{d}']).size)
               for s in ('left','right') for d in ('L','VC','CC')}
    report={'version':__version__,'frame':int(frame),'dataset':str(dataset),
        'shape':list(shape),'elapsed_seconds':round(time.monotonic()-t0,2),
        'stage_times_seconds':stage_times,
        'geometry':'validated DPG-element geometry with continuous native-texture plane-homography raster',
        'trained_model':False,'dense_pixel_disparity_optimization':False,'GT_used':False,
        'segmentation_method':segmentation_method, 'segmentation_method_label': SEGMENTATION_METHODS.get(segmentation_method, segmentation_method),
        'input_rectification_assumed':True,'camera':{'focal':camera.focal,'cx':camera.cx,'cy':camera.cy,'baseline':camera.baseline},
        'calibration_info':cal_info,'dpg_elements':obs_count,
        'solver_requested_mode':solver_mode,'solver_selected_mode':variant,
        'solver_hypothesis_validation':selection,
        'stereo_boundary_matches':int(len(matches.left_xy)),
        'jointly_supported_boundary_samples':int(np.count_nonzero(world.sample_plane>=0)),
        'number_of_world_planes':int(len(planes)),
        'world_solver':world.stats,'native_internal_plane_transitions':internal,
        'rendering':render_report,'world_confidence':confidence_report,
        'boundary_to_interior_model_checked':interior_stats,
        'boundary_to_interior_weak_patch_refinement':bi_refinement,
        'world_surface_identity':ident_report,'unique_surface_atlas':atlas_report,
        'independent_boundary_to_interior':extra.stats,
        'visibility_joint_refinement':visibility_joint_report,
        'boundary_to_interior_evidence_is_model_conditioned':False,
        'boundary_to_interior_post_check_is_model_conditioned':True,
        'notes':['Original two-camera observations are preserved but the 3D surface atlas contains no duplicate right samples of geometrically verified common sheets.',
                 'Unverified/background proxy image pixels are not claimed to be physically reconstructed.',
                 'Global optimality, correct object boundaries and complete visibility are not guaranteed.',
                 'Model-independent boundary-to-interior hypotheses are included in coupled plane optimization.',
                 'Visibility and shared world geometry are refined alternately (one pass); global optimum not guaranteed.',
                 'A physical surface atlas merges repeated stereo-observed sample geometry; LEFT, RIGHT and BOTH are the only 3D visibility classes.',
                 'V3 cannot guarantee correct surface identity without stereo evidence; unsupported geometry remains explicitly uncertain.']}
    (out/'REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=lambda v:v.tolist() if hasattr(v,'tolist') else str(v)),encoding='utf8')
    say('Valmis: '+str(out))
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',required=True,type=Path)
    p.add_argument('--frame',type=int,default=290)
    p.add_argument('--output',type=Path,default=ROOT/'results'/'frame_000290')
    p.add_argument('--cached-labels',type=Path,default=None)
    p.add_argument('--focal',type=float)
    p.add_argument('--baseline',type=float)
    p.add_argument('--cx',type=float)
    p.add_argument('--cy',type=float)
    p.add_argument('--sample-stride',type=int,default=3)
    p.add_argument('--max-match-samples',type=int,default=24000)
    p.add_argument('--solver-mode',choices=['auto','conservative','experimental'],default='experimental')
    p.add_argument('--segmentation-method',choices=list(SEGMENTATION_METHODS.keys()),default='dpg')
    a=p.parse_args()
    try:solve(a.dataset,a.frame,a.output,cached_labels=a.cached_labels,focal=a.focal,baseline=a.baseline,
          cx=a.cx,cy=a.cy,matcher_stride=a.sample_stride,max_match_samples=a.max_match_samples,solver_mode=a.solver_mode, segmentation_method=a.segmentation_method)
    except Exception:
        traceback.print_exc();raise SystemExit(1)
if __name__=='__main__':main()
