# Structural Stereo Boundary Alignment

Research code for matching and placing independently segmented stereo-image boundaries in a shared geometric coordinate system. The implementation uses one stereo-alignment pipeline with three input segmentation methods: **DPG**, **Felzenszwalb graph segmentation**, and **SLIC superpixels**. A virtual midpoint image can also be rendered for visual inspection.

Stereo correspondence and geometry estimation do **not** use ground-truth (GT) depth. When a matching depth image is present, GT is used **only after solving** to evaluate boundary and right-to-left placement accuracy.

## Installation

Python **3.11 or later** is recommended. On Windows:

1. Extract this repository and run `INSTALL_WINDOWS.bat` once.
2. Run `START_WINDOWS.bat`.
3. Select the original rig folder or ZIP, select a frame or an inclusive frame range, and start a workflow.

Alternatively:

```bash
python -m pip install -r requirements.txt
python simple_gui.py
```

The default stereo solver is **Experimental**. Conservative and Automatic modes remain selectable in the GUI.

## Processing workflows

| GUI workflow | Output |
| --- | --- |
| 1 - DPG / selected frame | DPG geometry, midpoint, diagnostics and PDFs |
| 2 - DPG temporal / L-L and R-R | Sequence results and cross-time element relations |
| 3 - DPG and disparity / selected frame | Illustrative midpoint comparison |
| 4 - Disparity PNG / frame range | PNG midpoint images |
| 5 - All 3 segmentations / selected frame | Detailed comparison and individual PDF images |
| 6 - All 3 segmentations / frame range | Space-saving six PDFs per frame plus one `frame_summary.csv` |
| 7 - All 3 / left-camera overlay PDFs | One PDF per method: left-camera RGB, left boundaries (blue), shared boundaries (green) and right boundaries projected into the **left** camera (red) |

In the compact frame-range workflow, each frame has a `frames/frame_XXXXXX` folder containing **two PDFs per method**: clean midpoint and midpoint with boundaries. The summary CSV reports segment count, GT reprojection errors, boundary symmetric MAE, boundary F1, GT-verifiable boundary percentage, and accepted-match consistency, among other metrics. The compact PDFs remain viewable in the result browser after large intermediate arrays have been removed.

Generated PDF *filenames* use ASCII letters, digits, underscores, dots and hyphens; source metadata and timestamped camera filenames remain unchanged. PDF pages preserve the native input-image pixel resolution.

## Export a dataset interval without renumbering its frames

Use **Export dataset subset (frame range)...** in the main GUI. The same inclusive **Start** and **End** fields control the export. For the 401-frame research interval, enter **200** and **600**, then choose a destination ZIP.

Or use the CLI:

```bash
python subset_dataset.py \
  --dataset "/path/to/rig_20261007_124954" \
  --start 200 --end 600 \
  --output "rig_20261007_124954_frames_200_600.zip"
```

On Windows PowerShell, enter that as one line (or use PowerShell continuation syntax instead of `\`). The source may be either a dataset directory or a ZIP.

**Preservation rules:**

- Select the left/right RGB images for original pair indexes 200–600, **inclusive**, without renaming or re-encoding them. Their original timestamp-based filenames are retained byte-for-byte.
- Include the corresponding `depth0` GT depth images (and `depth1`, if present), again preserving the original bytes. Exact camera-timestamp matches are preferred; the nearest depth image within 50 ms is used if necessary.
- Preserve camera, depth, IMU and other sensor `sensor.yaml` files, camera calibration, `export_report.json`, metadata, and general documentation.
- Update camera/depth `data.csv` indexes to reference only the selected camera/depth images. Time-indexed IMU and odometry logs are trimmed to the selected time span, with a 100 ms margin at either end.
- **Never silently discard unrecognized or clock-incompatible data.** Files that cannot be unambiguously filtered are copied intact; the generated manifest records this. Unsupported monolithic recordings (e.g. some binary bag files) are retained rather than rewritten.
- Generate `clip_manifest.json` with each original `pair_index`, `left` and `right` path. If the source already had a clip manifest, the original is preserved as `source_manifest_backup.json`.

The new ZIP is self-contained and can be reopened as a normal dataset by this repository. Frame IDs still read as **200...600** rather than being reset to **0...400**. Image and GT matching is based on original camera timestamps.

The exporter copies timestamped camera/depth data losslessly; it does not interpolate or infer new sensor measurements. If an original GT depth frame is missing, the report explicitly notes it. No large source datasets are bundled with this repository.

## Source layout

| Path | Responsibility |
| --- | --- |
| `simple_gui.py` | English-language desktop GUI and worker controls |
| `src/workflow_jobs.py` | Seven processing workflows and compact batch reporting |
| `subset_dataset.py`, `src/dataset_subset.py` | Standalone and GUI-accessible timestamp-preserving subset export |
| `src/dataset_io.py`, `src/dataset_metadata.py` | Dataset indexing, RGB input, metadata and camera calibration |
| `run_element_stereo.py` | Stereo boundary matching, geometric solve and rendering orchestration |
| `src/boundary_matching.py`, `src/bidirectional_matching.py`, `src/sheet_solver.py` | Correspondence and structural geometry |
| `src/segmentation_baselines.py`, `src/dpg_engine.py` | Independent segmentation methods |
| `src/gt_element_eval.py`, `src/gt_boundary_eval.py` | Post-hoc GT evaluation |
| `src/result_browser.py` | PDF export, overlays and result inspection |
| `run_sequence.py`, `src/temporal_links.py` | Temporal correspondences |
| `src/legacy_v31/` | Earlier conservative solver components still used by Conservative/Automatic modes |
| `tests/` | Automated GT, workflow, PDF and dataset export regressions |

The repository contains **only code, test fixtures and documentation**. It excludes research result caches, full datasets, previous Windows release packages and historical handoffs.

## Tests

```bash
python -m pip install pytest
python -m pytest -q tests
```

The test suite uses small procedural or bundled synthetic images. It includes a 601-frame source fixture from which exactly 401 original frames (200–600) are exported and verified, including GT timestamps. That is a software integration test, not a claim about results from the original research dataset.

## GT and interpretation

The expected ZED-like dataset organization is `mav0/cam0/data`, `mav0/cam1/data` and `mav0/depth0/data`. In this data convention, the left-camera GT depth is a single-channel 16-bit PNG containing millimetres; a zero depth is invalid. GT observability is evaluated independently of the stereo solver. Boundary error metrics are calculated only on source-boundary portions with a reliable GT projection and a valid estimated placement, and the verified boundary proportion is reported separately.

**Repository license:** No license is included in this distribution. The repository owner should select a license and attribution terms before a public GitHub release.
