@echo off
cd /d "%~dp0"
set "OPENBLAS_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
py -3 simple_gui.py
if errorlevel 1 pause
