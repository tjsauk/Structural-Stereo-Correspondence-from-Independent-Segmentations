"""STRICTLY POST-HOC DPG geometric evaluation against depth/disparity GT.

The DPG optimizer is NEVER passed this data. GT samples are used only after
loading a completed world.npz and dpg_labels.npz. Evaluates whole right element
pixels' continuous right->left plane projection versus GT-derived projection.
"""
from __future__ import annotations
import csv,io,json,re,zipfile
from pathlib import Path
import numpy as np
import cv2
from PIL import Image
from world_render import source_geometry
from gt_boundary_eval import evaluate_boundary_projection, gt_pair_support

EXTS={'.png','.tif','.tiff','.exr','.npy','.npz','.pfm'}


def _load_pfm(content):
    import struct
    f=io.BytesIO(content)
    header=f.readline().decode('ascii').strip()
    if header not in ('Pf','PF'):raise ValueError('PFM: invalid signature')
    line=f.readline().decode('ascii').strip()
    while line.startswith('#'):line=f.readline().decode('ascii').strip()
    w,h=map(int,line.split())
    scale=float(f.readline().decode('ascii'))
    arr=np.frombuffer(f.read(),dtype=('<f4' if scale<0 else '>f4'))
    arr=arr.reshape(h,w,3 if header=='PF' else 1)[::-1]
    return arr[...,0] if header=='PF' else arr[...,0]


def _read_field(content,name):
    suffix=Path(name).suffix.lower()
    if suffix=='.pfm':return _load_pfm(content)
    if suffix=='.npy':return np.load(io.BytesIO(content),allow_pickle=False)
    if suffix=='.npz':
        with np.load(io.BytesIO(content),allow_pickle=False) as f:
            preferred=['depth','depth_m','gt_depth','disparity','disp','gt','arr_0']
            key=next((k for k in preferred if k in f and f[k].ndim==2),None)
            if key is None:key=next((k for k in f if f[k].ndim==2),None)
            if key is None:raise ValueError('NPZ contains no 2D GT depth/disparity array')
            return f[key].copy()
    if suffix=='.exr':
        import os
        os.environ.setdefault('OPENCV_IO_ENABLE_OPENEXR','1')
        z=cv2.imdecode(np.frombuffer(content,np.uint8),cv2.IMREAD_UNCHANGED)
        if z is None:raise ValueError('EXR decoding failed')
        return z[...,0] if z.ndim==3 else z
    a=np.asarray(Image.open(io.BytesIO(content)))
    if a.ndim==3:raise ValueError('GT must be a single-channel depth/disparity image, not RGB')
    return a


def _image_timestamp_seconds(stem):
    """EuRoC timestamp filename in ns (19 digits), us, or ms; no frame guess."""
    stem=str(stem).lower()
    if stem.startswith('frame_'):
        stem=stem[6:]
    if not stem.isdigit() or len(stem)<13:
        return None
    value=int(stem)
    if len(stem)>=18:return value/1.e9
    if len(stem)>=15:return value/1.e6
    return value/1.e3


def discover_gt(gt_source,frame,side,dataset=None):
    """Find a depth GT frame using its corresponding camera image timestamp.

    The external frame number (e.g. 290) is NOT the actual image filename in
    EuRoC/ZED datasets. We first use dataset.pairs[frame] to obtain the image
    timestamp, prefer an identically named depth0 image, and only fall back to
    a close timestamp when necessary. Never accidentally select an RGB image.
    """
    p=Path(gt_source).expanduser()
    if not p.exists():raise FileNotFoundError('GT source not found: '+str(p))
    if p.is_file() and p.suffix.lower()!='.zip':return str(p),p.read_bytes()
    z=zipfile.ZipFile(p) if p.is_file() else None
    try:
        if dataset is not None and getattr(dataset,'z',None) is not None and p.resolve()==dataset.path.resolve():
            files=dataset.z.namelist()
        else:
            files=z.namelist() if z else [str(t.relative_to(p)).replace('\\','/') for t in p.rglob('*') if t.is_file()]
        files=[f for f in files if Path(f).suffix.lower() in EXTS and not Path(f).name.startswith('.')]
        # A frame index may be 290, while its source image and GT filenames are
        # both 19-digit ZED timestamps. Thus use camera-source filename FIRST.
        src_stems=set()
        if dataset is not None and int(frame) in dataset.pairs:
            left,right=dataset.pairs[int(frame)]
            src_stems.add(Path(left if side=='left' else right).stem.lower())
        src_times=[t for t in (_image_timestamp_seconds(x) for x in src_stems) if t is not None]
        tokens={str(frame),f'{frame:06d}',f'{frame:05d}',f'{frame:04d}',f'{frame:08d}'}
        candidates=[]
        for name in files:
            low=name.lower().replace('\\','/')
            stem=Path(name).stem.lower()
            if not any(x in low for x in ('/depth0/','/depth1/','depth','/disp/','disparity','groundtruth','ground_truth','/gt/','gt_')):
                continue
            if any(x in low for x in ('rgb','color','mask','confidence','confid','preview')):
                continue
            # depth0 is conventionally LEFT (cam0) in the user's ZED rig.
            wrong=(any(w in low for w in ('/depth1/','/cam1/','/right/','depth_cam1','depth_right','right_depth','gt_cam1'))
                if side=='left' else any(w in low for w in ('/depth0/','/cam0/','/left/','depth_cam0','depth_left','left_depth','gt_cam0')))
            if wrong:continue
            explicit=any(stem==ss or stem.startswith(ss+'_') or stem.endswith('_'+ss) for ss in src_stems)
            by_index=any(stem==t or stem=='frame_'+t or stem.startswith(t+'_') or stem.endswith('_'+t) for t in tokens)
            score=0
            if explicit:score+=200
            if by_index:score+=60
            if side=='left' and '/depth0/data/' in low:score+=25
            if side=='right' and '/depth1/data/' in low:score+=25
            if any(x in low for x in ('/gt/','groundtruth','ground_truth')):score+=6
            if src_times:
                t=_image_timestamp_seconds(stem)
                if t is not None:
                    offset=min(abs(t-s) for s in src_times)
                    if offset<=0.05 and not explicit:
                        # Only allow a nearest-timestamp fallback within 50 ms.
                        score+=90-(offset/0.05)*30
            if score>=50:candidates.append((float(score),name))
        if not candidates:
            sample=', '.join(sorted(src_stems)) or f'frame {frame}'
            raise FileNotFoundError(f'GT frame {frame} not found for camera timestamp {sample}. '
                'Expected e.g. mav0/depth0/data/<cam0-timestamp>.png; '
                'check whether the dataset includes depth images.')
        candidates.sort(key=lambda x:(-x[0],x[1]))
        if len(candidates)>1 and abs(candidates[0][0]-candidates[1][0])<1.e-6:
            raise ValueError('Multiple equally plausible GT depth files: '+
                             ' / '.join(n for _,n in candidates[:4]))
        name=candidates[0][1]
        return name, z.read(name) if z else (p/name).read_bytes()
    finally:
        if z:z.close()


def _to_depth(data,kind,focal,baseline):
    a=np.asarray(data,np.float32)
    if kind=='depth_m':z=a
    elif kind=='depth_mm':z=a*.001
    elif kind=='disp_px':z=np.divide(focal*baseline,a,out=np.full_like(a,np.nan),where=a>0)
    elif kind=='disp_16':z=np.divide(focal*baseline*16.,a,out=np.full_like(a,np.nan),where=a>0)
    elif kind=='disp_256':z=np.divide(focal*baseline*256.,a,out=np.full_like(a,np.nan),where=a>0)
    else:raise ValueError('Unknown GT encoding')
    return np.where(np.isfinite(z)&(z>1.e-4)&(z<1.e5),z,np.nan).astype(np.float32)


def _right_reference_from_left(z,focal,baseline):
    """GT left depth reprojection + nearest-z to right; only sampled GT-visible pixels."""
    h,w=z.shape
    yy,xx=np.indices((h,w),dtype=np.int32)
    shift=focal*baseline/z
    xr=xx.astype(np.float32)-shift
    valid=np.isfinite(z)&np.isfinite(xr)&(xr>=0)&(xr<w)
    ys=yy[valid];xs=xx[valid];zz=z[valid];xxr=np.rint(xr[valid]).astype(np.int32)
    good=(xxr>=0)&(xxr<w)
    ys=ys[good];xs=xs[good];zz=zz[good];xxr=xxr[good]
    flat=ys*w+xxr
    zb=np.full(h*w,np.inf,np.float32)
    np.minimum.at(zb,flat,zz)
    nearest=zz<=zb[flat]*(1+1.e-5)
    lx=np.full(h*w,np.nan,np.float32)
    # A valid right pixel inherits the left coordinate of the nearest visible
    # GT sample, never any DPG prediction.
    lx[flat[nearest]]=xs[nearest].astype(np.float32)
    return lx.reshape(h,w),np.isfinite(lx.reshape(h,w))


def measure_result(folder,gt_source,*,gt_kind='depth_m',gt_side='right',out_folder=None,gt_file=None,gt_dataset=None):
    folder=Path(folder)
    with (folder/'REPORT.json').open(encoding='utf8') as f:rep=json.load(f)
    frame=int(rep['frame'])
    with np.load(folder/'world.npz',allow_pickle=False) as f:
        planes=f['planes'].copy(); right_plane=f['right_plane'].copy()
        focal=float(f['focal']);cx=float(f['cx']);cy=float(f['cy']);baseline=float(f['baseline'])
    with np.load(folder/'dpg_labels.npz',allow_pickle=False) as f:
        labels={d:f['right_'+d].copy() for d in ('L','VC','CC')}
    h,w=right_plane.shape
    name,raw=gt_file if gt_file is not None else discover_gt(gt_source,frame,gt_side,dataset=gt_dataset)
    gt_depth=_to_depth(_read_field(raw,name),gt_kind,focal,baseline)
    if gt_depth.shape!=(h,w):
        raise ValueError(f'GT shape {gt_depth.shape} != stereo image shape {(h,w)}. GT is not rescaled.')
    xx=np.broadcast_to(np.arange(w,dtype=np.float32),(h,w))
    # DPG right-plane projection to LEFT for every right source pixel.
    mx,yy,z,valid=source_geometry(right_plane,planes,focal,cx,cy,baseline,'right')
    predicted_left=xx+focal*baseline/z
    if gt_side=='right':
        ref_left=xx+focal*baseline/gt_depth
        gt_valid=np.isfinite(gt_depth)
        how='right_GT_depth_to_left_analytic'
    else:
        ref_left,gt_valid=_right_reference_from_left(gt_depth,focal,baseline)
        how='left_GT_depth_forward_zbuffer_to_right'
    # Only projected left-image coordinates are part of the comparison.
    can_use=gt_valid&valid&np.isfinite(predicted_left)&(ref_left>=0)&(ref_left<w)&\
            (predicted_left>=0)&(predicted_left<w)
    error=np.abs(predicted_left-ref_left).astype(np.float32)
    error[~can_use]=np.nan
    # Boundaries need a stricter GT-only reliability mask than ordinary pixel MAE.
    # We discard holes and strong depth jumps because a left-only GT image
    # cannot establish the visible right-side surface at an occlusion seam.
    finite_depth=np.isfinite(gt_depth) & (gt_depth>0)
    from scipy.ndimage import minimum_filter, maximum_filter
    zlo=minimum_filter(np.where(finite_depth,gt_depth,np.inf),size=3,mode='nearest')
    zhi=maximum_filter(np.where(finite_depth,gt_depth,-np.inf),size=3,mode='nearest')
    complete=(minimum_filter(finite_depth.astype(np.uint8),size=3,mode='nearest')>0)
    local_stable=complete & ((zhi-zlo) <= np.maximum(0.12,0.08*gt_depth))
    if gt_side=='left':
        # Right-pixel correspondence ref_left was obtained from LEFT GT z-buffer;
        # sample its original LEFT GT neighborhood, not predicted model geometry.
        lx=np.rint(np.nan_to_num(ref_left,nan=-1)).astype(np.int64)
        ix=np.clip(lx,0,w-1)
        boundary_gt_valid=gt_valid & (lx>=0)&(lx<w)&np.take_along_axis(local_stable,ix,axis=1)
    else:
        boundary_gt_valid=gt_valid & local_stable
    boundary_gt_valid &= np.isfinite(ref_left)&(ref_left>=0)&(ref_left<w)
    report={'frame':frame,'gt_name':name,'gt_kind':gt_kind,'gt_side':gt_side,
        'gt_mapping':how,'calibration':{'focal_px':focal,'baseline_m':baseline,'cx':cx,'cy':cy},
        'GT_only_posthoc':True,'GT_used_for_solver':False,'GT_used_for_plane_assignment':False,
        'metric':'abs(right_to_left_predicted_x - GT_right_to_left_x) in native px',
        'evaluated_pixels':int(can_use.sum()),'image_pixels':int(h*w),
        'GT_coverage_pct':round(100.*float(can_use.mean()),3)}
    valid_errors=error[can_use]
    def summarize(v):
        if len(v)==0:return {'n':0,'mae_px':None,'median_px':None,'p90_px':None,'within_1px_pct':None,'within_2px_pct':None,'within_3px_pct':None}
        return {'n':int(len(v)),'mae_px':round(float(np.mean(v)),4),
                'median_px':round(float(np.median(v)),4),'p90_px':round(float(np.percentile(v,90)),4),
                'within_1px_pct':round(float(np.mean(v<=1)*100),3),
                'within_2px_pct':round(float(np.mean(v<=2)*100),3),
                'within_3px_pct':round(float(np.mean(v<=3)*100),3)}
    report['total']=summarize(valid_errors)
    rows=[]
    for domain,lab in labels.items():
        count=np.bincount(lab.ravel().astype(np.int64),minlength=int(lab.max())+1)
        for elem in np.flatnonzero(count):
            if elem<=0:continue
            sel=lab==elem
            vv=sel&can_use
            rec={'domain':domain,'right_element_id':int(elem),'element_pixels':int(count[elem]),
                 'GT_covered_pct':round(100*float(vv.sum())/max(int(count[elem]),1),3)}
            rec.update(summarize(error[vv]))
            rows.append(rec)
    report['elements_evaluated']=int(sum(r['n']>=5 for r in rows))
    # SECOND, stricter experiment: fit a continuous right->left affine disparity
    # using ONLY an individual accepted DPG boundary-pair's support samples,
    # then extend that transform over the WHOLE right element. GT is touched
    # strictly after fitting, never as a correspondence or selection signal.
    pair_rows=[]
    with np.load(folder/'boundary_matches.npz',allow_pickle=False) as z:
        pairs={k:z[k].copy() for k in z.files}
    try:
        domains=('L','VC','CC')
        owners=np.column_stack((pairs['domain'],pairs['left_owner'],pairs['right_owner']))
        accepted=(pairs['confidence']>=.3)
        if 'kind' in pairs:accepted &= pairs['kind']==0
        unique,groups,counts=np.unique(owners[accepted],axis=0,return_inverse=True,return_counts=True)
        src_idx=np.flatnonzero(accepted)
        for pair_no,(dom,left_id,right_id) in enumerate(unique):
            if not (0<=dom<len(domains)) or left_id<=0 or right_id<=0:continue
            inds=src_idx[groups==pair_no]
            if len(inds)<8:continue
            xy=np.asarray(pairs['right_xy'][inds],np.float64)
            disparity=(pairs['left_xy'][inds,0]-xy[:,0]).astype(np.float64)
            # Robust fit with a mild regularizer: an almost vertical seam must
            # not invent large horizontal shear when extrapolated to its area.
            mx=float(np.mean(xy[:,0]));my=float(np.mean(xy[:,1]))
            A=np.column_stack(((xy[:,0]-mx)/w,(xy[:,1]-my)/h,np.ones(len(xy))))
            rank=int(np.linalg.matrix_rank(A,tol=1.e-4))
            coef=np.linalg.lstsq(A,disparity,rcond=None)[0]
            for _ in range(3):
                residual=disparity-A@coef
                scale=max(float(np.median(np.abs(residual))),.3)
                weights=np.clip(2.5*scale/np.maximum(np.abs(residual),1.e-4),0,1)
                reg=np.diag([3. if np.ptp(xy[:,0])<10 else .01,
                             3. if np.ptp(xy[:,1])<10 else .01,0.])
                coef=np.linalg.solve(A.T@(weights[:,None]*A)+reg,
                                      A.T@(weights*disparity))
            field=labels[domains[dom]]==right_id
            eval_mask=field&can_use
            ry,rx=np.nonzero(eval_mask)
            pred=rx.astype(np.float64)+(rx-mx)/w*coef[0]+(ry-my)/h*coef[1]+coef[2]
            v=np.abs(pred-ref_left[eval_mask])
            row={'domain':domains[dom],'left_element_id':int(left_id),
                 'right_element_id':int(right_id),'pair_support_n':len(inds),
                 'affine_rank':rank,'fit_boundary_RMS_px':round(float(np.sqrt(np.mean((disparity-A@coef)**2))),4),
                 'GT_valid_fraction_of_right_element_pct':round(100.*float(eval_mask.sum())/max(int(field.sum()),1),3)}
            row.update(summarize(v))
            pair_rows.append(row)
    except (KeyError,ValueError) as exc:
        report['pair_extrapolation_warning']=str(exc)
    report['pair_extrapolations_evaluated']=len(pair_rows)
    # Aggregate the boundary-fit extrapolation scores; repeated pixels may occur
    # across different element pairs, so this is explicitly a pair-weighted
    # comparison, not an independent per-image-pixel accuracy measure.
    usable_pairs=[r for r in pair_rows if r.get('n',0)>0 and r.get('mae_px') is not None]
    total_pair_n=sum(int(r['n']) for r in usable_pairs)
    report['pair_extrapolation_summary']={
        'pairs_with_GT':len(usable_pairs),
        'weighted_sample_count':total_pair_n,
        'weighted_mae_px':round(sum(float(r['mae_px'])*int(r['n']) for r in usable_pairs)/total_pair_n,4)
            if total_pair_n else None,
        'weighted_within_1px_pct':round(sum(float(r['within_1px_pct'])*int(r['n']) for r in usable_pairs)/total_pair_n,3)
            if total_pair_n else None,
    }
    # Independent original-boundary evaluation: same source element IDs,
    # GT-only observable subset and paired left GT reprojection.
    try:
        boundary=evaluate_boundary_projection(labels,ref_left,predicted_left,
              boundary_gt_valid, valid)
        with np.load(folder/'boundary_matches.npz',allow_pickle=False) as data:
            matches={key:data[key] for key in data.files}
        pair_support=gt_pair_support(matches,ref_left,boundary_gt_valid)
        report['gt_boundary']=dict(boundary,**pair_support,
              reliability_rule='3x3 finite depth; local depth jump <= max(0.12m, 8% of depth); left GT z-buffer for right visibility')
    except Exception as exc:
        report['gt_boundary_warning']=str(exc)
    out=Path(out_folder) if out_folder else folder/'GT_EVALUATION' 
    out.mkdir(parents=True,exist_ok=True)
    (out/'GT_SEGMENT_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    with (out/'GT_SEGMENT_ELEMENTS.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['domain','right_element_id','element_pixels',
            'GT_covered_pct','n','mae_px','median_px','p90_px','within_1px_pct','within_2px_pct','within_3px_pct'])
        writer.writeheader();writer.writerows(rows)
    with (out/'GT_SEGMENT_PAIR_EXTRAPOLATION.csv').open('w',encoding='utf-8-sig',newline='') as f:
        fieldnames=['domain','left_element_id','right_element_id','pair_support_n','affine_rank',
            'fit_boundary_RMS_px','GT_valid_fraction_of_right_element_pct','n','mae_px',
            'median_px','p90_px','within_1px_pct','within_2px_pct','within_3px_pct']
        writer=csv.DictWriter(f,fieldnames=fieldnames)
        writer.writeheader();writer.writerows(pair_rows)
    # Red/yellow/green GT error; gray = no independent GT evidence.
    heat=np.full((h,w,3),(54,56,65),np.uint8)
    vals=np.nan_to_num(error,nan=0.,posinf=0.)
    col=np.minimum(vals/8.,1.)
    heat[can_use,0]=np.clip(50+205*col[can_use],0,255).astype(np.uint8)
    heat[can_use,1]=np.clip(235*(1-col[can_use]),0,255).astype(np.uint8)
    heat[can_use,2]=50
    Image.fromarray(heat).save(out/'GT_SEGMENT_error_right.png')
    Image.fromarray((can_use.astype(np.uint8)*255)).save(out/'GT_SEGMENT_valid_right.png')
    # Preserve the exact V6 DPG filenames for old scripts and diagnostics.
    # The generic GT_SEGMENT_* names are used by V7/V7.1 comparator runs.
    if rep.get('segmentation_method', 'dpg') == 'dpg':
        import shutil
        for stem in ('REPORT.json','ELEMENTS.csv','PAIR_EXTRAPOLATION.csv',
                     'error_right.png','valid_right.png'):
            shutil.copyfile(out/('GT_SEGMENT_'+stem),out/('GT_DPG_'+stem))
    return out,report
