"""Read camera/GT metadata from the user's stereo dataset, not fitted geometry.

No GT is exposed to the solver. Missing or ambiguous metadata is reported, not
replaced by a guessed GT unit or camera side. The calibration reader supports
common JSON/YAML, OpenCV P1/P2 and EuRoC cam0/cam1 sensor.yaml layouts.
"""
from __future__ import annotations
import json, math, re, zipfile
from pathlib import Path
import numpy as np

METADATA_NAMES=(
    'clip_manifest.json','dataset.json','metadata.json','calibration.json',
    'camera_calibration.json','camera_info.json','stereo_calibration.json',
    'calibration.yaml','calibration.yml','camera.yaml','camera.yml',
    'stereo.yaml','stereo.yml','cameras.yaml','cameras.yml',
    'sensor.yaml','calibration.conf','zed.conf',
)


def read_entries(dataset):
    """Read small probable metadata, independent of path's zip/folder layout."""
    path=Path(dataset)
    if path.is_file() and path.suffix.lower()=='.zip':
        with zipfile.ZipFile(path) as z:
            entries=[]
            for info in z.infolist():
                name=info.filename.replace('\\','/')
                if not name.lower().endswith(METADATA_NAMES) or info.file_size>1_000_000:continue
                try:entries.append((name,z.read(info)))
                except (KeyError,OSError):continue
            return entries
    if path.is_dir():
        return [(str(p.relative_to(path)).replace('\\','/'),p.read_bytes())
                for p in path.rglob('*') if p.is_file() and
                p.name.lower() in METADATA_NAMES and p.stat().st_size<=1_000_000]
    return []


def _parse(name, raw):
    lower=name.lower()
    if lower.endswith('.json'):
        try:return json.loads(raw.decode('utf-8-sig'))
        except Exception:return None
    if lower.endswith(('.yaml','.yml')):
        try:
            import yaml
            return yaml.safe_load(raw.decode('utf-8-sig'))
        except Exception:return None
    if lower.endswith('.conf'):
        import configparser, io
        try:
            parser=configparser.ConfigParser(interpolation=None)
            parser.optionxform=str.lower
            parser.read_file(io.StringIO(raw.decode('utf-8-sig')))
            return {'conf_sections':{s:dict(parser.items(s)) for s in parser.sections()}}
        except Exception:return None
    return None


def read_metadata(dataset):
    return [(name,obj) for name,raw in read_entries(dataset)
            if isinstance((obj:=_parse(name,raw)),dict)]


def _number(v):
    if isinstance(v,(int,float,np.integer,np.floating)) and math.isfinite(float(v)):
        return float(v)
    if isinstance(v,str):
        try:
            f=float(v.strip())
            return f if math.isfinite(f) else None
        except ValueError:return None
    return None


def _normalized_key(k):
    return re.sub(r'[^a-z0-9]','',str(k).lower())


def _field(mapping, *names):
    if not isinstance(mapping,dict):return None
    wanted={_normalized_key(n) for n in names}
    for k,v in mapping.items():
        if _normalized_key(k) in wanted:return v
    return None


def _walk(ob):
    if isinstance(ob,dict):
        yield ob
        for v in ob.values():yield from _walk(v)
    elif isinstance(ob,(list,tuple)):
        for v in ob:yield from _walk(v)


def _mat34(obj):
    if isinstance(obj,dict):obj=obj.get('data',obj)
    try:
        arr=np.asarray(obj,dtype=np.float64)
        if arr.shape==(3,4):return arr
        if arr.size==12:return arr.reshape(3,4)
    except (TypeError,ValueError):pass
    return None


def _calibration_from_projection(obj):
    """Rectified stereo projections are authoritative for baseline and focal."""
    for o in _walk(obj):
        p0=_field(o,'P1','P_left','projection_left','left_projection')
        p1=_field(o,'P2','P_right','projection_right','right_projection')
        if p0 is None or p1 is None:
            left=_field(o,'left','cam0','camera0')
            right=_field(o,'right','cam1','camera1')
            if isinstance(left,dict) and isinstance(right,dict):
                p0=_field(left,'P','projection_matrix','projection')
                p1=_field(right,'P','projection_matrix','projection')
        a,b=_mat34(p0),_mat34(p1)
        if a is None or b is None:continue
        fx=float(a[0,0]); baseline=abs(float(b[0,3]/b[0,0]-a[0,3]/a[0,0])) if a[0,0] and b[0,0] else 0.
        if fx>0 and baseline>0:
            return {'focal_px':fx,'baseline_m':baseline,'cx':float(a[0,2]),
                    'cy':float(a[1,2]), 'right_cx':float(b[0,2]),'rectified':True,
                    'provenance':'calibrated_stereo_projection_P1_P2'}
    return None


def _calibration_from_sensor_yaml(entries):
    sources={}
    for name,obj in entries:
        if name.replace('\\','/').lower().endswith('cam0/sensor.yaml'):sources[0]=obj
        if name.replace('\\','/').lower().endswith('cam1/sensor.yaml'):sources[1]=obj
    if not all(x in sources for x in (0,1)):return None
    arrs=[]
    for cam in (0,1):
        v=_field(sources[cam],'intrinsics')
        if not isinstance(v,(list,tuple)) or len(v)<4:return None
        arrs.append([float(x) for x in v[:4]])
    transforms=[]
    for cam in (0,1):
        mat=_field(sources[cam],'T_BS')
        if isinstance(mat,dict):mat=mat.get('data')
        try:
            t=np.asarray(mat,dtype=float).reshape((4,4))
            transforms.append(t)
        except (TypeError,ValueError):return None
    t=np.linalg.inv(transforms[0])@transforms[1]
    baseline=float(np.linalg.norm(t[:3,3]))
    if baseline<=0:return None
    return {'focal_px':arrs[0][0],'baseline_m':baseline,
            'cx':arrs[0][2],'cy':arrs[0][3], 'right_cx':arrs[1][2],
            'rectified':False,'provenance':'cam0_cam1_sensor_yaml_UNVERIFIED_RECTIFICATION'}


def _calibration_simple(obj):
    for o in _walk(obj):
        fx=_field(o,'focal_px','focal_length_px','focal_length','fx')
        fx=_number(fx)
        baseline=_field(o,'baseline_m','stereo_baseline_m','camera_baseline_m','baseline')
        baseline=_number(baseline)
        # JSON calibration may use millimetres explicitly.
        if baseline is None:
            bm=_number(_field(o,'baseline_mm','camera_baseline_mm'))
            if bm is not None:baseline=bm/1000.
        cx=_number(_field(o,'cx','principal_x','principal_x_px'))
        cy=_number(_field(o,'cy','principal_y','principal_y_px'))
        rectified=_field(o,'rectified','is_rectified','rectification_applied')
        if fx is not None and baseline is not None and fx>0 and 0<baseline<10:
            return {'focal_px':fx,'baseline_m':baseline,'cx':cx,'cy':cy,
                    'rectified':bool(rectified) if rectified is not None else None,
                    'provenance':'dataset_calibration_metadata'}
    return None


def read_camera_parameters(dataset):
    entries=read_metadata(dataset)
    for name,obj in entries:
        p=_calibration_from_projection(obj)
        if p is not None:return dict(p,source_file=name)
    sensor=_calibration_from_sensor_yaml(entries)
    if sensor is not None:return sensor
    for name,obj in entries:
        p=_calibration_simple(obj)
        if p is not None:return dict(p,source_file=name)
    return {}


def read_gt_hints(dataset):
    """Only explicitly declared GT metadata, never infer a kind here."""
    for name,obj in read_metadata(dataset):
        for o in _walk(obj):
            kind=_field(o,'gt_kind','gt_type','ground_truth_kind','groundtruth_kind','depth_format','depth_unit','depth_units','depth_units_m','disparity_unit')
            side=_field(o,'gt_side','depth_camera','ground_truth_camera','depth_side','depth_view')
            scale=_number(_field(o,'gt_scale','gt_value_scale','depth_scale_m','depth_scale','disparity_scale'))
            result={}
            if kind is not None:
                k=str(kind).lower().strip().replace(' ','_')
                kinds={
                    'depth_m':'depth_m','meter':'depth_m','meters':'depth_m','metre':'depth_m','metres':'depth_m',
                    'm':'depth_m','float32_m':'depth_m',
                    'depth_mm':'depth_mm','millimeter':'depth_mm','millimeters':'depth_mm','mm':'depth_mm',
                    'disparity_px':'disp_px','disp_px':'disp_px','pixels':'disp_px','pixel':'disp_px',
                    'disp_16':'disp_16','disparity_16':'disp_16',
                    'disp_256':'disp_256','disparity_256':'disp_256',
                }
                if k in kinds:result['kind']=kinds[k]
            if side is not None:
                s=str(side).lower().strip()
                if s in ('0','left','cam0','l'):result['side']='left'
                if s in ('1','right','cam1','r'):result['side']='right'
            if scale is not None:result['scale_m']=scale
            if result:return dict(result,source_file=name)
    return {}
