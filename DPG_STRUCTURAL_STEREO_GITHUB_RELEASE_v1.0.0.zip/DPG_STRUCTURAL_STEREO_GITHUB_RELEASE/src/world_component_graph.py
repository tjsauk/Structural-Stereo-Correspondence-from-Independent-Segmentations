"""Conservative world surface grouping; visualization identifiers only.

No 2D DPG ID is taken as a physical-object identity.  Geometrically
identical plane hypotheses share the same physical plane identifier.
Joining physically disconnected areas into an object is not inferred here.
"""
import numpy as np

def structural_components(obs, left_plane, right_plane, world_planes, camera, matched):
    normals=np.asarray(world_planes,np.float64)
    n=len(normals)
    parent=np.arange(n,dtype=np.int32)
    def root(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]];i=int(parent[i])
        return i
    # Only planes geometrically identical at sampled view directions are merged.
    # This does not infer that two nearby, parallel walls are one object.
    f=max(camera.focal,1e-6)
    for a in range(n):
        for b in range(a+1,n):
            na,nb=normals[a],normals[b]
            if not (np.isfinite(na).all() and np.isfinite(nb).all()):continue
            if np.linalg.norm(na-nb)<0.001*max(np.linalg.norm(na),np.linalg.norm(nb),1e-6):
                ra,rb=root(a),root(b)
                if ra!=rb:parent[rb]=ra
    labels=np.array([root(i) for i in range(n)],np.int32)
    _,labels=np.unique(labels,return_inverse=True)
    return labels.astype(np.int32),{'geometrically_distinct_plane_groups':int(len(np.unique(labels))),
       'object_identity_not_claimed':True}
