"""Dataset loading only. No geometry, GUI or matching code."""
from __future__ import annotations
import hashlib,io,json,zipfile
import math
from pathlib import Path
import numpy as np
from PIL import Image
class Dataset:
    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser().resolve()
        self.z = None
        if self.path.is_file():
            self.z = zipfile.ZipFile(self.path)
            names = set(self.z.namelist())
            manifests = sorted((n for n in names if n.endswith('clip_manifest.json')),
                               key=lambda n:len(n))
            manifest_path=manifests[0] if manifests else None
            manifest=json.loads(self.z.read(manifest_path)) if manifest_path else None
            if manifest and 'pair_source_ids' in manifest:
                prefix=manifest_path.rpartition('/')[0]
                def lookup(rel):
                    rel=str(rel).replace('\\','/')
                    if rel in names:return rel
                    candidate=(prefix+'/'+rel).lstrip('/') if prefix else rel
                    return candidate if candidate in names else rel
                self.pairs={int(r['pair_index']):(lookup(r['left']),lookup(r['right']))
                            for r in manifest['pair_source_ids']}
            else:
                left = sorted(
                    n
                    for n in names
                    if "cam0/data/" in n and n.lower().endswith((".png", ".jpg", ".jpeg"))
                )
                self.pairs = {
                    i: (l, l.replace("cam0/data/", "cam1/data/"))
                    for i, l in enumerate(left)
                    if l.replace("cam0/data/", "cam1/data/") in names
                }
        else:
            roots = [self.path, self.path / "mav0"]
            root = next((r for r in roots if (r / "cam0/data").is_dir()), None)
            if root is None:
                raise FileNotFoundError("Dataset must contain mav0/cam0/data/ or cam0/data/")
            manifest_file = next((f for f in (self.path/'clip_manifest.json',root/'clip_manifest.json') if f.is_file()),None)
            manifest = json.loads(manifest_file.read_text(encoding='utf-8')) if manifest_file else None
            left = sorted(
                x
                for x in (root / "cam0/data").iterdir()
                if x.suffix.lower() in (".png", ".jpg", ".jpeg")
            )
            right = root / "cam1/data"
            if manifest and 'pair_source_ids' in manifest:
                def folder_resolve(q):
                    path=Path(q)
                    if path.is_absolute():return str(path)
                    for basedir in (self.path,root,manifest_file.parent):
                        candidate=basedir/path
                        if candidate.is_file():return str(candidate)
                    return str(self.path/path)
                self.pairs={int(r['pair_index']):(folder_resolve(r['left']),folder_resolve(r['right']))
                    for r in manifest['pair_source_ids']}
            else:
                self.pairs={i:(str(l),str(right/l.name)) for i,l in enumerate(left)
                            if (right/l.name).exists()}
        if not self.pairs:
            raise ValueError("No stereo image pairs found")
        self.frames = sorted(self.pairs)
        self.calibration=self._read_camera_calibration()
        self.gt_hints=self._read_gt_hints()

    def _read_gt_hints(self):
        from dataset_metadata import read_gt_hints
        return read_gt_hints(self.path)

    def _read_camera_calibration(self):
        """Report measured FOV and physical baseline when source metadata exists.

        Does not impose a numeric disparity cap: there is no finite maximum
        disparity without a measured minimum visible depth. Camera YAML from
        unrectified streams is informational until its relation to any image
        rectification is independently confirmed.
        """
        from dataset_metadata import read_camera_parameters
        detected=read_camera_parameters(self.path)
        if detected:
            return dict(detected, status='dataset_calibration_detected')
        try:
            import yaml
        except ImportError:
            return {'status':'no usable camera calibration metadata'}
        sources=[]
        for camera in (0,1):
            suffix=f'cam{camera}/sensor.yaml'
            if self.z:
                names=[n for n in self.z.namelist() if n.endswith(suffix)]
                content=self.z.read(names[0]).decode('utf8') if names else None
            else:
                roots=[self.path,self.path/'mav0']
                candidates=[p/f'cam{camera}/sensor.yaml' for p in roots]
                content=next((p.read_text(encoding='utf8') for p in candidates if p.is_file()),None)
            if not content:return {'status':'not found: stereo sensor.yaml calibration data'}
            try:sources.append(yaml.safe_load(content))
            except Exception:return {'status':'sensor.yaml unreadable'}
        result={'status':'source sensor.yaml (rectification unverified)','cameras':[]}
        transforms=[]
        for src in sources:
            intr=src.get('intrinsics') or []
            resolution=src.get('resolution') or []
            camera={}
            if len(intr)>=4 and len(resolution)>=2:
                fx,fy,cx,cy=map(float,intr[:4]);w,h=map(int,resolution[:2])
                camera=dict(resolution_px=[w,h],focal_px=[fx,fy],principal_px=[cx,cy],
                            fov_degrees=[math.degrees(2*math.atan(w/(2*fx))),
                                         math.degrees(2*math.atan(h/(2*fy)))])
            result['cameras'].append(camera)
            t=src.get('T_BS')
            if isinstance(t,dict) and len(t.get('data',[]))==16:
                import numpy as np
                transforms.append(np.asarray(t['data'],dtype=float).reshape(4,4))
        if len(transforms)==2:
            import numpy as np
            T=np.linalg.inv(transforms[0])@transforms[1]
            result['baseline_m']=float(np.linalg.norm(T[:3,3]))
        return result

    def load(self, idx: int):
        a, b = self.pairs[int(idx)]

        def read(path: str):
            if self.z:
                return np.asarray(Image.open(io.BytesIO(self.z.read(path))).convert("RGB"))
            return np.asarray(Image.open(path).convert("RGB"))

        return read(a), read(b)

    def identity(self) -> str:
        return hashlib.sha256(str(self.path).encode("utf-8")).hexdigest()[:14]

