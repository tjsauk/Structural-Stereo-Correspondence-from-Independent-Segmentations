"""Only native DPG boundary arc pair data and a geometric arc grouping helper.

No dense disparity method or legacy stereo comparator is included here.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.spatial import cKDTree
from native_observation import DOMAINS
from observations import edge

@dataclass
class BoundaryMatches:
    # (left_x,left_y) / (right_x,right_y) in rectified original pixel grids.
    left_xy: np.ndarray
    right_xy: np.ndarray
    domain: np.ndarray      # L=0, VC=1, CC=2
    left_owner: np.ndarray  # native DPG labels; not cross-camera identities
    right_owner: np.ndarray
    confidence: np.ndarray
    segment_id: np.ndarray  # partial matched boundary arcs, -1 if isolated
    segments: list
    stats: dict
    kind: np.ndarray | None = None  # 0 = seam->seam, 1 = seam->interior

    def save(self, filename):
        np.savez_compressed(filename, left_xy=self.left_xy,right_xy=self.right_xy,
                domain=self.domain,left_owner=self.left_owner,right_owner=self.right_owner,
                confidence=self.confidence,segment_id=self.segment_id,
                kind=(np.zeros(len(self.left_xy),np.uint8) if self.kind is None else self.kind))

    @classmethod
    def load(cls, filename, segments=None, stats=None):
        with np.load(filename,allow_pickle=False) as z:
            data={k:z[k].copy() for k in z.files}
        return cls(**data, segments=segments or [], stats=stats or {})


def segment_clusters(matches:BoundaryMatches, max_step=11., max_disparity_jump=3.5, min_points=3):
    """Connect neighboring matches belonging to a *particular source pair*.

    These are *partial* arc pairs, not whole-element pair assumptions.
    """
    n=len(matches.left_xy)
    segment_id=np.full(n,-1,np.int32)
    segments=[]
    if n==0:return segment_id,segments
    # Dictionary split prevents matching two different elements just because
    # their boundaries meet in the image.
    domains=matches.domain
    keys=np.stack([domains,matches.left_owner,matches.right_owner],axis=1)
    unique,inv=np.unique(keys,axis=0,return_inverse=True)
    for grp,key in enumerate(unique):
        ids=np.flatnonzero(inv==grp)
        if len(ids)<min_points:continue
        xy=matches.left_xy[ids]
        pairs=cKDTree(xy).query_pairs(max_step,output_type='ndarray')
        parent=np.arange(len(ids),dtype=np.int32)
        def find(a):
            while parent[a]!=a:
                parent[a]=parent[parent[a]];a=parent[a]
            return a
        for u,v in pairs:
            disp_u=matches.left_xy[ids[u],0]-matches.right_xy[ids[u],0]
            disp_v=matches.left_xy[ids[v],0]-matches.right_xy[ids[v],0]
            if abs(float(disp_u-disp_v))>max_disparity_jump:continue
            a,b=find(int(u)),find(int(v))
            if a!=b:parent[b]=a
        roots=np.array([find(i) for i in range(len(ids))],dtype=np.int32)
        for root in np.unique(roots):
            sub=ids[roots==root]
            if len(sub)<min_points:continue
            coords=matches.left_xy[sub]
            # Endpoints approximated by two most distant samples along principal axis.
            center=coords.mean(axis=0)
            centered=coords-center
            _,_,vh=np.linalg.svd(centered,full_matrices=False)
            t=centered@vh[0]
            a=sub[np.argmin(t)];b=sub[np.argmax(t)]
            sid=len(segments)
            segment_id[sub]=sid
            segments.append(dict(id=sid,domain=DOMAINS[int(key[0])],left=int(key[1]),right=int(key[2]),
                n=int(len(sub)),start_left=matches.left_xy[a].tolist(),end_left=matches.left_xy[b].tolist(),
                start_right=matches.right_xy[a].tolist(),end_right=matches.right_xy[b].tolist(),
                mean_confidence=float(matches.confidence[sub].mean()),
                disparity_range_px=[float(np.min(matches.left_xy[sub,0]-matches.right_xy[sub,0])),
                                    float(np.max(matches.left_xy[sub,0]-matches.right_xy[sub,0]))]))
    return segment_id,segments


