"""v1.51 experimental DPG pixel-set encounter matcher (GT-blind).

Native *pixel sets* are the units of identity. Their internal source-camera
seams (including hole contours) generate encounters; the image's outside
boundary is never treated as a DPG contour. No pixel is changed in obs.

For each sampled source element-boundary pixel, all horizontally earlier
opposite-camera boundary positions are considered in an epipolar row. A
vectorized encounter generator evaluates RGB/structural context, then coherent
runs are voted for by (source pixel set, target pixel set, disparity band).
Multiple accepted parts of one element can have distinct displacement modes.
These partial boundary tracks, with original element owners, are passed to the
existing multi-affine puzzle solver. This is NOT dense disparity or pixelwise
RGB-driven fitting.
"""
from __future__ import annotations
import numpy as np
import cv2
from scipy import ndimage
from collections import defaultdict
from native_observation import DOMAINS, native_edge_mask
from boundary_matching import BoundaryMatches

METHOD='element-pixel-set-vectorized-encounter-v151'


def _features(images, obs):
    output=[]
    for side,rgb in zip(('left','right'),images):
        rgb=np.asarray(rgb,np.float32)/255.
        low=cv2.GaussianBlur(rgb,(0,0),1.45)
        large=cv2.GaussianBlur(rgb,(0,0),4.0)
        # Local two-sided appearance is supporting evidence, never an identity.
        gray=cv2.cvtColor(low,cv2.COLOR_RGB2GRAY)
        gx=cv2.Sobel(gray,cv2.CV_32F,1,0,ksize=3)
        gy=cv2.Sobel(gray,cv2.CV_32F,0,1,ksize=3)
        mag=np.sqrt(gx*gx+gy*gy)
        chans=[low,large,mag[...,None]]
        for d in DOMAINS:
            seam=native_edge_mask(obs[f'{side}_{d}']).astype(np.float32)
            chans.append(cv2.GaussianBlur(seam,(0,0),3.)[...,None])
        # Signed horizontal contrast separates opposite vertical sides of a leg.
        chans.append(gx[...,None])
        feat=np.concatenate(chans,axis=2).astype(np.float32)
        output.append(feat)
    return output


def _events(left_boundary,right_boundary,left_labels,right_labels,lf,rf,
            *,sample_stride=3,max_per_source=11,photo_threshold=.40):
    """Vectorized epipolar encounter sweep; no per-candidate Python loop.

    Every source boundary sample queries ALL opposite boundary crossings in
    its horizontal row. The source/target element owner is read from the
    immutable label images, not from a line segment ID. Running rows in
    batches bounds temporary memory independent of image width.
    """
    h,w=left_labels.shape
    accum=[[] for _ in range(6)]
    proposed=0
    for y in range(1,h-1):
        lx=np.flatnonzero(left_boundary[y])
        rx=np.flatnonzero(right_boundary[y])
        if not len(lx) or not len(rx):continue
        # deterministic spatial sampling, does not depend on contour length
        lx=lx[((lx+y)%max(1,sample_stride))==0]
        if not len(lx):continue
        ends=np.searchsorted(rx,lx,side='left')
        starts=np.searchsorted(rx,lx-w,side='left')
        counts=ends-starts
        n=int(counts.sum())
        if not n:continue
        # Broadcasting via indexed ragged ranges, no Python pair iteration.
        q=np.repeat(np.arange(len(lx),dtype=np.int32),counts)
        origins=np.repeat(np.cumsum(counts)-counts,counts)
        rix=np.arange(n,dtype=np.int32)-origins+np.repeat(starts,counts)
        xs=lx[q];xt=rx[rix]
        proposed+=n
        al=lf[y,xs];ar=rf[y,xt]
        # Spatially smooth colour/contrast and multi-domain neighbourhood.
        photo=np.mean(np.abs(al[:,:6]-ar[:,:6]),axis=1)
        struct=np.mean(np.abs(al[:,7:]-ar[:,7:]),axis=1)
        grad=np.abs(al[:,6]-ar[:,6])
        # Suppress opposite-polarity boundary coincidences only when both
        # cameras have sufficiently strong independent horizontal gradients.
        # Weak/shadow boundaries remain eligible (no hard semantic leg rule).
        pol=(al[:,-1]*ar[:,-1]<0.) & (np.abs(al[:,-1])>.07) & (np.abs(ar[:,-1])>.07)
        cost=photo*1.75+struct*.50+np.minimum(grad,1.)*.04+pol*.24
        ok=(photo<photo_threshold)&(cost<.66)&((xs-xt)>=0)
        if not np.any(ok):continue
        xs=xs[ok];xt=xt[ok];q=q[ok];cost=cost[ok]
        # Retain many encounter shifts per *source* pixel, but keep bounded
        # memory. Coherence emerges downstream from the entire element set.
        order=np.lexsort((cost,q))
        sq=q[order]
        change=np.r_[True,sq[1:]!=sq[:-1]]
        first=np.maximum.accumulate(np.where(change,np.arange(len(sq)),0))
        take=order[(np.arange(len(sq))-first)<max_per_source]
        xs=xs[take];xt=xt[take];cost=cost[take]
        accum[0].append(xs.astype(np.int32));accum[1].append(np.full(len(xs),y,np.int32))
        accum[2].append(xt.astype(np.int32))
        accum[3].append(left_labels[y,xs].astype(np.int32))
        accum[4].append(right_labels[y,xt].astype(np.int32))
        accum[5].append(cost.astype(np.float32))
    arr=[np.concatenate(a) if a else np.array([],np.float32 if j==5 else np.int32)
         for j,a in enumerate(accum)]
    return arr,proposed


def _track_components(x,y,xr,cost,*,min_run=8,connect_radius=4):
    """Group encounter observations by contiguous *portions* of an element.

    Candidate point sets are raster connectivity hypotheses only: the original
    full element boundary has not been cut or overwritten.
    """
    if len(x)<min_run:return []
    xa,xb=int(x.min()),int(x.max())+1
    ya,yb=int(y.min()),int(y.max())+1
    width=xb-xa;height=yb-ya
    if not width or not height:return []
    # For each source coordinate keep the lowest cost encounter in this band.
    code=(y-ya)*width+(x-xa)
    order=np.lexsort((cost,code))
    keep=np.r_[True,code[order][1:]!=code[order][:-1]]
    ix=order[keep];x=x[ix];y=y[ix];xr=xr[ix];cost=cost[ix]
    if len(ix)<min_run:return []
    img=np.zeros((height,width),np.uint8);img[y-ya,x-xa]=1
    joined=cv2.dilate(img,np.ones((connect_radius,connect_radius),np.uint8))
    count,lbl=cv2.connectedComponents(joined,connectivity=8)
    groups=[]
    owners=lbl[y-ya,x-xa]
    for group in range(1,count):
        ii=np.flatnonzero(owners==group)
        if len(ii)<min_run:continue
        if max(np.ptp(x[ii]),np.ptp(y[ii]))<min_run:continue
        groups.append((x[ii],y[ii],xr[ii],cost[ii]))
    return groups


def _fit_track(x,y,xr,cost,shape):
    """Robust test of ONE locally affine displacement *boundary hypothesis*.

    Not a dense field: the model is used only to reject inconsistent event
    sequences and to estimate a candidate chart's boundary motion.
    """
    h,w=shape
    d=(x-xr).astype(np.float64)
    A=np.column_stack((np.ones(len(x)),x/max(w-1,1),y/max(h-1,1)))
    weights=np.clip(1.-cost,0.15,1.)
    if len(x)<4:return None
    try:
        p=np.array([np.median(d),0.,0.])
        for _ in range(4):
            residual=d-A@p
            robust=weights*np.minimum(1.,3.0/np.maximum(np.abs(residual),1e-4))
            p=np.linalg.lstsq(A*np.sqrt(robust[:,None]),d*np.sqrt(robust),rcond=None)[0]
        res=np.abs(d-A@p)
    except np.linalg.LinAlgError:return None
    valid=res<max(2.75,np.percentile(res,60)+1.5)
    if int(valid.sum())<7:return None
    score=float(np.median(res[valid]))
    if score>2.8 or np.percentile(res[valid],90)>5.:return None
    return p,valid,score


def match_element_encounters(images,obs,*,progress=lambda _:None,
                            sample_stride=3,max_per_source=11,
                            disparity_bin=5,min_run=22,max_matches=13500):
    """Return native-identity partial boundary pairs for the v1.49 solver.

    The image frame is not a boundary. Interior holes are naturally included
    because the native label-difference mask contains all true label seams.
    Segmentation remains per pixel set; partial arcs carry support only.
    """
    shape=images[0].shape[:2]
    if images[0].shape!=images[1].shape:raise ValueError('L/R image shapes differ')
    left_feat,right_feat=_features(images,obs)
    pieces=[];diagnostics=[];all_splits=[]
    proposal_count=0
    for domain_id,domain in enumerate(DOMAINS):
        ll=np.asarray(obs['left_'+domain],np.int32)
        rr=np.asarray(obs['right_'+domain],np.int32)
        le=native_edge_mask(ll);re=native_edge_mask(rr)
        # Only label *changes*. The outside of the image is never padded with
        # zeros to manufacture an open contour along the frame perimeter.
        ev,nprop=_events(le,re,ll,rr,left_feat,right_feat,
                          sample_stride=sample_stride,max_per_source=max_per_source)
        proposal_count+=nprop
        xs,ys,xt,lo,ro,cost=ev
        if len(xs)==0:
            diagnostics.append(dict(domain=domain,events=0,accepted_tracks=0));continue
        d=xs-xt
        # Histogram in element-pair and disparity band; no single DPG curve
        # or putative depth is used as the matching unit.
        band=(d//disparity_bin).astype(np.int32)
        keys=np.stack((lo,ro,band),axis=1)
        unique,group,counts=np.unique(keys,axis=0,return_inverse=True,return_counts=True)
        active=np.flatnonzero(counts>=min_run)
        order=np.argsort(group,kind='stable')
        starts=np.r_[0,np.cumsum(counts)]
        candidates=[]
        for k in active:
            ids=order[starts[k]:starts[k+1]]
            for px,py,pr,pc in _track_components(xs[ids],ys[ids],xt[ids],cost[ids],min_run=min_run):
                fitted=_fit_track(px,py,pr,pc,shape)
                if fitted is None:continue
                model,keep,err=fitted
                px,py,pr,pc=px[keep],py[keep],pr[keep],pc[keep]
                if len(px)<min_run:continue
                # Long coherent chains, multiple levels of support and low
                # descriptor disagreement are preferred to isolated crossings.
                score=(len(px)**.70)/(1.+2.*float(np.mean(pc))+err)
                candidates.append((score,int(unique[k,0]),int(unique[k,1]),px,py,pr,pc,model))
        # Independent two-sided evidence of a narrow, long structure.
        # Compute symmetric left/right boundary separations across a shared
        # vertical interval; no global 'table-leg' semantic label is used.
        pair_support=np.zeros(len(candidates),np.int32)
        if candidates:
            mid=np.array([[(np.min(c[4])+np.max(c[4]))*.5,
                           np.median(c[3]),np.median(c[5]),
                           np.max(c[4])-np.min(c[4]),
                           np.max(c[3])-np.min(c[3]),
                           np.median(c[3]-c[5])] for c in candidates],float)
            # Candidate tuple: score, left ID, right ID, x, y, right-x, cost, fit.
            # A long vertical contour is tested against nearby independent
            # contours. Require the same separation in BOTH cameras.
            tall=(mid[:,3]>=26)&(mid[:,3]>=1.5*mid[:,4])
            idx=np.flatnonzero(tall)
            if len(idx)>1:
                Y=mid[idx,0];L=mid[idx,1];R=mid[idx,2];D=mid[idx,5]
                shared=((mid[idx,3,None]+mid[None,idx,3])*.5-np.abs(Y[:,None]-Y[None,:]))
                dl=np.abs(L[:,None]-L[None,:]);dr=np.abs(R[:,None]-R[None,:])
                ok=((shared>=20)&(dl>=3)&(dl<=36)&(dr>=3)&(dr<=36)&
                    (np.abs(dl-dr)<6)&(np.abs(D[:,None]-D[None,:])<4))
                np.fill_diagonal(ok,False)
                pair_support[idx]=ok.sum(axis=1).astype(np.int32)
            # Normalize all candidate tuples to 9 fields, even when no pair
            # of tall contours exists. Otherwise single candidates crash unpack.
            candidates=[(c[0]*(1.0+.22*min(2,pair_support[i])),*c[1:],bool(pair_support[i]>0))
                        for i,c in enumerate(candidates)]
        candidates.sort(key=lambda v:-v[0])
        selected=0
        occupied=np.zeros(shape,np.uint8)
        # The right camera must not be reused repeatedly by unrelated nearby
        # source elements just because it crosses many source boundaries.
        target_hits=np.zeros(shape,np.uint8)
        domain_pieces=[]
        for score,lid,rid,px,py,pr,pc,model,thin_support in candidates:
            keep=(occupied[py,px]==0)&(target_hits[py,pr]<2)
            if np.count_nonzero(keep)<min_run:continue
            px,py,pr,pc=px[keep],py[keep],pr[keep],pc[keep]
            if max(np.ptp(px),np.ptp(py))<min_run:continue
            # If both cameras have long parallel contours, vote for a single
            # coherent target *element* per source boundary run, not one
            # coincident pixel. Preserve multiple runs of one element.
            occupied[py,px]=1
            np.add.at(target_hits,(py,pr),1)
            track=dict(domain=domain_id,domain_name=domain,left_owner=lid,right_owner=rid,
                       left=np.column_stack((px,py)).astype(np.float32),
                       right=np.column_stack((pr,py)).astype(np.float32),
                       confidence=np.clip(np.exp(-pc*1.2)*min(1.,len(px)/18.),.08,.99).astype(np.float32),
                       thin_two_sided_support=bool(thin_support),
                       score=score,affine_disparity=model,median_shift=float(np.median(px-pr)))
            domain_pieces.append(track);pieces.append(track);selected+=1
        diagnostics.append(dict(domain=domain,
            left_elements=int(len(np.unique(ll))),right_elements=int(len(np.unique(rr))),
            boundary_source_samples=int(np.count_nonzero(le)),
            raw_epipolar_encounters=int(nprop),retained_events=int(len(xs)),
            histogram_groups=int(len(unique)),candidate_tracks=int(len(candidates)),
            accepted_tracks=int(selected),accepted_thin_tracks=int(sum(bool(t['thin_two_sided_support']) for t in domain_pieces)),
            accepted_samples=int(sum(len(t['left']) for t in domain_pieces))))
        # Detect a multi-affine ELEMENT hypothesis from spatially separate
        # partial contour tracks. Group similar shifts; require independent
        # sequence support for each competing displacement level.
        for side in ('left','right'):
            groups=defaultdict(list)
            for item in domain_pieces:groups[item[side+'_owner']].append(item)
            for owner,tracks in groups.items():
                tracks=[t for t in tracks if len(t['left'])>=min_run]
                if len(tracks)<2:continue
                tracks.sort(key=lambda t:t['median_shift'])
                modes=[]
                for t in tracks:
                    if modes and t['median_shift']-modes[-1][-1]['median_shift']<=7.:
                        modes[-1].append(t)
                    else:modes.append([t])
                supported=[mode for mode in modes if sum(len(t['left']) for t in mode)>=2*min_run]
                if len(supported)<2:continue
                centers=[float(np.median([t['median_shift'] for t in mode])) for mode in supported]
                if max(centers)-min(centers)<8.:continue
                all_splits.append(dict(side=side,domain=domain,owner=int(owner),
                    modes=[dict(disparity_median_px=round(c,2),
                                partial_arcs=len(mode),
                                boundary_samples=sum(len(t['left']) for t in mode))
                           for c,mode in zip(centers,supported)],
                    status='candidate_from_native_element_boundary_sequences'))
        progress(f'Boundary encounters {domain}: {selected} partial arcs, '
                 f'{diagnostics[-1]["accepted_samples"]} matched samples')
    # Keep a bounded, balanced pool for the existing solver. Never drop an
    # entire accepted segment merely because it is short; budget by track.
    if pieces:
        quota=max(3,int(max_matches//len(pieces)))
        arr=[];segments=[]
        for track in pieces:
            n=len(track['left'])
            take=np.arange(n) if n<=quota else np.unique(np.linspace(0,n-1,quota).astype(np.int32))
            if len(take)<3:continue
            seg=len(segments)
            arr.append((track,take,seg))
            segments.append(dict(id=seg,domain=track['domain_name'],
                left=track['left_owner'],right=track['right_owner'],n=len(take),
                start_left=track['left'][take[0]].tolist(),end_left=track['left'][take[-1]].tolist(),
                start_right=track['right'][take[0]].tolist(),end_right=track['right'][take[-1]].tolist(),
                mean_confidence=float(track['confidence'][take].mean()),
                disparity_range_px=[float(np.min(track['left'][take,0]-track['right'][take,0])),
                                   float(np.max(track['left'][take,0]-track['right'][take,0]))]))
        matches=BoundaryMatches(
            np.concatenate([t['left'][ix] for t,ix,_ in arr]).astype(np.float32),
            np.concatenate([t['right'][ix] for t,ix,_ in arr]).astype(np.float32),
            np.concatenate([np.full(len(ix),t['domain'],np.uint8) for t,ix,_ in arr]),
            np.concatenate([np.full(len(ix),t['left_owner'],np.int32) for t,ix,_ in arr]),
            np.concatenate([np.full(len(ix),t['right_owner'],np.int32) for t,ix,_ in arr]),
            np.concatenate([t['confidence'][ix] for t,ix,_ in arr]).astype(np.float32),
            np.concatenate([np.full(len(ix),sid,np.int32) for t,ix,sid in arr]),
            segments,{})
    else:
        matches=BoundaryMatches(np.zeros((0,2),np.float32),np.zeros((0,2),np.float32),
            np.zeros(0,np.uint8),np.zeros(0,np.int32),np.zeros(0,np.int32),
            np.zeros(0,np.float32),np.zeros(0,np.int32),[],{})
    matches.stats=dict(method=METHOD,native_element_is_pixel_set=True,
        external_image_frame_is_not_contour=True,holes_are_native_contours=True,
        pixel_sets_preserved=True,no_GT_or_dense_disparity=True,
        max_disparity_px='image_extent_only',candidate_disparity_bin_px=int(disparity_bin),
        signed_gradient_polarity_audited=True,thin_two_sided_support_scored=True,
        target_reuse_limited_to_two=True,raw_epipolar_encounters=int(proposal_count),matched_boundary_samples=int(len(matches.left_xy)),
        matched_partial_arcs=int(len(matches.segments)),domain_stats=diagnostics,
        proposed_multi_affine_splits=all_splits,
        warning='Matching and multi-affine splits remain hypotheses; no physical identity accuracy certification')
    return matches
