"""Utilities for original DPG element ownership; no matching or warp code."""
from __future__ import annotations
import numpy as np
DOMAINS=('L','VC','CC')

def native_edge_mask(label_map):
    """Only true label changes at neighboring source pixels count as edges."""
    labels=np.asarray(label_map)
    edge=np.zeros(labels.shape,bool)
    a=labels[:,1:]!=labels[:,:-1]
    b=labels[1:,:]!=labels[:-1,:]
    edge[:,1:]|=a;edge[:,:-1]|=a
    edge[1:,:]|=b;edge[:-1,:]|=b
    return edge


def canonical_seam_mask(label_map):
    """Exactly one pixel per ORIGINAL DPG label transition (display only).

    native_edge_mask deliberately collects samples on BOTH sides of each
    seam for correspondence search. Rendering that 2-sided search mask as a
    contour generated the apparent doubled same-camera lines in V1.
    Choose right/bottom pixel deterministically, not both neighbors.
    Frame perimeter is never a seam and the immutable labels are untouched.
    """
    a=np.asarray(label_map)
    edge=np.zeros(a.shape,bool)
    edge[:,1:] |= a[:,1:]!=a[:,:-1]
    edge[1:,:] |= a[1:,:]!=a[:-1,:]
    return edge
