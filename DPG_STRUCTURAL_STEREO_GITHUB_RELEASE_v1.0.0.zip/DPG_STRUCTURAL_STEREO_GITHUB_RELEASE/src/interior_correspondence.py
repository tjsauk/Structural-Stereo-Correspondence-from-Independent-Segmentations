"""Boundary-to-interior evidence from an independently fitted world plane.

IMPORTANT: These are model-conditioned photometric confirmations, *not* new
independent stereo anchors. They are never fed back to the plane fitter.
"""
from __future__ import annotations
import cv2,numpy as np
from native_observation import DOMAINS,native_edge_mask
from world_render import source_geometry


def discover(images,obs,solution,*,sample_step=5,max_candidates=60000):
    h,w=images[0].shape[:2]
    f=solution.camera.focal;cx=solution.camera.cx;cy=solution.camera.cy;B=solution.camera.baseline
    ids={'left':solution.left_plane,'right':solution.right_plane}
    geom={s:source_geometry(ids[s],solution.world_planes,f,cx,cy,B,s)
          for s in ('left','right')}
    blurred=[cv2.GaussianBlur(a.astype(np.float32),(5,5),1.0) for a in images]
    counts={};records=[]
    for a,s in enumerate(('left','right')):
        target='right' if s=='left' else 'left'
        dest_index=1-a
        srcz=geom[s][2];srcmid=geom[s][0]
        oppz=geom[target][2]
        yy,xx=np.indices((h,w),dtype=np.int32)
        direction=-.5 if target=='left' else .5
        with np.errstate(divide='ignore',invalid='ignore'):
            tx=srcmid-direction*f*B/srcz
        tx=np.nan_to_num(tx,nan=-99999,posinf=-99999,neginf=-99999)
        rx=np.rint(tx).astype(np.int32)
        ok=(rx>=2)&(rx<w-2)&(ids[s]>=0)&np.isfinite(srcz)&(srcz>0)&(xx>=2)&(xx<w-2)
        # Same-world depth visibility against target camera's OWN observed sheets.
        targetz=np.zeros((h,w),np.float32)
        ix=np.clip(rx,0,w-1)
        targetz[:]=oppz[yy,ix]
        ok &= (np.isnan(targetz)|(targetz<=0)|(srcz<=targetz*1.005))
        for domain_id,d in enumerate(DOMAINS):
            src_edge=native_edge_mask(obs[f'{s}_{d}'])
            target_edge=native_edge_mask(obs[f'{target}_{d}'])
            target_on_edge=target_edge[yy,ix]
            boundary=ok&src_edge&(~target_on_edge)&(((xx+yy*3)%sample_step)==0)
            sy,sx=np.nonzero(boundary)
            if len(sx)>max_candidates:
                choices=np.linspace(0,len(sx)-1,max_candidates).astype(np.int32)
                sy=sy[choices];sx=sx[choices]
            if len(sx)==0:
                counts[f'{s}_{d}']=0;continue
            destx=tx[sy,sx].astype(np.float32)
            dst_rgb=cv2.remap(blurred[dest_index],destx.reshape(1,-1),sy.astype(np.float32).reshape(1,-1),
                             cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT).reshape(-1,3)
            src_rgb=blurred[a][sy,sx]
            dif=np.mean(np.abs(src_rgb-dst_rgb),axis=1)
            # Similarity alone never creates a new plane or establishes visibility.
            # Retain moderate-confidence observations as checks on existing planes.
            accept=dif<22.
            if accept.any():
                sy=sy[accept];sx=sx[accept];destx=destx[accept];dif=dif[accept]
                rec=dict(side=s,domain=np.full(len(sx),domain_id,np.uint8),
                    source_xy=np.column_stack((sx,sy)).astype(np.float32),
                    target_xy=np.column_stack((destx,sy)).astype(np.float32),
                    plane=ids[s][sy,sx].astype(np.int32),
                    rgb_mae=dif.astype(np.float32),
                    source_id=obs[f'{s}_{d}'][sy,sx].astype(np.int32),
                    target_id=obs[f'{target}_{d}'][sy,np.clip(np.rint(destx).astype(np.int32),0,w-1)].astype(np.int32))
                records.append(rec)
            counts[f'{s}_{d}']=int(accept.sum())
    data={}
    for key,dtype,shape in [('side',np.uint8,()),('domain',np.uint8,()),('source_xy',np.float32,(2,)),
                            ('target_xy',np.float32,(2,)),('plane',np.int32,()),
                            ('rgb_mae',np.float32,()),('source_id',np.int32,()),('target_id',np.int32,())]:
        values=[]
        for rec in records:
            if key=='side':values.append(np.full(len(rec['plane']),0 if rec['side']=='left' else 1,dtype))
            else:values.append(rec[key])
        data[key]=np.concatenate(values).astype(dtype) if values else np.empty((0,)+shape,dtype)
    return data,counts
