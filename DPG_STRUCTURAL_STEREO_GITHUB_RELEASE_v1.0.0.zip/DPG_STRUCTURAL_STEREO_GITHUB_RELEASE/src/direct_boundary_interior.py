"""GT-blind, independent BOUNDARY -> opposite-image INTERIOR observations.

This is an *additional sparse structural observation*, not dense disparity.
Each native DPG seam is a source. Candidate positions run along the entire
rectified epipolar row in the opposite camera. Opposite endpoints are required
NOT to lie on an element seam in the same domain. Photo/patch consistency,
uniqueness, coherent arc support and reciprocal-geometry consistency are used.
No world plane/disparity prior is an input to this module. Accepted samples
can participate in joint planar fitting but do not create RGB pixel depth maps.
"""
from __future__ import annotations
import numpy as np
import cv2
from scipy.ndimage import maximum_filter
from scipy.spatial import cKDTree
from boundary_matching import BoundaryMatches,segment_clusters
from native_observation import DOMAINS,canonical_seam_mask,native_edge_mask


def _descriptors(rgb):
    im=np.asarray(rgb,np.float32)/255.
    blur=cv2.GaussianBlur(im,(5,5),1.1)
    mono=cv2.cvtColor(blur,cv2.COLOR_RGB2GRAY)
    # Low-frequency context discriminates candidates even if source DPG
    # seam geometry does not exist as a seam in the other view.
    context=cv2.GaussianBlur(mono,(0,0),2.1)
    h,w=mono.shape
    features=np.empty((h,w,8),np.float32)
    features[...,:3]=blur
    features[...,3]=context
    features[...,4]=np.roll(context,3,axis=1)
    features[...,5]=np.roll(context,-3,axis=1)
    features[...,6]=np.roll(context,3,axis=0)
    features[...,7]=np.roll(context,-3,axis=0)
    return features


def _one_direction(images,obs,side,*,source_cap=2600,target_step=2,
                   min_track_neighbours=2):
    a=0 if side=='left' else 1
    b=1-a
    source='left' if a==0 else 'right'
    dest='right' if a==0 else 'left'
    sf,tf=_descriptors(images[a]),_descriptors(images[b])
    h,w=images[0].shape[:2]
    output=[];diagnostics=[]
    for domain,dom in enumerate(DOMAINS):
        source_labels=obs[f'{source}_{dom}']
        dest_labels=obs[f'{dest}_{dom}']
        seam=canonical_seam_mask(source_labels)
        # A full three-pixel exclusion window in the target ensures this
        # is truly a boundary->INTERIOR proposal, never a disguised seam pair.
        exclusion=maximum_filter(native_edge_mask(dest_labels).astype(np.uint8),
                                 size=(3,3),mode='nearest')>0
        y,x=np.nonzero(seam)
        interior=(x>=5)&(x<w-5)&(y>=5)&(y<h-5)
        x=x[interior];y=y[interior]
        if len(x)>source_cap:
            take=np.unique(np.linspace(0,len(x)-1,source_cap).astype(np.int32))
            x=x[take];y=y[take]
        raw=[]
        # Entire epipolar search, no ungrounded disparity cap, but vectorized
        # by scanline so working memory does not grow as H*W*D.
        for row in np.unique(y):
            srcx=x[y==row]
            if not len(srcx):continue
            target_x=np.arange(5,w-5,max(1,target_step),dtype=np.int32)
            target_x=target_x[~exclusion[row,target_x]]
            if not len(target_x):continue
            if a==0:
                candidates=target_x[None,:]<=srcx[:,None]
            else:
                candidates=target_x[None,:]>=srcx[:,None]
            if not candidates.any():continue
            va=sf[row,srcx];vb=tf[row,target_x]
            color=np.mean(np.abs(va[:,None,:3]-vb[None,:,:3]),axis=2)
            context=np.mean(np.abs(va[:,None,3:]-vb[None,:,3:]),axis=2)
            cost=.65*color+.35*context
            cost[~candidates]=np.inf
            best=np.argmin(cost,axis=1)
            best_cost=cost[np.arange(len(srcx)),best]
            # Check a genuinely different candidate displacement, not two
            # adjacent target pixels of the same interpolated optimum.
            alt=cost.copy()
            alt[np.abs(target_x[None,:]-target_x[best,None])<=10]=np.inf
            second=np.min(alt,axis=1)
            unique=np.zeros_like(second)
            usable=np.isfinite(best_cost)&np.isfinite(second)
            unique[usable]=second[usable]-best_cost[usable]
            accept=(best_cost<.095)&(unique>.018)&np.isfinite(second)
            if not accept.any():continue
            sx=srcx[accept];tx=target_x[best[accept]]
            for sx0,tx0,bc0,uc0 in zip(sx,tx,best_cost[accept],unique[accept]):
                raw.append((int(sx0),int(row),int(tx0),float(bc0),float(uc0),
                            int(source_labels[row,sx0]),int(dest_labels[row,tx0])))
        candidate_count=len(raw)
        if len(raw):
            raw=np.asarray(raw,np.float64)
            src_xy=raw[:,:2]
            disparity=raw[:,0]-raw[:,2] if a==0 else raw[:,2]-raw[:,0]
            owners=raw[:,5:7].astype(np.int32)
            # Structural coherence: neighbouring positions of the *same
            # source DPG element* should make compatible displacement votes.
            tree=cKDTree(src_xy)
            distances,near=tree.query(src_xy,k=min(9,len(src_xy)),distance_upper_bound=16.)
            nearby=(near<len(src_xy))
            near=np.clip(near,0,len(src_xy)-1)
            label_ok=(owners[near,0]==owners[:,None,0])&\
                     (owners[near,1]==owners[:,None,1])
            difference=np.abs(disparity[near]-disparity[:,None])
            tolerance=2.0+.40*np.where(np.isfinite(distances),distances,0)
            consensus=nearby&label_ok&(difference<=tolerance)&(distances>0)
            support=consensus.sum(axis=1)
            accept=support>=min_track_neighbours
            raw=raw[accept];support=support[accept]
            for v,k in zip(raw,support):
                sx,yy,tx,bc,uc,owner_src,owner_dst=v
                confidence=float(np.clip(.18+.21*min(k,6)/6+.20*min(uc/.075,1.)-
                                          .3*bc, .12,.59))
                if a==0:
                    xl,xr=sx,tx;lo,ro=owner_src,owner_dst
                else:
                    xl,xr=tx,sx;lo,ro=owner_dst,owner_src
                # Domain 0 is an unclassified pixel, not an element.
                # It cannot anchor a physical 3D chart/identity on its own.
                if int(lo)>0 and int(ro)>0:
                    output.append((xl,yy,xr,domain,int(lo),int(ro),confidence))
        diagnostics.append(dict(domain=dom,side=side,independent_candidates=candidate_count,
                                coherent_interior_samples=len(output)-sum(d.get('coherent_interior_samples',0) for d in diagnostics)))
    return output,diagnostics


def discover_independent(images,obs,progress=lambda _:None,*,source_cap=2600):
    allsamples=[];stats=[]
    for s in ('left','right'):
        progress(f'Independent boundary-to-interior: {s}, full epipolar row')
        rec,diag=_one_direction(images,obs,s,source_cap=source_cap)
        allsamples.extend(rec);stats.extend(diag)
    if not allsamples:
        out=BoundaryMatches(np.empty((0,2),np.float32),np.empty((0,2),np.float32),
           np.empty(0,np.uint8),np.empty(0,np.int32),np.empty(0,np.int32),
           np.empty(0,np.float32),np.empty(0,np.int32),[],{},
           kind=np.empty(0,np.uint8))
    else:
        z=np.asarray(allsamples,np.float32)
        n=len(z)
        out=BoundaryMatches(
            left_xy=z[:,[0,1]].astype(np.float32),right_xy=z[:,[2,1]].astype(np.float32),
            domain=z[:,3].astype(np.uint8),left_owner=z[:,4].astype(np.int32),
            right_owner=z[:,5].astype(np.int32),confidence=z[:,6].astype(np.float32),
            segment_id=np.full(n,-1,np.int32),segments=[],stats={},kind=np.ones(n,np.uint8))
        out.segment_id,out.segments=segment_clusters(out,max_step=16.,
                                                     max_disparity_jump=7.,min_points=3)
        # A sparse neighbouring chain alone is not a physical plane. A valid
        # 3D surface produces locally AFFINE disparity, even across scale
        # differences. Reject non-affine or drifting photo coincidences.
        keep=np.zeros(len(out.left_xy),bool)
        d=out.left_xy[:,0]-out.right_xy[:,0]
        for sid in np.unique(out.segment_id[out.segment_id>=0]):
            which=np.flatnonzero(out.segment_id==sid)
            if len(which)<9:continue
            xy=out.left_xy[which]
            if np.max(np.ptp(xy,axis=0))<18.:continue
            design=np.column_stack((xy[:,0],xy[:,1],np.ones(len(which))))
            active=np.ones(len(which),bool)
            for _ in range(3):
                co=np.linalg.lstsq(design[active],d[which][active],rcond=None)[0]
                res=np.abs(design@co-d[which])
                active=res<1.8
                if active.sum()<9:break
            if active.sum()>=9 and active.mean()>.72 and np.median(res[active])<.85:
                keep[which[active]]=True
        for name in ('left_xy','right_xy','domain','left_owner','right_owner',
                     'confidence','segment_id','kind'):
            setattr(out,name,getattr(out,name)[keep])
    out.stats=dict(method='independent_boundary_to_interior_bidirectional_epipolar',
                   no_GT=True,no_pixel_disparity_map=True,
                   independent_of_world_plane=True,accepted_samples=len(out.left_xy),
                   source_domain_stats=stats)
    progress(f'Independent boundary-to-interior arcs: {len(out.left_xy)} samples')
    return out


def combine(boundary,interior):
    if len(interior.left_xy)==0:
        boundary.kind=np.zeros(len(boundary.left_xy),np.uint8)
        boundary.stats['independent_boundary_to_interior_samples']=0
        return boundary
    new_id=1+int(np.max(boundary.segment_id)) if len(boundary.segment_id) else 0
    kwargs={k:np.concatenate([getattr(boundary,k),getattr(interior,k)],axis=0)
            for k in ('left_xy','right_xy','domain','left_owner','right_owner','confidence')}
    kinds=np.r_[np.zeros(len(boundary.left_xy),np.uint8),np.ones(len(interior.left_xy),np.uint8)]
    seg=np.r_[boundary.segment_id, np.where(interior.segment_id>=0,
                                           interior.segment_id+new_id,-1)].astype(np.int32)
    segments=list(boundary.segments)
    for item in interior.segments:
        row=dict(item);row['id']=int(row['id'])+new_id
        row['match_kind']='boundary_to_interior'
        segments.append(row)
    out=BoundaryMatches(**kwargs,segment_id=seg,segments=segments,
                        stats=dict(boundary.stats),kind=kinds)
    out.stats['independent_boundary_to_interior_samples']=int(len(interior.left_xy))
    out.stats['independent_boundary_to_interior_stats']=interior.stats
    return out
