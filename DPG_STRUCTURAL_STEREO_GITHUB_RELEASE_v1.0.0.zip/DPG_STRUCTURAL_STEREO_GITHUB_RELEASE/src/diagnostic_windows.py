"""Read-only Tk diagnostics for native DPG element pairs and affine world-plane charts.

No GT data is accessed. No stereo optimisation is performed by these windows.
The lower pair view is a midpoint *projection of source DPG pixel sets*, not a
redrawn fitting result or the midpoint RGB's z-buffer selection.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import colorsys
import csv
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import numpy as np
import cv2
from PIL import Image, ImageTk
from native_observation import DOMAINS
from world_render import source_geometry

BLUE=np.array((35,110,255),np.uint8)
RED=np.array((255,55,65),np.uint8)
GREEN=np.array((20,235,80),np.uint8)


def _read_npz(filename, required=True):
    if not Path(filename).is_file():
        if required:raise FileNotFoundError(str(filename))
        return {}
    with np.load(filename,allow_pickle=False) as z:
        return {k:z[k].copy() for k in z.files}


def palette(i):
    """Deterministic, camera-independent colour per global plane/surface id."""
    if i<0:return (42,45,52)
    hue=(0.137+0.618033988749895*int(i))%1.0
    r,g,b=colorsys.hsv_to_rgb(hue,0.74,0.96)
    return tuple(int(round(255*c)) for c in (r,g,b))


def inner_contour(mask):
    """One native source pixel on the inside of each true mask transition."""
    mask=np.asarray(mask,bool)
    out=np.zeros(mask.shape,bool)
    out[:,1:] |= mask[:,1:]&~mask[:,:-1]
    out[:,:-1] |= mask[:,:-1]&~mask[:,1:]
    out[1:,:] |= mask[1:,:]&~mask[:-1,:]
    out[:-1,:] |= mask[:-1,:]&~mask[1:,:]
    return out


def seam(label):
    """Canonical 1px label transition; the frame itself is not a DPG seam."""
    out=np.zeros(label.shape,bool)
    out[:,1:] |= label[:,1:]!=label[:,:-1]
    out[1:,:] |= label[1:,:]!=label[:-1,:]
    return out


class Results:
    def __init__(self, folder):
        folder=Path(folder)
        from PIL import Image
        self.path=folder
        self.rgb={s:np.asarray(Image.open(folder/f'{s}.png').convert('RGB')) for s in ('left','right')}
        self.labels=_read_npz(folder/'dpg_labels.npz')
        self.matches=_read_npz(folder/'boundary_matches.npz')
        self.world=_read_npz(folder/'world.npz')
        self.identity=_read_npz(folder/'surface_identity.npz',required=False)
        self.h,self.w=self.rgb['left'].shape[:2]
        if self.rgb['right'].shape!=self.rgb['left'].shape:raise ValueError('Camera image resolutions differ')
        for s in ('left','right'):
            if s+'_plane' not in self.world:raise ValueError('world.npz: missing plane map')
            for d in DOMAINS:
                if s+'_'+d not in self.labels:raise ValueError(f'Elementtilabelit puuttuvat: {s}_{d}')
        if not all(k in self.world for k in ('planes','focal','baseline','cx','cy')):
            raise ValueError('world.npz: missing camera model')
        self.camera={k:float(self.world[k]) for k in ('focal','baseline','cx','cy')}
        self.midxy={};self.valid={};self.depth={}
        for s in ('left','right'):
            mx,_,z,valid=source_geometry(self.world[s+'_plane'],self.world['planes'],
                self.camera['focal'],self.camera['cx'],self.camera['cy'],self.camera['baseline'],s)
            self.midxy[s]=mx;self.valid[s]=valid;self.depth[s]=z
        self._pairs={}
        for di,d in enumerate(DOMAINS):
            sub=np.flatnonzero(self.matches['domain']==di)
            if len(sub):
                keys=np.column_stack((self.matches['left_owner'][sub],self.matches['right_owner'][sub]))
                unique,inv,cnt=np.unique(keys,axis=0,return_inverse=True,return_counts=True)
                self._pairs[d]=[
                    (int(key[0]),int(key[1]),sub[inv==i])
                    for i,key in enumerate(unique) if key[0]>=0 and key[1]>=0
                ]
                self._pairs[d].sort(key=lambda p:-len(p[2]))
            else:self._pairs[d]=[]
        self._mode_cache={}
        self.gt_by_element={}
        f=folder/'GT_EVALUATION'/'GT_DPG_ELEMENTS.csv'
        if f.is_file():
            with f.open(encoding='utf-8-sig',newline='') as stream:
                for row in csv.DictReader(stream):
                    self.gt_by_element[(row['domain'],int(row['right_element_id']))]=row

    def pairs(self,domain,mode,kind='All'):
        pairs=self._pairs[domain]
        # For normal element pairs exclude DPG's unclassified label 0.
        # For seam->interior diagnostics keep label-0 observations visible,
        # so invalid-looking evidence is not silently hidden from the user.
        if kind!='Boundary to interior':pairs=[p for p in pairs if p[0]>0 and p[1]>0]
        if kind!='All':
            needed=1 if kind=='Boundary to interior' else 0
            if 'kind' in self.matches:
                pairs=[(l,r,idx[self.matches['kind'][idx]==needed]) for l,r,idx in pairs]
                pairs=[(l,r,idx) for l,r,idx in pairs if len(idx)]
            elif needed==1:pairs=[]
        if mode=='Pairs':return [(l,r,idx) for l,r,idx in pairs]
        side='left' if mode=='Left only' else 'right'
        col=0 if side=='left' else 1
        owned={p[col] for p in pairs}
        existing=np.unique(self.labels[f'{side}_{domain}'])
        return [(int(a),-1,np.empty(0,np.int32)) if side=='left' else
                (-1,int(a),np.empty(0,np.int32)) for a in existing if int(a)>0 and int(a) not in owned]

    def project_mask(self,side,mask):
        """Continuous inverse planar projection of one source DPG pixel set.

        This DIAGNOSTIC uses the same continuous mapping as the V4 midpoint.
        The old V3.1 scatter of rounded source pixel centers left artificial
        red/blue sampling gaps when sheets were stretched/shrunk.
        Only original member pixels and their already solved plane charts are
        eligible; no invented image-space interpolation across DPG masks.
        """
        mask=np.asarray(mask,bool)
        source=self.world[f'{side}_plane']
        active=mask & self.valid[side] & (source>=0)
        out=np.zeros((self.h,self.w),bool)
        if not np.any(active):return out
        y,x=np.mgrid[0:self.h,0:self.w].astype(np.float32)
        f=self.camera['focal'];B=self.camera['baseline']
        u=(x-self.camera['cx'])/f
        v=(y-self.camera['cy'])/f
        side_sign=1. if side=='left' else -1.
        src_mask=mask.astype(np.uint8)
        src_plane=source.astype(np.float32)
        for k in np.unique(source[active]):
            n=np.asarray(self.world['planes'][int(k)],np.float32)
            invz=n[0]*u+n[1]*v+n[2]
            target_x=(x+side_sign*.5*f*B*invz).astype(np.float32)
            ok=(target_x>=0)&(target_x<=self.w-1)&(invz>1.e-6)
            supported=cv2.remap(src_mask,target_x,y,cv2.INTER_NEAREST,
                                 borderMode=cv2.BORDER_CONSTANT,borderValue=0)>0
            assigned=cv2.remap(src_plane,target_x,y,cv2.INTER_NEAREST,
                                borderMode=cv2.BORDER_CONSTANT,borderValue=-1)==int(k)
            out|=ok&supported&assigned
        return out

    def transform_rgb(self,side,domain,*,by='plane',rgb_under=False,boundaries=True):
        """Colour native DPG pixels by ALREADY solved midpoint geometric chart.

        Plane grouping means the same global plane map, NOT object or surface
        identity. A single DPG element may have several colours / plane pieces.
        """
        k=(side,domain,by,rgb_under,boundaries)
        if k in self._mode_cache:return self._mode_cache[k]
        if domain=='All':
            frames=[self.transform_rgb(side,d,by=by,rgb_under=rgb_under,boundaries=boundaries)
                    for d in DOMAINS]
            out=np.vstack(frames)
            for i,d in enumerate(DOMAINS):
                cv2.rectangle(out,(2,i*self.h+2),(125,i*self.h+29),(13,15,20),-1)
                cv2.putText(out,d,(11,i*self.h+22),cv2.FONT_HERSHEY_SIMPLEX,.65,(255,255,255),2,cv2.LINE_AA)
            self._mode_cache[k]=out
            return out
        original=self.rgb[side]
        labels=self.labels[f'{side}_{domain}']
        if by=='surface':
            arr=self.identity.get(f'{side}_surface_id')
            if arr is None:raise ValueError('This result has no surface_identity.npz')
        else:arr=self.world[f'{side}_plane']
        usable=(labels>0)&(arr>=0)&self.valid[side]
        out=original.copy() if rgb_under else np.full_like(original,(29,32,38))
        if np.any(usable):
            for group in np.unique(arr[usable]):
                colour=np.asarray(palette(int(group)),np.uint8)
                on=usable&(arr==group)
                if rgb_under:
                    out[on]=np.rint(original[on].astype(np.float32)*.35+colour*.65).astype(np.uint8)
                else:out[on]=colour
        if boundaries:out[seam(labels)]=(7,8,12)
        self._mode_cache[k]=out
        return out


class ZoomCanvas(ttk.Frame):
    def __init__(self,parent,description,click=None):
        super().__init__(parent)
        self.label=ttk.Label(self,text=description)
        self.label.pack(fill='x',padx=4,pady=(2,0))
        self.canvas=tk.Canvas(self,bg='#151820',highlightthickness=1,highlightbackground='#4d545b')
        self.canvas.pack(fill='both',expand=True,padx=3,pady=3)
        self.image=None;self.photo=None
        self.scale=0.;self.pan=np.zeros(2,np.float64);self.drag=None;self.on_click=click
        self.canvas.bind('<Configure>',lambda _:self.paint())
        self.canvas.bind('<MouseWheel>',self.wheel)
        self.canvas.bind('<Button-4>',lambda e:self.wheel(e,1))
        self.canvas.bind('<Button-5>',lambda e:self.wheel(e,-1))
        self.canvas.bind('<ButtonPress-1>',self.start)
        self.canvas.bind('<B1-Motion>',self.move)
        self.canvas.bind('<ButtonRelease-1>',self.release)
        self.canvas.bind('<Double-Button-1>',lambda _:self.reset())

    def set_image(self,img,reset=False):
        if img is None:return
        img=np.asarray(img,np.uint8)
        changed=self.image is None or self.image.shape[:2]!=img.shape[:2]
        self.image=img
        if reset or changed:self.scale=0.;self.pan[:]=0
        self.paint()

    def reset(self):
        self.scale=0.;self.pan[:]=0;self.paint()

    def focus_mask(self,mask,margin=16):
        """Show the selected native element / midpoint union."""
        yy,xx=np.nonzero(mask)
        cw=self.canvas.winfo_width();ch=self.canvas.winfo_height()
        if len(xx)==0 or cw<20 or ch<20:
            self.reset();return
        x0=max(0,int(xx.min())-margin);x1=min(self.image.shape[1],int(xx.max())+margin+1)
        y0=max(0,int(yy.min())-margin);y1=min(self.image.shape[0],int(yy.max())+margin+1)
        self.scale=float(np.clip(min((cw-12)/max(1,x1-x0),(ch-12)/max(1,y1-y0)),.04,16.))
        self.pan[:]=[(cw-(x0+x1)*self.scale)/2.,(ch-(y0+y1)*self.scale)/2.]
        self.paint()

    def xy(self,event):
        if self.image is None or self.scale<=0:return None
        p=(np.array([event.x,event.y])-self.pan)/self.scale
        x,y=np.floor(p).astype(int)
        if not (0<=x<self.image.shape[1] and 0<=y<self.image.shape[0]):return None
        return x,y

    def start(self,e):self.drag=(e.x,e.y,e.x,e.y)
    def move(self,e):
        if self.drag is None:return
        px,py,ax,ay=self.drag
        self.pan+=np.array([e.x-px,e.y-py],np.float64)
        self.drag=(e.x,e.y,ax,ay)
        self.paint()
    def release(self,e):
        if self.drag is None:return
        _,_,ax,ay=self.drag
        self.drag=None
        if abs(e.x-ax)+abs(e.y-ay)<=4 and self.on_click is not None:
            p=self.xy(e)
            if p is not None:self.on_click(p)

    def wheel(self,e,override=None):
        if self.image is None:return
        direction=override if override is not None else (1 if e.delta>0 else -1)
        previous=max(.04,self.scale)
        self.scale=float(np.clip(previous*(1.22 if direction>0 else 1/1.22),.04,32.))
        p=np.array([e.x,e.y],np.float64)
        self.pan=p-(p-self.pan)*self.scale/previous
        self.paint()

    def paint(self):
        if self.image is None:return
        cv=self.canvas
        cw=max(1,cv.winfo_width());ch=max(1,cv.winfo_height())
        if cw<20 or ch<20:return
        h,w=self.image.shape[:2]
        if self.scale<=0:
            self.scale=max(.04,min(cw/w,ch/h))
            self.pan[:]=[(cw-w*self.scale)/2,(ch-h*self.scale)/2]
        s=self.scale
        x0=max(0,int(np.floor(-self.pan[0]/s))-2)
        x1=min(w,int(np.ceil((cw-self.pan[0])/s))+2)
        y0=max(0,int(np.floor(-self.pan[1]/s))-2)
        y1=min(h,int(np.ceil((ch-self.pan[1])/s))+2)
        cv.delete('all')
        if x1<=x0 or y1<=y0:return
        crop=self.image[y0:y1,x0:x1]
        ow=max(1,int(round((x1-x0)*s)));oh=max(1,int(round((y1-y0)*s)))
        method=Image.Resampling.NEAREST if s>=1 else Image.Resampling.BILINEAR
        self.photo=ImageTk.PhotoImage(Image.fromarray(crop).resize((ow,oh),method))
        cv.create_image(round(self.pan[0]+x0*s),round(self.pan[1]+y0*s),anchor='nw',image=self.photo)


def _highlight(rgb,labels,label,col,points=None):
    if label<0:return (rgb.astype(np.float32)*.25).astype(np.uint8)
    mask=labels==label
    out=np.rint(rgb.astype(np.float32)*.25).astype(np.uint8)
    if np.any(mask):
        out[mask]=np.rint(rgb[mask].astype(np.float32)*.75+col.astype(np.float32)*.25).astype(np.uint8)
        out[inner_contour(mask)]=col
    if points is not None and len(points):
        for x,y in np.rint(points[::max(1,len(points)//1200)]).astype(np.int32):
            if 0<=x<out.shape[1] and 0<=y<out.shape[0]:out[y,x]=GREEN
    return out


class PairInspector(tk.Toplevel):
    def __init__(self,parent,results):
        super().__init__(parent)
        self.data=results;self.title('Stereo element pairs - original cameras and midpoint')
        self.geometry('1460x960');self.minsize(830,620)
        self.domain=tk.StringVar(value='L');self.mode=tk.StringVar(value='Pairs')
        self.matchkind=tk.StringVar(value='All')
        self.show_points=tk.BooleanVar(value=False)
        self.status=tk.StringVar(value='Select an element pair or click an element in the camera images.')
        self.entries=[];self.selected=None
        top=ttk.Frame(self,padding=6);top.pack(fill='x')
        ttk.Label(top,text='Domain').pack(side='left')
        dc=ttk.Combobox(top,textvariable=self.domain,values=DOMAINS,width=6,state='readonly')
        dc.pack(side='left',padx=4);dc.bind('<<ComboboxSelected>>',lambda _:self.rebuild())
        ttk.Label(top,text='Mode').pack(side='left',padx=(16,3))
        mc=ttk.Combobox(top,textvariable=self.mode,values=('Pairs','Left only','Right only'),width=13,state='readonly')
        mc.pack(side='left');mc.bind('<<ComboboxSelected>>',lambda _:self.rebuild())
        ttk.Label(top,text='Correspondence type').pack(side='left',padx=(12,3))
        kc=ttk.Combobox(top,textvariable=self.matchkind,values=('All','Boundary to boundary','Boundary to interior'),width=15,state='readonly')
        kc.pack(side='left');kc.bind('<<ComboboxSelected>>',lambda _:self.rebuild())
        ttk.Checkbutton(top,text='Show matched boundary samples',variable=self.show_points,command=self.draw).pack(side='left',padx=14)
        ttk.Button(top,text='Save 3 PDFs',command=self.export_pdf).pack(side='right',padx=3)
        ttk.Button(top,text='Save 3 PNGs',command=self.export_png).pack(side='right',padx=3)
        ttk.Button(top,text='Previous',command=lambda:self.advance(-1)).pack(side='right',padx=3)
        ttk.Button(top,text='Next',command=lambda:self.advance(1)).pack(side='right',padx=3)
        main=ttk.Panedwindow(self,orient='horizontal');main.pack(fill='both',expand=True)
        sidebar=ttk.Frame(main,width=230);main.add(sidebar,weight=0)
        ttk.Label(sidebar,text='Elements and partial matches').pack(anchor='w',padx=5)
        lf=ttk.Frame(sidebar);lf.pack(fill='both',expand=True)
        scroll=ttk.Scrollbar(lf,orient='vertical')
        self.pair_list=tk.Listbox(lf,width=35,exportselection=False,yscrollcommand=scroll.set,font=('Consolas',9))
        scroll.configure(command=self.pair_list.yview)
        self.pair_list.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        self.pair_list.bind('<<ListboxSelect>>',lambda _:self.pick())
        content=ttk.Frame(main);main.add(content,weight=1)
        cols=ttk.Frame(content);cols.pack(fill='both',expand=True)
        self.left=ZoomCanvas(cols,'Left RGB + selected element (blue)',click=lambda p:self.select_by_click('left',p))
        self.right=ZoomCanvas(cols,'Right RGB + selected element (red)',click=lambda p:self.select_by_click('right',p))
        self.left.pack(side='left',fill='both',expand=True);self.right.pack(side='left',fill='both',expand=True)
        self.combined=ZoomCanvas(content,'Midpoint: blue=left, red=right, green=shared surface overlap (black background)')
        self.combined.pack(fill='both',expand=True)
        ttk.Label(self,textvariable=self.status,wraplength=1380).pack(fill='x',padx=9,pady=5)
        self.rebuild()

    def rebuild(self):
        d=self.domain.get();mode=self.mode.get()
        self.entries=self.data.pairs(d,mode,self.matchkind.get())
        self.pair_list.delete(0,'end')
        for l,r,ids in self.entries:
            self.pair_list.insert('end',f'L {l:5}  R {r:5}   n={len(ids):4}')
        if self.entries:
            self.pair_list.selection_set(0);self.pair_list.see(0);self.pick()
        else:
            self.selected=None
            self.status.set('No observations of the selected type in this domain.')

    def advance(self,inc):
        if not self.entries:return
        sels=self.pair_list.curselection();i=(sels[0] if sels else 0)+inc
        i=max(0,min(len(self.entries)-1,i))
        self.pair_list.selection_clear(0,'end');self.pair_list.selection_set(i)
        self.pair_list.see(i);self.pick()

    def select_by_click(self,side,p):
        x,y=p;d=self.domain.get();label=int(self.data.labels[f'{side}_{d}'][y,x])
        if label<=0:return
        candidates=[i for i,e in enumerate(self.entries) if e[0 if side=='left' else 1]==label]
        if not candidates:
            self.status.set(f'{side} {d}:{label} has no correspondence with the current filters.')
            return
        index=candidates[0]
        self.pair_list.selection_clear(0,'end');self.pair_list.selection_set(index)
        self.pair_list.see(index);self.pick()

    def pick(self):
        ids=self.pair_list.curselection()
        if not ids:return
        self.selected=self.entries[int(ids[0])]
        self.draw()

    def draw(self):
        if self.selected is None:return
        l,r,idx=self.selected;d=self.domain.get();data=self.data
        source_pts=data.matches['left_xy'][idx] if self.show_points.get() else None
        target_pts=data.matches['right_xy'][idx] if self.show_points.get() else None
        a=_highlight(data.rgb['left'],data.labels['left_'+d],l,BLUE,source_pts)
        b=_highlight(data.rgb['right'],data.labels['right_'+d],r,RED,target_pts)
        self.left.set_image(a);self.right.set_image(b)
        # Centre each view on the selected element when browsing pairs.
        self.left.focus_mask(data.labels['left_'+d]==l) if l>=0 else self.left.reset()
        self.right.focus_mask(data.labels['right_'+d]==r) if r>=0 else self.right.reset()
        maskl=data.project_mask('left',data.labels['left_'+d]==l) if l>=0 else np.zeros((data.h,data.w),bool)
        maskr=data.project_mask('right',data.labels['right_'+d]==r) if r>=0 else np.zeros((data.h,data.w),bool)
        common=maskl&maskr
        comp=np.zeros((data.h,data.w,3),np.uint8)
        comp[maskl]=BLUE;comp[maskr]=RED;comp[common]=GREEN
        self.combined.set_image(comp)
        self.combined.focus_mask(maskl|maskr)
        union=int(np.count_nonzero(maskl|maskr));both=int(common.sum())
        iou=both/max(union,1)
        meanconf=float(data.matches['confidence'][idx].mean()) if len(idx) else 0.
        rms=float('nan');segment_rms=[]
        if len(idx)>=3:
            xy=np.asarray(data.matches['left_xy'][idx],np.float64)
            disp=xy[:,0]-np.asarray(data.matches['right_xy'][idx,0],np.float64)
            A=np.column_stack((np.ones(len(idx)),(xy[:,0]-data.w/2)/data.w,(xy[:,1]-data.h/2)/data.h))
            fit=np.linalg.lstsq(A,disp,rcond=None)[0]
            rms=float(np.sqrt(np.mean((disp-A@fit)**2)))
            seg=data.matches.get('segment_id')
            if seg is not None:
                for sg in np.unique(seg[idx]):
                    if sg<0:continue
                    part=np.flatnonzero(seg[idx]==sg)
                    if len(part)<4:continue
                    model=np.linalg.lstsq(A[part],disp[part],rcond=None)[0]
                    segment_rms.append(float(np.sqrt(np.mean((disp[part]-A[part]@model)**2))))
        arcs=f' | {len(segment_rms)} partial arcs; median arc RMS {np.median(segment_rms):.2f} px' if segment_rms else ''
        zero_note=(' WARNING: label 0 is unclassified, not a verified segment. ' if (l==0 or r==0) else '')
        gtrow=data.gt_by_element.get((d,r))
        gtnote=(' | GT right-to-left element median '+gtrow['median_px']+' px, '+
                'MAE '+gtrow['mae_px']+' px, n='+gtrow['n']+' (whole right element)') if gtrow and gtrow['n']!='0' else ''
        self.status.set(f'{d} | left element {l} | right element {r} | partial-boundary samples {len(idx)} | '+zero_note+
            f'confidence {meanconf:.2f} | pair affine RMS {rms:.2f} px{arcs} | '
            f'midpointissa L={int(maskl.sum())} px, R={int(maskr.sum())} px, '
            f'overlap={both} px (IoU={iou:.3f}). {gtnote} '\
            'Projection overlap alone does not establish physical surface identity. '
            'Wheel: zoom; drag: pan; double click: fit.')

    def export_pdf(self):
        if self.selected is None:return
        folder=filedialog.askdirectory(title='Choose directory for three pair PDF images',parent=self)
        if not folder:return
        from result_browser import write_single_image_pdf, _read_json, _dataset_tag, _safe
        report=_read_json(Path(self.data.path)/'REPORT.json')
        ds=_dataset_tag(report.get('dataset') or Path(self.data.path).parent.name)
        frame=int(report.get('frame',0))
        method=_safe(report.get('segmentation_method','dpg'))
        l,r,_=self.selected
        prefix=f'{ds}__frame_{frame:06d}__{method}__{self.domain.get()}__L{l}__R{r}'
        for name,view in (('pair_left',self.left),('pair_right',self.right),('pair_midpoint',self.combined)):
            if view.image is not None:
                write_single_image_pdf(Image.fromarray(view.image),Path(folder)/f'{prefix}__{name}.pdf')

    def export_png(self):
        if self.selected is None:return
        folder=filedialog.askdirectory(title='Minne elementtiparin kolme kuvaa tallennetaan?',parent=self)
        if not folder:return
        l,r,_=self.selected
        base=f'{self.domain.get()}_L{l}_R{r}'
        for name,view in (('left',self.left),('right',self.right),('midpoint_alueet',self.combined)):
            if view.image is not None:Image.fromarray(view.image).save(Path(folder)/f'{base}_{name}.png')
        (Path(folder)/f'{base}_tiedot.txt').write_text(self.status.get(),encoding='utf8')


class TransformInspector(tk.Toplevel):
    def __init__(self,parent,results):
        super().__init__(parent)
        self.data=results;self.title('Stereo transform colors - left / right')
        self.geometry('1440x910');self.minsize(800,560)
        self.domain=tk.StringVar(value='L')
        self.group=tk.StringVar(value='Plane transform')
        self.under=tk.BooleanVar(value=False)
        self.draw_edges=tk.BooleanVar(value=True)
        self.status=tk.StringVar(value='The same color marks the same solved 3D plane transform, not necessarily the same object.')
        top=ttk.Frame(self,padding=6);top.pack(fill='x')
        ttk.Label(top,text='Domain').pack(side='left')
        dc=ttk.Combobox(top,textvariable=self.domain,values=(*DOMAINS,'All'),state='readonly',width=9)
        dc.pack(side='left',padx=5);dc.bind('<<ComboboxSelected>>',lambda _:self.refresh(reset=True))
        ttk.Label(top,text='Color grouping').pack(side='left',padx=(14,3))
        options=('Plane transform','Surface identity') if results.identity else ('Plane transform',)
        group=ttk.Combobox(top,textvariable=self.group,values=options,state='readonly',width=18)
        group.pack(side='left');group.bind('<<ComboboxSelected>>',lambda _:self.refresh())
        ttk.Checkbutton(top,text='Show RGB background',variable=self.under,command=self.refresh).pack(side='left',padx=10)
        ttk.Checkbutton(top,text='Segment boundaries',variable=self.draw_edges,command=self.refresh).pack(side='left')
        ttk.Button(top,text='Fit images',command=self.reset_zoom).pack(side='right')
        ttk.Button(top,text='Save 2 PDFs',command=self.export_pdf).pack(side='right',padx=8)
        ttk.Button(top,text='Save 2 PNGs',command=self.export_png).pack(side='right',padx=8)
        pane=ttk.Panedwindow(self,orient='horizontal');pane.pack(fill='both',expand=True)
        self.left=ZoomCanvas(pane,'Left - same transform uses same color',click=lambda p:self.inspect('left',p))
        self.right=ZoomCanvas(pane,'Right - colors correspond to left',click=lambda p:self.inspect('right',p))
        pane.add(self.left,weight=1);pane.add(self.right,weight=1)
        bottom=ttk.Frame(self,padding=5);bottom.pack(fill='x')
        ttk.Label(bottom,textvariable=self.status,wraplength=1360).pack(anchor='w')
        self.legend=tk.Canvas(bottom,height=34,highlightthickness=0)
        self.legend.pack(fill='x',pady=3)
        self.refresh(reset=True)

    def reset_zoom(self):self.left.reset();self.right.reset()
    def export_pdf(self):
        folder=filedialog.askdirectory(title='Choose directory for transform PDF images',parent=self)
        if not folder:return
        from result_browser import write_single_image_pdf, _read_json, _dataset_tag, _safe
        report=_read_json(Path(self.data.path)/'REPORT.json')
        ds=_dataset_tag(report.get('dataset') or Path(self.data.path).parent.name)
        frame=int(report.get('frame',0))
        method=_safe(report.get('segmentation_method','dpg'))
        d=_safe(self.domain.get())
        mode='surface' if self.group.get()=='Surface identity' else 'plane'
        for side,view in (('left',self.left),('right',self.right)):
            if view.image is not None:
                name=f'{ds}__frame_{frame:06d}__{method}__{d}__{mode}__transforms_{side}.pdf'
                write_single_image_pdf(Image.fromarray(view.image),Path(folder)/name)

    def export_png(self):
        folder=filedialog.askdirectory(title='Choose directory for transform PNG images',parent=self)
        if not folder:return
        label=self.domain.get();kind='surface' if self.group.get()=='Surface identity' else 'plane'
        for side,view in (('left',self.left),('right',self.right)):
            if view.image is not None:Image.fromarray(view.image).save(Path(folder)/f'{label}_{kind}_{side}.png')
    def inspect(self,side,p):
        x,y=p;d=self.domain.get()
        if d=='All':
            idx=min(2,int(y//self.data.h));d=DOMAINS[idx];y%=self.data.h
        if y>=self.data.h:return
        elem=int(self.data.labels[f'{side}_{d}'][y,x])
        pid=int(self.data.world[f'{side}_plane'][y,x])
        sidarr=self.data.identity.get(f'{side}_surface_id')
        sid=int(sidarr[y,x]) if sidarr is not None else -1
        model='world plane' if self.group.get()=='Plane transform' else 'surface identity'
        self.status.set(f'{side.upper()} | domain {d} | x={x}, y={y} | original segment {elem} | '
                        f'3D plane {pid} | shared surface ID {sid} | coloring: {model}. '
                        'The same plane transform alone does not prove physical surface identity.')

    def refresh(self,reset=False):
        domain=self.domain.get();kind='surface' if self.group.get()=='Surface identity' else 'plane'
        try:
            self.left.set_image(self.data.transform_rgb('left',domain,by=kind,rgb_under=self.under.get(),boundaries=self.draw_edges.get()),reset=reset)
            self.right.set_image(self.data.transform_rgb('right',domain,by=kind,rgb_under=self.under.get(),boundaries=self.draw_edges.get()),reset=reset)
        except Exception as e:
            messagebox.showerror('Transform colors',str(e),parent=self)
            return
        count=(len(np.unique(self.data.world['planes'],axis=0)) if kind=='plane' else
               len(np.unique(np.r_[self.data.identity['left_surface_id'].reshape(-1)[::50],
                                  self.data.identity['right_surface_id'].reshape(-1)[::50]])))
        self.status.set(f'Colors represent {"shared 3D plane transform" if kind=="plane" else "surface identity"}. '
                        f'A segment may be divided across several differently colored regions. '
                        'Kaikki = L/VC/CC allekkain molemmissa kameroissa; ulkoreuna ei ole DPG-raja.')
        canvas=self.legend;canvas.delete('all')
        count=len(self.data.world['planes']) if kind=='plane' else min(20,count)
        for i in range(min(count,30)):
            x=10+i*43
            canvas.create_rectangle(x,3,x+20,22,fill='#%02x%02x%02x'%palette(i),outline='')
            canvas.create_text(x+23,12,text=str(i),anchor='w')


def show_pair_inspector(root,path):
    return PairInspector(root,Results(path))


def show_transform_inspector(root,path):
    return TransformInspector(root,Results(path))
