"""Single public release identifier shared by GUI, reports, and scripts."""
__version__ = '1.0.0'
