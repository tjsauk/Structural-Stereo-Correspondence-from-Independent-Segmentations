"""Clear V8 GUI workflows. Non-learning stereo; GT strictly post-hoc.

Each job creates its own folder and incremental MANIFEST.json. All ordinary
image exports are one full-resolution PDF per image. Disparity batch produces
PNG to support fast overnight triage, per user requirement.
"""
from __future__ import annotations
import json, time, csv, re, traceback, shutil
from pathlib import Path
from PIL import Image
import numpy as np
from release_info import __version__
from dataset_io import Dataset
from disparity_baseline import run_batch as disparity_batch
from gt_element_eval import discover_gt, _read_field, measure_result
from result_browser import export_frame, export_compact_frame, export_left_coordinate_boundary_frame, metrics_for_method
from segmentation_baselines import METHODS

MODES=('dpg_one','dpg_time','compare_one','disparity_range','all_one','all_range','all_one_left_overlay')
METHODS3=('dpg','felzenszwalb','slic')


def safe(s):return re.sub(r'[^a-zA-Z0-9_.-]+','_',str(s)).strip('._') or 'dataset'


def dataset_label(dataset):
    p=Path(dataset)
    return safe(p.stem if p.suffix.lower()=='.zip' else p.name)


def _read_names(ds):
    if ds.z is not None:return [n for n in ds.z.namelist() if not n.endswith('/')]
    return [str(p.relative_to(ds.path)).replace('\\','/') for p in ds.path.rglob('*') if p.is_file()]


def _gt_name_has_side(name):
    n='/'+str(name).lower().replace('\\','/')
    if any(w in n for w in ('/cam1/','/right/','/r_depth/','right_depth','depth_right','disparity_right','disp_right','/cam1_','depth_cam1','disp_cam1','gt_cam1')):return 'right'
    if any(w in n for w in ('/cam0/','/left/','/l_depth/','left_depth','depth_left','disparity_left','disp_left','/cam0_','depth_cam0','disp_cam0','gt_cam0')):return 'left'
    return None


def detect_gt(ds:Dataset,frame:int):
    """Resolve the exact GT file for a camera-indexed frame, including timestamps.

    The checked file bytes are cached for immediate use by measure_result;
    GT is never passed into the stereo solver.
    """
    hints=getattr(ds,'gt_hints',{}) or {}
    side=hints.get('side')
    side_source='metadata' if side in ('left','right') else 'default_left_cam0_depth0'
    if side not in ('left','right'):
        # A single explicitly named right-hand depth source is honored. When
        # both sides are present or the source is neutral, default to LEFT.
        names=getattr(ds,'_gt_inventory_side_names',None)
        if names is None:
            names=_read_names(ds)
            ds._gt_inventory_side_names=names
        names=[n.lower().replace('\\','/') for n in names
               if any(t in n.lower() for t in ('depth','disparity','/gt/','groundtruth'))]
        left_exists=any(any(t in n for t in ('/depth0/','/cam0/','/left/','depth_cam0','depth_left','left_depth','gt_cam0')) for n in names)
        right_exists=any(any(t in n for t in ('/depth1/','/cam1/','/right/','depth_cam1','depth_right','right_depth','gt_cam1')) for n in names)
        if right_exists and not left_exists:
            side='right'
            side_source='GT_filename_only_right_available'
        else:
            side='left'
    try:
        fn,raw=discover_gt(ds.path,int(frame),side,dataset=ds)
    except Exception as exc:
        return None,'GT depth lookup failed: '+str(exc)
    kind=hints.get('kind')
    if not kind:
        name=fn.lower().replace('\\','/')
        if 'disparity' in name or '/disp/' in name or 'disp_' in name:
            if 'disp_16' in name or 'disparity_16' in name:kind='disp_16'
            elif 'disp_256' in name or 'disparity_256' in name:kind='disp_256'
            else:return None,'Disparity GT scale is not declared.'
        elif 'depth' in name:
            try:
                arr=np.asarray(_read_field(raw,fn))
                if np.issubdtype(arr.dtype,np.floating):kind='depth_m'
                elif np.issubdtype(arr.dtype,np.integer):kind='depth_mm'
                else:return None,'GT data type is not a supported depth representation.'
            except Exception as exc:
                return None,'GT depth decoding failed: '+str(exc)
        else:return None,'GT filename does not identify depth or disparity encoding.'
    # EuRoC/ZED depth0: integer depth PNG in millimetres, 0 is invalid.
    # Hints may contain depth_scale=1000 (raw counts per metre), which is
    # consistent with divide-by-1000, not multiply-by-1000.
    cache={'frame':int(frame),'name':fn,'raw':raw,'side':side}
    ds._gt_latest_resolved=cache
    return dict(kind=kind,side=side,side_source=side_source,file=fn,
                source=str(hints.get('source_file','depth0_or_file_type'))),None


def try_gt(out,ds:Dataset,frame:int,progress=lambda _:None):
    options,reason=detect_gt(ds,frame)
    result={'available':False,'reason':reason,'frame':int(frame)}
    if options is not None:
        try:
            cache=getattr(ds,'_gt_latest_resolved',None)
            exact_gt=(cache['name'],cache['raw']) if cache and cache['frame']==int(frame) else None
            p,report=measure_result(out,ds.path,gt_kind=options['kind'],gt_side=options['side'],
                                    gt_file=exact_gt,gt_dataset=ds)
            result={'available':True,'frame':int(frame),'options':options,
                    'report_dir':str(p),'total':report.get('total',{}),'coverage_pct':report.get('GT_coverage_pct')}
            progress(f'GT complete: {options["file"]} ({options["kind"]}, {options["side"]}) | MAE {result["total"].get("mae_px")} px')
        except Exception as exc:
            result={'available':False,'frame':int(frame),'reason':f'GT evaluation failed: {exc}', 'options':options}
    if not result['available']:progress(f'GT unavailable: {result["reason"]}')
    (Path(out)/'GT_AUTO_STATUS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result



def append_pdf_index(job:Path, paths, frame:int):
    if not paths:return
    path=Path(job)/'figures'/'PDF_INDEX.csv'
    path.parent.mkdir(parents=True,exist_ok=True)
    prior=path.exists()
    with path.open('a',encoding='utf-8-sig' if not prior else 'utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['frame','method','image_type','pdf','latex_includegraphics'])
        if not prior:w.writeheader()
        for p in paths:
            file=Path(p)
            parts=file.stem.split('__')
            rel=file.relative_to(job).as_posix()
            w.writerow({'frame':int(frame),'method':parts[-2] if len(parts)>=4 else '',
                'image_type':parts[-1] if len(parts)>=4 else '',
                'pdf':rel,
                'latex_includegraphics':r'\includegraphics[width=\linewidth]{\detokenize{'+rel+'}}'})

def _save_json(path,info):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(info,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    tmp.replace(path)


def _summary_row_for_frame(frame:int, record:dict[str,Path]):
    row={'frame':int(frame)}
    for method in METHODS3:
        metrics=metrics_for_method(method, record.get(method))
        for key,val in metrics.items():
            row[f'{method}_{key}']=val
    return row


def _append_summary_csv(path:Path, row:dict):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    prior=path.exists()
    with path.open('a',encoding='utf-8-sig' if not prior else 'utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(row.keys()))
        if not prior: w.writeheader()
        w.writerow(row)


def run_workflow(mode,dataset,one,start,end,output_root,*,solver_mode='experimental',disp_search=256,disp_block=5,
                 cancel=lambda:False,progress=lambda _:None, evaluate_gt=True):
    """Run one of six GUI workflows, return (job_folder, manifest)."""
    if mode not in MODES:raise ValueError('Unknown workflow: '+mode)
    ds=Dataset(dataset)
    tag=dataset_label(dataset)
    frames=[f for f in ds.frames if int(start)<=f<=int(end)] if mode in ('dpg_time','disparity_range','all_range') else [int(one)]
    if not frames:raise ValueError(f'No stereo pairs in frame range {start}-{end}')
    if mode not in ('dpg_time','disparity_range','all_range') and int(one) not in ds.frames:raise ValueError(f'Frame {one} ei kuulu datasettiin')
    timestamp=time.strftime('%Y%m%d_%H%M%S')
    job=Path(output_root).expanduser()/tag/f'{mode}_{frames[0]:06d}_{frames[-1]:06d}_{timestamp}'
    job.mkdir(parents=True,exist_ok=True)
    manifest={'version':__version__,'dataset':str(ds.path),'dataset_name':tag,'mode':mode,
              'frames':frames,'completed':[],'failures':[], 'gt':[], 'outputs':{},
              'solver_mode':solver_mode,'state':'running','time_created':timestamp,
              'calibration':ds.calibration,'gt_hints':ds.gt_hints}
    _save_json(job/'JOB.json',manifest)
    if mode=='disparity_range':
        # Keep pure-disparity batch as PNG, with diagnostic artifacts and resume support.
        folder,stats=disparity_batch(ds.path,job,stop_requested=cancel,progress=progress,
            num_disparities=disp_search,block_size=disp_block,start=frames[0],end=frames[-1],skip_existing=True)
        manifest['outputs']['disparity_png']=str(folder)
        manifest['completed']=[int(p.stem[6:]) for p in folder.glob('frame_*.png') if p.stem.startswith('frame_')]
        manifest['batch_report']=stats
        manifest['state']='stopped' if cancel() else 'completed'
        _save_json(job/'JOB.json',manifest)
        return job,manifest
    if mode=='dpg_time':
        from run_sequence import run_sequence
        session=job/'temporal_session'
        run_sequence(ds.path,frames[0],frames[-1],session,solver_mode=solver_mode,
                     stop_requested=cancel,progress=progress)
        manifest['temporal_session']=str(session)
        for fr in frames:
            if cancel():break
            result=session/f'frame_{fr:06d}'
            if not (result/'REPORT.json').exists():continue
            if evaluate_gt:manifest['gt'].append(dict(method='dpg',**try_gt(result,ds,fr,progress)))
            exports=export_frame({'dpg':result},tag,fr,job/'figures',include_details=True,progress=progress)
            append_pdf_index(job,exports,fr)
            manifest['completed'].append(fr)
            manifest['outputs'][str(fr)]={'dpg':str(result),'pdf_count':len(exports)}
            _save_json(job/'JOB.json',manifest)
    else:
        from run_element_stereo import solve as solve_stereo
        modes={'dpg_one':('dpg',),'compare_one':('dpg',),
               'all_one':METHODS3,'all_range':METHODS3,'all_one_left_overlay':METHODS3}
        methods=modes[mode]
        for fr in frames:
            if cancel():break
            record={}
            for method in methods:
                if cancel():break
                out=job/f'frame_{fr:06d}'/method
                out.mkdir(parents=True,exist_ok=True)
                try:
                    progress(f'Frame {fr}: {method} - segmentation, matching, midpoint')
                    solve_stereo(ds.path,fr,out,solver_mode=solver_mode,segmentation_method=method,
                                 progress=lambda msg,fr=fr,method=method: progress(f'{fr}/{method}: {msg}'))
                    record[method]=out
                    if evaluate_gt:manifest['gt'].append(dict(method=method,**try_gt(out,ds,fr,progress)))
                except Exception as exc:
                    manifest['failures'].append({'frame':fr,'method':method,'error':str(exc),'traceback':traceback.format_exc()})
                    progress(f'ERROR frame {fr}, {method}: {exc}')
                _save_json(job/'JOB.json',manifest)
            if mode=='compare_one' and not cancel():
                try:
                    progress(f'Frame {fr}: disparity SGBM + midpoint')
                    disp_folder,_=disparity_batch(ds.path,job/'disparity_cache',stop_requested=cancel,
                        progress=progress,num_disparities=disp_search,block_size=disp_block,
                        start=fr,end=fr,skip_existing=False)
                    png=disp_folder/f'frame_{fr:06d}.png'
                    if png.is_file():record['disparity']=png
                except Exception as exc:
                    manifest['failures'].append({'frame':fr,'method':'disparity','error':str(exc)})
                    progress(f'Disparity failed: {exc}')
            if record:
                try:
                    if mode=='all_range':
                        exports=export_compact_frame(record,tag,fr,job/'frames',progress=progress)
                        _append_summary_csv(job/'frame_summary.csv', _summary_row_for_frame(fr, record))
                    elif mode=='all_one_left_overlay':
                        exports=export_left_coordinate_boundary_frame(record,tag,fr,job/'figures',progress=progress)
                    else:
                        exports=export_frame(record,tag,fr,job/'figures',include_details=True,progress=progress)
                except Exception as exc:
                    manifest['failures'].append({'frame':fr,'method':'pdf_export','error':str(exc)})
                    exports=[];progress(f'PDF export failed: {exc}')
                append_pdf_index(job,exports,fr)
                if mode=='all_range':
                    manifest['outputs'][str(fr)]={'frame_folder':str(job/'frames'/f'frame_{fr:06d}'),'pdf_count':len(exports)}
                    # Low-storage batch mode: keep only the compact PDFs and summary CSV.
                    for m,p in list(record.items()):
                        try:
                            if Path(p).is_dir(): shutil.rmtree(p, ignore_errors=True)
                        except Exception:
                            pass
                else:
                    manifest['outputs'][str(fr)]={k:str(v) for k,v in record.items()}
                    manifest['outputs'][str(fr)]['pdf_count']=len(exports)
                manifest['completed'].append(fr)
                _save_json(job/'JOB.json',manifest)
    if manifest['failures']:
        (job/'ERRORS.json').write_text(json.dumps(manifest['failures'],ensure_ascii=False,indent=2),encoding='utf-8')
    manifest['state']='stopped' if cancel() else ('partial' if manifest['failures'] else 'completed')
    _save_json(job/'JOB.json',manifest)
    return job,manifest
