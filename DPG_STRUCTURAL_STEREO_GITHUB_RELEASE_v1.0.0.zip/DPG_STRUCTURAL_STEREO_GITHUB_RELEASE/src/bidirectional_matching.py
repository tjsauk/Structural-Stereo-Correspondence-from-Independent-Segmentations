"""Identical contour-arc stereo matching in both camera directions.

The right-to-left search is performed on horizontally mirrored, swapped
images so its nonnegative epipolar displacement has identical semantics.
Reciprocal hypotheses receive more confidence, but plausible unique/occluded
partial tracks are NOT discarded merely for lacking a reverse partner.
"""
import numpy as np
from scipy.spatial import cKDTree
from boundary_matching import BoundaryMatches
from element_encounter_v151 import match_element_encounters as experimental_encounters
from element_encounter_v151_legacy import match_element_encounters as conservative_encounters
from native_observation import DOMAINS


def match_both(images,obs,progress=lambda s:None, sample_stride=3,max_matches=24000,
               matcher_mode='conservative'):
    if matcher_mode not in ('conservative','experimental'):
        raise ValueError('matcher_mode')
    match_element_encounters=(experimental_encounters if matcher_mode=='experimental' else conservative_encounters)
    h,w=images[0].shape[:2]
    progress('Left to right: partial segment-boundary arcs')
    forward=match_element_encounters(images,obs,progress=progress,
                        sample_stride=sample_stride,max_matches=max_matches//2)
    progress('Right to left: symmetric correspondence pass')
    flipped=(images[1][:,::-1].copy(),images[0][:,::-1].copy())
    reverse_obs={}
    for dom in DOMAINS:
        reverse_obs[f'left_{dom}']=obs[f'right_{dom}'][:,::-1].copy()
        reverse_obs[f'right_{dom}']=obs[f'left_{dom}'][:,::-1].copy()
    backward=match_element_encounters(flipped,reverse_obs,progress=progress,
                        sample_stride=sample_stride,max_matches=max_matches//2)
    def recover(xy):
        result=np.asarray(xy,np.float32).copy()
        result[:,0]=(w-1)-result[:,0]
        return result
    bl=recover(backward.right_xy)
    br=recover(backward.left_xy)
    fl=forward.left_xy;fr=forward.right_xy
    conf_l=np.asarray(forward.confidence,np.float32).copy()
    conf_r=np.asarray(backward.confidence,np.float32).copy()
    forward_recip=np.zeros(len(fl),bool)
    reverse_recip=np.zeros(len(bl),bool)
    if len(fl) and len(bl):
        # A stereo hypothesis is reciprocal only when BOTH endpoints agree.
        q=cKDTree(bl).query(fl,k=1,distance_upper_bound=2.25)
        ids=q[1];dist=q[0]
        ok=ids<len(bl)
        valid_ix=np.flatnonzero(ok)
        target=np.linalg.norm(fr[valid_ix]-br[ids[valid_ix]],axis=1)<2.25
        good=valid_ix[target]
        forward_recip[good]=True
        reverse_recip[ids[good]]=True
    conf_l*=np.where(forward_recip,1.12,.73).astype(np.float32)
    conf_r*=np.where(reverse_recip,1.12,.73).astype(np.float32)
    nseg=max(-1,int(forward.segment_id.max()) if len(forward.segment_id) else -1)+1
    idsr=backward.segment_id.copy()
    idsr[idsr>=0]+=nseg
    segments=list(forward.segments)
    for item in backward.segments:
        row=dict(item)
        row['id']=int(row['id'])+nseg
        row['left'],row['right']=row['right'],row['left']
        segments.append(row)
    allmatches=BoundaryMatches(
        left_xy=np.concatenate((fl,bl)).astype(np.float32),
        right_xy=np.concatenate((fr,br)).astype(np.float32),
        domain=np.r_[forward.domain,backward.domain],
        left_owner=np.r_[forward.left_owner,backward.right_owner],
        right_owner=np.r_[forward.right_owner,backward.left_owner],
        confidence=np.clip(np.r_[conf_l,conf_r],.01,.99).astype(np.float32),
        segment_id=np.r_[forward.segment_id,idsr].astype(np.int32),
        segments=segments,
        stats=dict(forward_samples=len(fl),backward_samples=len(bl),
             forward_reciprocal=int(forward_recip.sum()),backward_reciprocal=int(reverse_recip.sum()),
             reverse_unmatched_kept=True, no_arbitrary_max_disparity=True,
             source_matcher_mode=matcher_mode))
    progress(f'Kaksisuuntaiset osarajat {len(allmatches.left_xy)}, '
             f'vastavuoroisesti vahvistettu {int(forward_recip.sum()+reverse_recip.sum())}')
    return allmatches
