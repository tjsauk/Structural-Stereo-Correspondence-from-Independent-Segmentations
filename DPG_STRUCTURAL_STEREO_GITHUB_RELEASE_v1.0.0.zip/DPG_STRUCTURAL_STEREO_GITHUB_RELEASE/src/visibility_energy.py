"""Native-patch visibility constraints IN the joint stereo solver (V4).

The source camera's 2D pixel occupancy is ground observation. A candidate
plane for a left patch is invalid whenever it reprojects strictly in front
of a *different* right-camera observed surface, and vice versa. This is
an alternating, conservative unary term, NOT a post-render hiding filter.
No RGB dense disparity, segmentation changes, GT or object-specific priors.
"""
from __future__ import annotations
import numpy as np


def disparity_at(coeff, x, y, side):
    """Positive disparity for a world plane in the given camera's native x.

    For left d_L=a*xL+b*y+c.  Since xL=xR+dL, right disparity is
    d_R=(a*xR+b*y+c)/(1-a).  The 1-a denominator is essential for
    correct 100->50 image width changes and reversed-camera visibility.
    """
    coeff=np.asarray(coeff,dtype=np.float64)
    raw=coeff[...,0]*x+coeff[...,1]*y+coeff[...,2]
    return raw if side=='left' else raw/(1.-coeff[...,0])


def _foreign_front_buffer(source_patch, source_labels, co, camera, source_side):
    """Closest depth of opposite-camera native observations in target camera.

    An original TARGET camera observation must be in front of this buffer.
    Otherwise it has been incorrectly hidden by a sheet reconstructed only
    from the source view. We derive depth from planar ELEMENT assignments,
    never by computing an RGB pixel disparity map.
    """
    h,w=source_patch.shape
    ys,xs=np.indices((h,w),dtype=np.float32)
    ids=np.asarray(source_labels,np.int32)[source_patch]
    valid=(ids>=0)&(ids<len(co))
    c=co[np.clip(ids,0,len(co)-1)]
    with np.errstate(divide='ignore',invalid='ignore'):
        d=disparity_at(c,xs,ys,source_side)
        z=camera.focal*camera.baseline/d
        xt=xs-d if source_side=='left' else xs+d
    xf=np.rint(np.nan_to_num(xt,nan=-1e6)).astype(np.int32)
    good=valid&np.isfinite(z)&(z>.001)&(z<1e6)&(xf>=0)&(xf<w)
    buf=np.full(h*w,np.inf,np.float32)
    if np.any(good):
        linear=(ys[good].astype(np.int64)*w+xf[good]).astype(np.int64)
        np.minimum.at(buf,linear,z[good].astype(np.float32))
    return buf.reshape(h,w)


def visibility_unary(patches, left_labels, right_labels, coefficients, camera,
                     step=9, rel_margin=.02):
    """Fraction of invalid foreground occupancy per native patch and plane.

    Candidate alternatives are evaluated at original image sampling rays. If
    the candidate projects IN FRONT of the opposite camera's actually visible
    modeled sheet (different plane), it contradicts observed visibility.
    Occluded/background candidates BEHIND the other sheet are allowed.
    The both-camera same-surface case is allowed by identical plane geometry.
    """
    lp,rp=(np.asarray(p,dtype=np.int32) for p in patches)
    assignments=(np.asarray(left_labels,np.int32),np.asarray(right_labels,np.int32))
    co=np.asarray(coefficients,np.float64)
    nleft=len(assignments[0]);nright=len(assignments[1]); k=len(co)
    h,w=lp.shape
    ys,xs=np.mgrid[step//2:h:step,step//2:w:step]
    xx=xs.ravel().astype(np.float64)
    yy=ys.ravel().astype(np.float64)
    pleft=lp[ys,xs].ravel();pright=rp[ys,xs].ravel()
    parts=[pleft,pright]
    samples=[(pleft,'left',rp,assignments[1]),
             (pright,'right',lp,assignments[0])]
    # Native-view depth must be frontmost in its OWN camera too. In each
    # camera, project all opposite-native element sheets and build their
    # nearest possible competing depth; no post-render filtering.
    incoming={
       'left':_foreign_front_buffer(rp,assignments[1],co,camera,'right'),
       'right':_foreign_front_buffer(lp,assignments[0],co,camera,'left')}
    sampled_front={s:buf[ys,xs].ravel() for s,buf in incoming.items()}
    out=np.zeros((nleft+nright,k),np.float32)
    stat={}
    focal_baseline=float(camera.focal*camera.baseline)
    for sindex,(patch_id,side,target_patch,target_labels) in enumerate(samples):
        n=nleft if sindex==0 else nright
        offset=0 if sindex==0 else nleft
        examined=np.zeros((n,k),np.float32)
        conflicting=np.zeros((n,k),np.float32)
        hidden=np.zeros((n,k),np.float32)
        hidden_examined=np.zeros((n,k),np.float32)
        dest_plane=np.where(target_labels>=0,target_labels,0).astype(np.int32)
        target_plane_map=dest_plane[target_patch]
        for plane in range(k):
            a,b,c=co[plane]
            if a>=.985:continue
            d=disparity_at(co[plane],xx,yy,side)
            z=np.divide(focal_baseline,d,out=np.full(len(d),np.nan),
                        where=np.abs(d)>1.e-8)
            target_x=xx-d if side=='left' else xx+d
            tx=np.rint(np.nan_to_num(target_x,nan=-1e6)).astype(np.int32)
            inside=(tx>=0)&(tx<w)&np.isfinite(z)&(z>.001)&(z<1e6)
            if not np.any(inside):continue
            txc=np.clip(tx,0,w-1)
            chosen=target_plane_map[yy.astype(np.int32),txc]
            known=target_labels[target_patch[yy.astype(np.int32),txc]]>=0
            # Depth of the native observation from the opposite camera.
            dest_coef=co[chosen]
            target_d=disparity_at(dest_coef,target_x,yy,'right' if side=='left' else 'left')
            target_z=np.divide(focal_baseline,target_d,out=np.full(len(d),np.nan),
                               where=np.abs(target_d)>1e-8)
            valid=inside&known&np.isfinite(target_z)&(target_z>.001)&(target_z<1e6)
            # Same physical plane may have different native DPG partitions;
            # equal geometry is not a false-front witness.
            conflict=valid&(chosen!=plane)&(z<target_z*(1.-rel_margin))
            examined[:,plane]=np.bincount(patch_id,weights=valid.astype(np.float32),minlength=n)
            conflicting[:,plane]=np.bincount(patch_id,weights=conflict.astype(np.float32),minlength=n)
            foreign=sampled_front[side]
            tested=np.isfinite(foreign)&np.isfinite(z)&(z>.001)&(z<1e6)
            # Incoming conflict: a surface guaranteed visible in this camera
            # was reconstructed BEHIND an opposite-camera sheet.
            obscured=tested&(z>foreign*(1.+rel_margin))
            hidden[:,plane]=np.bincount(patch_id,weights=obscured.astype(np.float32),minlength=n)
            hidden_examined[:,plane]=np.bincount(patch_id,weights=tested.astype(np.float32),minlength=n)
        outgoing_rate=conflicting/np.maximum(examined,1)
        incoming_rate=hidden/np.maximum(hidden_examined,1)
        # The two hard physical conditions are independent. Neither may be
        # treated as proof that the *other* one is satisfied.
        out[offset:offset+n]=np.maximum(outgoing_rate,incoming_rate)
        current=assignments[sindex]
        active=(current>=0)&(current<k)
        value=out[offset:offset+n]
        stat[side+'_native_patch_conflict_fraction']=float(np.mean(value[np.arange(n)[active],current[active]])) if np.any(active) else 0.
        stat[side+'_sample_grid']=int(len(xx))
        if np.any(active):
            sel=np.arange(n)[active];cur=current[active]
            stat[side+'_outgoing_fraction']=float(np.mean(outgoing_rate[sel,cur]))
            stat[side+'_hidden_in_own_camera_fraction']=float(np.mean(incoming_rate[sel,cur]))
    return out,stat


def measured_visibility_violations(patches,left_labels,right_labels,coeff,camera):
    matrix,stats=visibility_unary(patches,left_labels,right_labels,coeff,camera)
    return stats
