"""CPU dense textured render of the *existing* planar world.

Unlike a point-cloud preview, every actual source element sheet is rendered
as a continuous planar texture by an exact plane-induced homography. RGB is
resampled from native images; mask/identity are sampled without interpolation.
The 3D solution is NOT changed or filled with a new disparity estimate.
"""
import numpy as np
import cv2


def plane_homography(normal, Ks_inverse, Kview, Rview, Cview, Csource):
    n=np.asarray(normal,np.float64)
    source=np.asarray(Csource,np.float64)
    v=np.asarray(Cview,np.float64)
    A=(1.-np.dot(n,source))*np.eye(3)+(source-v)[:,None]@n[None,:]
    H=np.asarray(Kview,np.float64)@np.asarray(Rview,np.float64)@A@np.asarray(Ks_inverse,np.float64)
    if not np.isfinite(H).all() or abs(np.linalg.det(H))<1e-15:return None
    return H/H[2,2] if abs(H[2,2])>1e-12 else H/np.linalg.norm(H)


def render_planes(images,plane_ids,planes,identities,camera,view_center,view_rotation,
                  width,height,fx,cx,cy,*,use_sides=('left','right'),confidence=None):
    """Plane-by-plane inverse texture sampling in arbitrary virtual camera.

    `plane_ids` and `identities` use the native pixel grid. A single physical
    patch is a continuous area on its solved plane; the source texture and
    surface ID are warped with the same 2D->3D->camera projective map.
    """
    height=int(height);width=int(width)
    fx=float(fx)
    if fx<=0 or width<1 or height<1:raise ValueError('Invalid output viewport')
    K=np.array([[camera.focal,0,camera.cx],[0,camera.focal,camera.cy],[0,0,1.]],np.float64)
    Kv=np.array([[fx,0,cx],[0,fx,cy],[0,0,1.]],np.float64)
    Ki=np.linalg.inv(K)
    C=np.asarray(view_center,np.float64)
    R=np.asarray(view_rotation,np.float64)
    xx=(np.arange(width,dtype=np.float32)[None,:]-cx)/fx
    yy=(np.arange(height,dtype=np.float32)[:,None]-cy)/fx
    # Ray for a virtual image pixel in WORLD coordinates = R.T K^-1 p.
    rayx=R[0,0]*xx+R[1,0]*yy+R[2,0]
    rayy=R[0,1]*xx+R[1,1]*yy+R[2,1]
    rayz=R[0,2]*xx+R[1,2]*yy+R[2,2]
    zbuffer=np.full((height,width),np.inf,np.float32)
    surface=np.full((height,width),-1,np.int32)
    output=np.full((height,width,3),[24,28,34],np.uint8)
    count=np.zeros((height,width),np.uint8)
    present=np.zeros((height,width),np.uint8)
    confidence_out=np.zeros((height,width),np.uint8) if confidence is not None else None
    valid_planes=np.unique(np.concatenate([np.asarray(plane_ids[s],np.int32).ravel()
                           for s in use_sides]))
    for pi in valid_planes:
        if pi<0 or pi>=len(planes):continue
        n=np.asarray(planes[pi],np.float64)
        den=n[0]*rayx+n[1]*rayy+n[2]*rayz
        numer=1.-np.dot(n,C)
        with np.errstate(divide='ignore',invalid='ignore'):
            depth=np.divide(numer,den,out=np.full((height,width),np.inf,np.float64),
                            where=np.abs(den)>1e-10).astype(np.float32)
        good=(depth>.0001)&np.isfinite(depth)&(depth<1.e6)
        if not np.any(good):continue
        for side in use_sides:
            native=np.asarray(plane_ids[side],np.int32)
            mask=(native==pi).astype(np.uint8)
            if int(mask.sum())<3:continue
            Cs=np.array([(-.5 if side=='left' else .5)*camera.baseline,0,0],np.float64)
            H=plane_homography(n,Ki,Kv,R,C,Cs)
            if H is None:continue
            # Source mask remains discrete, but its support is projected as a
            # full area, never as sparse splat samples.
            warped_mask=cv2.warpPerspective(mask,H,(width,height),flags=cv2.INTER_NEAREST,
                            borderMode=cv2.BORDER_CONSTANT,borderValue=0)>0
            eligible=warped_mask&good
            if not np.any(eligible):continue
            ids_native=np.asarray(identities[side],np.float32)
            warped_id=cv2.warpPerspective(ids_native,H,(width,height),flags=cv2.INTER_NEAREST,
                            borderMode=cv2.BORDER_CONSTANT,borderValue=-1).astype(np.int32)
            tol=np.maximum(depth*.002,1.e-5)
            nearer=eligible&(depth<zbuffer-tol)
            compatible=eligible&(~nearer)&(np.abs(depth-zbuffer)<=tol)&\
                       (warped_id==surface)&(warped_id>=0)
            draw=nearer|compatible
            if not np.any(draw):continue
            warped_rgb=cv2.warpPerspective(np.asarray(images[side],np.uint8),H,(width,height),
                       flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE)
            output[nearer]=warped_rgb[nearer]
            zbuffer[nearer]=depth[nearer]
            surface[nearer]=warped_id[nearer]
            count[nearer]=1
            bit=1 if side=='left' else 2
            present[nearer]=bit
            if confidence_out is not None:
                native_conf=np.asarray(confidence[side],np.uint8)
                warp_conf=cv2.warpPerspective(native_conf,H,(width,height),flags=cv2.INTER_NEAREST,
                                   borderMode=cv2.BORDER_CONSTANT,borderValue=0)
                confidence_out[nearer]=warp_conf[nearer]
            if np.any(compatible):
                outcolor=output[compatible].astype(np.float32)
                nseen=count[compatible].astype(np.float32)
                blended=(outcolor*nseen[:,None]+warped_rgb[compatible].astype(np.float32))/(nseen[:,None]+1.)
                output[compatible]=np.clip(blended+.5,0,255).astype(np.uint8)
                count[compatible]=np.minimum(255,count[compatible]+1)
                present[compatible]|=bit
                if confidence_out is not None:
                    confidence_out[compatible]=np.minimum(confidence_out[compatible],warp_conf[compatible])
    if confidence_out is not None:return output,present,surface,confidence_out
    return output,present,surface
