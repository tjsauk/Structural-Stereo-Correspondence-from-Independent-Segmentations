"""Evidence provenance: stereo-supported vs native-element extension vs weak.

Original element identity is NEVER overwritten. Confidence tracks the SOURCE
observation patch, not a claim of physical object identity.
"""
from __future__ import annotations
import numpy as np
from native_observation import DOMAINS

def classify(obs,matches,world):
    known=np.asarray(world.sample_plane,np.int32)
    evidence={}
    stats={}
    for s in ('left','right'):
        patch=world.left_patch if s=='left' else world.right_patch
        plane_map=world.left_plane if s=='left' else world.right_plane
        patch_plane=world.left_patch_planes if s=='left' else world.right_patch_planes
        pcount=len(patch_plane)
        xy=matches.left_xy if s=='left' else matches.right_xy
        h,w=patch.shape
        x=np.clip(np.rint(xy[:,0]).astype(np.int32),0,w-1)
        y=np.clip(np.rint(xy[:,1]).astype(np.int32),0,h-1)
        pid=patch[y,x]
        reliable=(known>=0)&(plane_map[y,x]==known)&(np.asarray(matches.confidence)>.25)
        hits=np.bincount(pid[reliable],minlength=pcount)
        direct=hits>=3
        state=np.zeros(pcount,np.uint8)
        state[direct]=2
        # Interior of a native DPG element inherits its solved plane ONLY
        # where the element identity AND the plane ID both agree with a
        # stereo-supported sample. Any other placement remains weak.
        for dom in DOMAINS:
            labels=obs[f'{s}_{dom}']
            labels_xy=labels[y[reliable],x[reliable]]
            planes_xy=known[reliable]
            good=labels_xy>0
            pairs=np.stack((labels_xy[good],planes_xy[good]),axis=1)
            if not len(pairs):continue
            identity=np.unique(pairs,axis=0)
            # Query each PATCH at a representative source pixel. The original
            # domain IDs have constant membership on a joint domain patch.
            flat=np.asarray(patch,np.int32).ravel()
            first=np.full(pcount,len(flat),np.int64)
            np.minimum.at(first,flat,np.arange(len(flat),dtype=np.int64))
            ids=np.flatnonzero(first<len(flat))
            ref=first[ids]
            label_patch=labels.ravel()[ref]
            plane_patch=patch_plane[ids]
            query=np.stack((label_patch,plane_patch),axis=1)
            # Vectorized structured-record membership avoids per-element loops.
            typ=np.dtype([('id',np.int32),('plane',np.int32)])
            eligible=np.isin(np.ascontiguousarray(query).view(typ).ravel(),
                             np.ascontiguousarray(identity).view(typ).ravel())
            state[ids[(state[ids]==0)&eligible&(label_patch>0)&(plane_patch>=0)]]=1
        confidence=state[patch]
        evidence[s]=confidence
        stats[s]={'stereo_supported':int(np.count_nonzero(confidence==2)),
                  'same_element_plane_continuation':int(np.count_nonzero(confidence==1)),
                  'weak_or_unverified':int(np.count_nonzero(confidence==0))}
    return evidence,stats


def project_provenance(evidence,geom,shape):
    h,w=shape
    out=np.zeros(h*w,np.uint8)
    for s in ('left','right'):
        mx,yy,z,valid=geom[s]
        xi=np.rint(np.nan_to_num(mx,nan=-1e6)).astype(np.int32)
        ok=valid&(xi>=0)&(xi<w)
        dest=yy[ok].astype(np.int64)*w+xi[ok]
        np.maximum.at(out,dest,evidence[s][ok])
    return out.reshape(h,w)
