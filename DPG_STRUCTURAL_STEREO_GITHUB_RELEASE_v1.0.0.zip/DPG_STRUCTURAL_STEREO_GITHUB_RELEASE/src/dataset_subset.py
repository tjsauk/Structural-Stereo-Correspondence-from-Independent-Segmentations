"""Lossless, timestamp-preserving export of an indexed stereo dataset interval.

This module does not decode or re-encode camera/depth images. The source
filenames, timestamps, calibration and documentation are preserved. Only
camera/depth frames outside the interval and time-indexed auxiliary records
outside its timestamp window are removed. Unknown/non-indexed files are kept.

An explicit clip_manifest.json preserves the *original* pair indexes when
opening the subset with Dataset, including indexes such as 200..600.
"""
from __future__ import annotations

import csv
import io
import json
import re
import shutil
import zipfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Callable, BinaryIO

from dataset_io import Dataset

_IMAGE_SUFFIXES = {'.png', '.jpg', '.jpeg', '.tif', '.tiff', '.exr', '.npy', '.npz', '.pfm'}
_COMPRESSED_SUFFIXES = _IMAGE_SUFFIXES | {'.gz', '.zip', '.mp4', '.bag', '.db3', '.mcap'}
_TIMESTAMP_RX = re.compile(r'(?<!\d)(\d{12,20})(?!\d)')
_CHUNK_BYTES = 1024 * 1024


def _timestamp(value: str) -> float | None:
    """Read integer ns/us/ms or epoch seconds, without renaming recordings."""
    text = str(value).strip().lstrip('\ufeff').strip('"\'')
    if text.startswith('frame_'):
        text = text[6:]
    try:
        if re.fullmatch(r'\d+', text):
            n = float(text)
            if len(text) >= 18:
                return n / 1e9
            if len(text) >= 15:
                return n / 1e6
            if len(text) >= 12:
                return n / 1e3
            if len(text) >= 9:
                return n
            return None
        n = float(text)
        return n if 1e8 <= n < 1e11 else None
    except ValueError:
        return None


def _stem_time(path: str) -> float | None:
    stem = PurePosixPath(path).stem
    ts = _timestamp(stem)
    if ts is not None:
        return ts
    m = _TIMESTAMP_RX.search(stem)
    return _timestamp(m.group(1)) if m else None


def _is_timed_file(name: str) -> bool:
    """Whether the filename is a timestamped recording rather than metadata."""
    rel = '/' + name.lower().replace('\\', '/')
    return ('/data/' in rel or '/frames/' in rel) and _stem_time(name) is not None


def _camera_channel(name: str) -> str | None:
    norm = '/' + name.lower().replace('\\', '/')
    for channel in ('cam0', 'cam1', 'depth0', 'depth1'):
        if f'/{channel}/data/' in norm or norm.endswith(f'/{channel}/data.csv'):
            return channel
    return None


def _source_rel(ds: Dataset, name: str) -> str:
    """Convert a Dataset pair locator to the untouched source-relative path."""
    if ds.z is not None:
        rel = str(name).replace('\\', '/')
    else:
        rel = Path(name).resolve().relative_to(ds.path).as_posix()
    posix = PurePosixPath(rel)
    if posix.is_absolute() or '..' in posix.parts:
        raise ValueError(f'Unsafe dataset entry: {name!r}')
    return str(posix)


class _ArchiveSource:
    def __init__(self, ds: Dataset):
        self.ds = ds
        if ds.z is not None:
            self.files = sorted(n for n in ds.z.namelist() if not n.endswith('/'))
        else:
            self.files = sorted(p.relative_to(ds.path).as_posix()
                                for p in ds.path.rglob('*') if p.is_file() and not p.is_symlink())
        for entry in self.files:
            normalized = PurePosixPath(entry.replace('\\', '/'))
            if normalized.is_absolute() or '..' in normalized.parts:
                raise ValueError(f'Unsafe path in input dataset: {entry}')
        self.file_set = set(self.files)

    def open(self, name: str) -> BinaryIO:
        if self.ds.z is not None:
            return self.ds.z.open(name, 'r')
        return (self.ds.path / name).open('rb')


def _copy_entry(source: _ArchiveSource, original: str, output: zipfile.ZipFile,
                dest_name: str | None = None):
    """Stream bytes into the ZIP; PNG/depth samples remain byte-identical."""
    dest_name = dest_name or original
    suffix = PurePosixPath(dest_name).suffix.lower()
    compression = zipfile.ZIP_STORED if suffix in _COMPRESSED_SUFFIXES else zipfile.ZIP_DEFLATED
    info = zipfile.ZipInfo(dest_name)
    info.compress_type = compression
    info.external_attr = 0o644 << 16
    with source.open(original) as src, output.open(info, mode='w', force_zip64=True) as dst:
        shutil.copyfileobj(src, dst, _CHUNK_BYTES)


def _rewrite_timed_index(source: _ArchiveSource, name: str, output: zipfile.ZipFile,
                         lower_bound: float, upper_bound: float,
                         retained_names: set[str] | None = None) -> tuple[int, bool]:
    """Filter time-series rows in CSV/TUM files and retain all headers/comments.

    No rows are dropped if the file does not contain recognized timestamps.
    Returns (number of copied timestamped rows, whether filtering occurred).
    """
    with source.open(name) as raw:
        # Large time series are processed by streaming, not reading into RAM.
        stream = io.TextIOWrapper(raw, encoding='utf-8-sig', errors='replace', newline='')
        samples = []
        for _ in range(40):
            line = stream.readline()
            if not line:
                break
            samples.append(line)
        valid_timestamps = 0
        for line in samples:
            if not line.strip() or line.lstrip().startswith(('#', '//')):
                continue
            first = re.split(r'[\s,;]+', line.strip(), maxsplit=1)[0]
            if _timestamp(first) is not None:
                valid_timestamps += 1
    if valid_timestamps == 0 and retained_names is None:
        _copy_entry(source, name, output)
        return 0, False

    # An odometry / IMU file may use a different clock origin. Never truncate
    # the entire file to an empty series if no records fall into our timebase.
    # In that case keep the original bytes and report it as unfiltered.
    if retained_names is None:
        has_overlap = False
        with source.open(name) as raw:
            for line in io.TextIOWrapper(raw, encoding='utf-8-sig', errors='replace'):
                if not line.strip() or line.lstrip().startswith(('#', '//')):
                    continue
                first = re.split(r'[\s,;]+', line.strip(), maxsplit=1)[0]
                t = _timestamp(first)
                if t is not None and lower_bound <= t <= upper_bound:
                    has_overlap = True
                    break
        if not has_overlap:
            _copy_entry(source, name, output)
            return 0, False

    def filter_line(line: str) -> tuple[str | None, bool]:
        if not line.strip() or line.lstrip().startswith(('#', '//')):
            return line, False
        columns = next(csv.reader([line])) if ',' in line else re.split(r'\s+', line.strip())
        if not columns:
            return line, False
        timestamp = _timestamp(columns[0])
        if timestamp is None:
            return line, False
        if retained_names is not None:
            # Camera/depth data.csv: retain rows whose original image name
            # occurs in the selected camera/depth records, not intervening frames.
            names = {PurePosixPath(c.strip().strip('"')).name for c in columns[1:]}
            keep = bool(names & retained_names)
            # Some CSVs have only a timestamp and no filename column.
            if len(columns) == 1:
                keep = lower_bound <= timestamp <= upper_bound
        else:
            keep = lower_bound <= timestamp <= upper_bound
        return (line if keep else None), keep

    count = 0
    out_info = zipfile.ZipInfo(name)
    out_info.compress_type = zipfile.ZIP_DEFLATED
    with source.open(name) as raw, output.open(out_info, 'w', force_zip64=True) as dst:
        for line in io.TextIOWrapper(raw, encoding='utf-8-sig', errors='replace', newline=''):
            retained, recognized_and_kept = filter_line(line)
            if retained is not None:
                dst.write(retained.encode('utf-8'))
                if recognized_and_kept:
                    count += 1
    return count, True


def _manifest_parent(source_paths: list[str]) -> str:
    # For ZIPs with a rig_.../ prefix, add the index alongside rig_.../mav0.
    a = source_paths[0]
    parts = PurePosixPath(a).parts
    for channel in ('cam0', 'cam1'):
        if channel in parts:
            i = parts.index(channel)
            return '/'.join(parts[:max(0, i - 1)])
    return ''


@dataclass
class SubsetReport:
    output: str
    start_frame: int
    end_frame: int
    selected_pairs: int
    selected_depth_files: int = 0
    copied_files: int = 0
    filtered_indexes: int = 0
    copied_auxiliary_timed_files: int = 0
    kept_untimed_files: int = 0
    warnings: list[str] = field(default_factory=list)


def export_subset(dataset: str | Path, start_frame: int, end_frame: int,
                  output_zip: str | Path, *, time_margin_seconds: float = 0.10,
                  progress: Callable[[str], None] = lambda msg: None,
                  stop_requested: Callable[[], bool] = lambda: False) -> SubsetReport:
    """Export inclusive original frame indexes to an independently usable ZIP.

    Preserves: original image/depth filenames and file bytes; sensor YAML;
    calibration JSON, static files, and any unknown files. Rewrites per-sensor
    CSV/pose logs to the selected time span. Stores an explicit frame-index
    manifest, so Dataset(clip).frames remains [200, ..., 600], not [0, ..., 400].
    """
    ds = Dataset(dataset)
    start_frame = int(start_frame)
    end_frame = int(end_frame)
    if start_frame > end_frame:
        raise ValueError('Start frame must not exceed end frame')
    selection = [i for i in ds.frames if start_frame <= i <= end_frame]
    if not selection:
        raise ValueError('No stereo pairs within the requested frame interval')
    target = Path(output_zip).expanduser().resolve()
    if target == ds.path:
        raise ValueError('Output archive must differ from input dataset')
    if target.suffix.lower() != '.zip':
        raise ValueError('Output filename must end in .zip')
    if target.exists():
        raise FileExistsError(f'Output archive already exists: {target}')
    target.parent.mkdir(parents=True, exist_ok=True)
    src = _ArchiveSource(ds)
    selected = [(_source_rel(ds,ds.pairs[i][0]),_source_rel(ds,ds.pairs[i][1])) for i in selection]
    all_camera = set(sum(([l,r] for l,r in selected),[]))
    if not all_camera <= src.file_set:
        raise FileNotFoundError('Some selected camera files are missing from the input')
    timestamp_list = [_stem_time(l) for l,_ in selected]
    if any(t is None for t in timestamp_list):
        raise ValueError('Source image filenames must carry timestamps to filter sensor records')
    lo,hi = min(timestamp_list),max(timestamp_list)
    lo_aux,hi_aux = lo - time_margin_seconds,hi + time_margin_seconds
    chosen_depth: set[str] = set()
    depth_by_channel: dict[str, set[str]] = {}
    warnings: list[str] = []
    for channel, selected_images in (('depth0', [l for l,_ in selected]),
                                     ('depth1', [r for _,r in selected])):
        candidates = [n for n in src.files if _camera_channel(n) == channel and
                      PurePosixPath(n).suffix.lower() in _IMAGE_SUFFIXES]
        if not candidates:
            if channel == 'depth0':
                warnings.append('No left-camera depth0 GT files found in this dataset')
            continue
        by_stem = {PurePosixPath(n).stem:n for n in candidates}
        timed = sorted((t,n) for n in candidates if (t:=_stem_time(n)) is not None)
        times = [q[0] for q in timed]
        chosen = set()
        misses = 0
        for cam_name in selected_images:
            stem = PurePosixPath(cam_name).stem
            exact = by_stem.get(stem)
            if exact is not None:
                chosen.add(exact)
                continue
            time = _stem_time(cam_name)
            if time is None or not timed:
                misses += 1
                continue
            # Find the nearest saved depth observation within 50 milliseconds.
            import bisect
            at = bisect.bisect_left(times, time)
            options = timed[max(0,at-1):min(len(timed),at+2)]
            nearest = min(options, key=lambda q:abs(q[0]-time)) if options else None
            if nearest and abs(nearest[0]-time) <= 0.05:
                chosen.add(nearest[1])
            else:
                misses += 1
        if misses:
            warnings.append(f'{channel}: {misses} selected frames have no matching depth file')
        chosen_depth.update(chosen)
        depth_by_channel[channel] = {PurePosixPath(n).name for n in chosen}

    manifest_path = _manifest_parent([selected[0][0]])
    manifest_name = f'{manifest_path}/clip_manifest.json' if manifest_path else 'clip_manifest.json'
    report = SubsetReport(str(target), selection[0], selection[-1], len(selection),
                          selected_depth_files=len(chosen_depth),warnings=warnings)
    # For RGB/GT data.csv, preserve exactly the records selected by the same
    # images. All other sensor logs are cropped to the selected time span.
    channel_names = {
        'cam0':{PurePosixPath(l).name for l,_ in selected},
        'cam1':{PurePosixPath(r).name for _,r in selected},
        **depth_by_channel,
    }
    notes = []
    try:
        with zipfile.ZipFile(target, 'w', allowZip64=True) as out:
            for idx, name in enumerate(src.files):
                if stop_requested():
                    raise InterruptedError('Dataset export cancelled; incomplete ZIP removed')
                if name == manifest_name or name.endswith('/clip_manifest.json'):
                    # Preserve the original manifest as raw metadata, while
                    # only the replacement name is consumed by Dataset.
                    # The backup deliberately does not end in clip_manifest.json.
                    parent = name.rpartition('/')[0]
                    prefix = parent + '/' if parent else ''
                    backup = prefix + 'source_manifest_backup.json'
                    if backup in src.file_set:
                        # Re-clipping an existing subset must not duplicate a
                        # ZIP entry or overwrite its original manifest backup.
                        backup = prefix + 'source_manifest_from_current_clip.json'
                    _copy_entry(src, name, out, backup)
                    report.copied_files += 1
                    notes.append('Original clip manifest preserved as ' + backup)
                    continue
                if ds.path.is_dir() and (ds.path / name).resolve() == target:
                    continue
                ch = _camera_channel(name)
                suffix = PurePosixPath(name).suffix.lower()
                is_camera_data = (ch in ('cam0','cam1') and suffix in _IMAGE_SUFFIXES)
                is_depth_data = (ch in ('depth0','depth1') and suffix in _IMAGE_SUFFIXES)
                if is_camera_data and name not in all_camera:
                    continue
                if is_depth_data and name not in chosen_depth:
                    continue
                if PurePosixPath(name).name.lower() == 'data.csv' and ch in channel_names:
                    copied,filtered = _rewrite_timed_index(src,name,out,lo_aux,hi_aux,
                                                            channel_names[ch])
                    report.filtered_indexes += int(filtered)
                elif suffix in ('.csv','.txt','.tum') and ('/lio_odom/' in '/'+name.lower() or
                       '/imu' in '/'+name.lower() or '/odom' in '/'+name.lower() or
                       '/pose' in '/'+name.lower() or '/trajectory' in '/'+name.lower() or
                       PurePosixPath(name).name.lower()=='data.csv'):
                    copied,filtered = _rewrite_timed_index(src,name,out,lo_aux,hi_aux)
                    report.filtered_indexes += int(filtered)
                    if not filtered:
                        notes.append('Unfilterable or clock-mismatched time series kept intact: ' + name)
                elif _is_timed_file(name) and ch is None:
                    timestamp = _stem_time(name)
                    if timestamp is None or not lo_aux <= timestamp <= hi_aux:
                        continue
                    _copy_entry(src,name,out)
                    report.copied_auxiliary_timed_files += 1
                else:
                    _copy_entry(src,name,out)
                    report.kept_untimed_files += int(ch is None and not _is_timed_file(name))
                report.copied_files += 1
                if idx % 250 == 0:
                    progress(f'Writing dataset subset: {idx + 1}/{len(src.files)} source files checked')
            pair_rows=[{'pair_index':int(i),'left':l,'right':r}
                       for i,(l,r) in zip(selection,selected)]
            manifest={
                'format':'structural_stereo_subset_v1',
                'description':'Stereo pair subset retaining original frame indexes and filenames',
                'frame_start':selection[0], 'frame_end':selection[-1],
                'frame_count':len(selection),
                'time_start_seconds':lo, 'time_end_seconds':hi,
                'auxiliary_margin_seconds':time_margin_seconds,
                'pair_source_ids':pair_rows,
                'depth_file_count':len(chosen_depth),
                'notes':notes+warnings,
            }
            out.writestr(manifest_name,json.dumps(manifest,indent=2,ensure_ascii=True))
            report.copied_files += 1
        # Check that the published archive reopens with its ORIGINAL indices.
        verified = Dataset(target)
        try:
            if verified.frames != selection:
                raise RuntimeError('Subset frame indexes failed verification')
            if len(verified.pairs) != len(selection):
                raise RuntimeError('Subset pair count failed verification')
        finally:
            if verified.z is not None:
                verified.z.close()
        progress(f'Subset complete: {len(selection)} original stereo pairs and '
                 f'{len(chosen_depth)} depth images; {target}')
        return report
    except BaseException:
        target.unlink(missing_ok=True)
        raise


# Re-exported CLI shared with the GUI; see top-level subset_dataset.py.
