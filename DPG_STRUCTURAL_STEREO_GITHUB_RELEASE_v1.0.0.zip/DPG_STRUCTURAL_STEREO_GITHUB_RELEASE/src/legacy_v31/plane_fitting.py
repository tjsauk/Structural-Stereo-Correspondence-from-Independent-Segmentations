"""Stereo boundary correspondences -> ONE shared multi-surface relative 3D model.

This solver does NOT receive RGB images or SGBM disparity maps. Each fitted
plane is described in left RECTIFIED CAMERA COORDINATES by
    x_left - x_right = a*x_left + b*y + c
which is the exact perspective projection of a 3D plane for parallel rectified
pinhole cameras. The midpoint uses the SAME plane, not separately fitted 3D
copies. Multiple DPG groups may share a plane, and one group may span planes.

Model selection is deliberately conservative: unexplained observations remain
in the diagnostics; there is no claim that all real surfaces are planar or that
an underconstrained scene has a unique reconstruction.
"""
from __future__ import annotations
import numpy as np
import cv2
from scipy import ndimage as ndi
from native_observation import DOMAINS

def _fit(A, y, weights):
    sw=np.sqrt(np.maximum(weights, .002))
    return np.linalg.lstsq(A*sw[:,None], y*sw, rcond=None)[0]


def _irls(A, y, w, initial, steps=5):
    beta=initial.copy()
    for _ in range(steps):
        residual=y-A@beta
        scale=max(.35,1.4826*np.median(np.abs(residual-np.median(residual))))
        robust=np.minimum(1.,1.8*scale/np.maximum(np.abs(residual),1e-4))
        beta=_fit(A,y,w*robust)
    return beta


def discover_planes(matches, shape, max_planes=None, threshold_px=1.7, seed=20261030):
    """Sequential deterministic RANSAC + robust refit + duplicate-plane merging.

    A plane requires 2D-spread boundary matches; a single short collinear arc
    cannot establish its full orientation. That case is marked underconstrained.
    """
    h,w=shape
    l=np.asarray(matches.left_xy,np.float64)
    r=np.asarray(matches.right_xy,np.float64)
    q=np.asarray(matches.confidence,np.float64)
    n=len(l)
    if n<3:raise ValueError('Too few corresponding DPG boundary samples')
    disparity=l[:,0]-r[:,0]
    # Exact zero shift is a valid apparent-infinity observation. A plane at
    # infinity has no finite XYZ intersection; choose a tiny relative visual
    # parallax ONLY for its finite 3D display proxy, retaining original pairs.
    positives=disparity[np.isfinite(disparity)&(disparity>0)]
    far_parallax=max(1.e-5, min(.01,float(positives.min())*.01)) if len(positives) else .01
    display_disparity=np.where(disparity==0,far_parallax,disparity)
    ok=np.isfinite(l).all(axis=1)&np.isfinite(r).all(axis=1)&np.isfinite(q)&(q>.01)&(disparity>=0)&(np.abs(l[:,1]-r[:,1])<=3)
    # Coordinates normalized for stable linear fits; output converted to pixel coordinates.
    A=np.column_stack(((l[:,0]-w/2)/w,(l[:,1]-h/2)/h,np.ones(n)))
    rng=np.random.default_rng(seed)
    remaining=ok.copy()
    raw=[]
    # Minimum structural evidence is proportional to measured boundary support.
    # No hard quota: stop when the remaining structural evidence cannot
    # support another distinguishable coherent planar hypothesis.
    min_support=max(22,int(np.count_nonzero(ok)*.012))
    # No hard number-of-planes cutoff. Each accepted model consumes
    # observations; termination follows the remaining structural evidence.
    requested_cap=None if max_planes is None else int(max_planes)
    search_cap=None
    attempts=0
    while True:
        if requested_cap is not None and attempts>=requested_cap:break
        attempts+=1
        ids=np.flatnonzero(remaining)
        if len(ids)<min_support:break
        # Cap random search for large scenes without dropping observations from scoring.
        best=None;best_score=-1
        for _trial in range(440):
            choice=rng.choice(ids,3,replace=False)
            tri=A[choice]
            if abs(np.linalg.det(tri))<.0025:continue
            beta=np.linalg.solve(tri,display_disparity[choice])
            # Suppress numerical extrapolation from nearly collinear triples.
            if max(abs(beta[0]),abs(beta[1]))>w*3:continue
            residual=np.abs(A[ids]@beta-display_disparity[ids])
            inliers=residual<threshold_px
            # Truncated robust quality score: a coincidental oblique plane
            # should not win by loosely covering samples from two real planes.
            score=float(np.sum(q[ids]*np.maximum(0.,1.-(residual/threshold_px)**2)))
            if score>best_score:
                best=(beta,ids[inliers]);best_score=score
        if best is None or len(best[1])<min_support:break
        beta,fit_ids=best
        # Avoid a low-rank inlier set masquerading as a full 3D surface plane.
        if np.linalg.matrix_rank(A[fit_ids],tol=.02)<3:
            break
        beta=_irls(A[fit_ids],display_disparity[fit_ids],q[fit_ids],beta)
        all_res=np.abs(A@beta-display_disparity)
        support=remaining&(all_res<threshold_px)
        if np.count_nonzero(support)<min_support:break
        beta=_irls(A[support],display_disparity[support],q[support],beta)
        # Require a plane to be physically forward over its measured area.
        if np.median(A[support]@beta)<=0:break
        raw.append((beta,np.flatnonzero(support)))
        remaining[support]=False
    if not raw:
        # Explicit underconstrained fallback: constant depth from the matched boundaries.
        med=float(np.median(display_disparity[ok])) if np.any(ok) else 1.0
        raw=[(np.array([0.,0.,max(far_parallax,med)]),np.flatnonzero(ok))]
        underconstrained=True
    else:underconstrained=False

    # Merge near-identical hypotheses, including disconnected DPG regions lying
    # on the same plane. A scene plane ID is not a DPG element ID.
    unique=[]
    for beta,ids in raw:
        co=np.array([beta[0]/w,beta[1]/h,beta[2]-beta[0]/2-beta[1]/2],np.float64)
        if any(np.median(np.abs(A[ids]@p['beta']-A[ids]@beta))<.55 for p in unique):
            nearest=min(unique,key=lambda p:np.median(np.abs(A[ids]@p['beta']-A[ids]@beta)))
            nearest['ids']=np.unique(np.r_[nearest['ids'],ids]);continue
        unique.append(dict(beta=beta,ids=ids,co=co))
    for p in unique:
        ids=p['ids'];p['beta']=_irls(A[ids],display_disparity[ids],q[ids],p['beta'])
        beta=p['beta'];p['co']=np.array([beta[0]/w,beta[1]/h,beta[2]-beta[0]/2-beta[1]/2])

    coefs=np.array([p['co'] for p in unique],np.float32)
    residual=np.abs(np.stack([A@p['beta']-display_disparity for p in unique],axis=1))
    labels=np.argmin(residual,axis=1).astype(np.int32)
    err=residual[np.arange(n),labels]
    labels[~ok|(err>max(2.6,threshold_px*1.65))]=-1
    report=[]
    for k,p in enumerate(unique):
        hits=(labels==k)
        # A plane's straight 3D lines are encoded by a single plane equation;
        # no independent pointwise disparity wiggle is admitted on that plane.
        report.append(dict(id=k,a=float(p['co'][0]),b=float(p['co'][1]),c=float(p['co'][2]),
                           matched_boundary_samples=int(hits.sum()),
                           median_boundary_residual_px=float(np.median(err[hits])) if hits.any() else None,
                           unique_partial_arcs=int(len(np.unique(np.asarray(matches.segment_id)[hits])))))
    return coefs,labels,report,dict(plane_search_cap=requested_cap,
        plane_search_attempts=attempts,
        plane_limit_reached=bool(requested_cap is not None and len(raw)>=requested_cap and np.count_nonzero(remaining)>=min_support),
        zero_shift_boundary_samples=int(np.count_nonzero(ok&(disparity==0))),
        display_proxy_parallax_px=float(far_parallax),
        accepted_samples=int(ok.sum()),explained_samples=int((labels>=0).sum()),
        unexplained_samples=int((ok&(labels<0)).sum()),underconstrained_fallback=underconstrained)


