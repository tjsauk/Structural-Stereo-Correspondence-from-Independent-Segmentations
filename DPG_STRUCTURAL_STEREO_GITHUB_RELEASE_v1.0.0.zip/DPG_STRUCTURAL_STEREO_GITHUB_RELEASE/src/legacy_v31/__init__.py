"""Frozen original V3.1 structural stereo solve for regression fallback.

Do not modify these modules when experimenting with the V4 solver.
"""
