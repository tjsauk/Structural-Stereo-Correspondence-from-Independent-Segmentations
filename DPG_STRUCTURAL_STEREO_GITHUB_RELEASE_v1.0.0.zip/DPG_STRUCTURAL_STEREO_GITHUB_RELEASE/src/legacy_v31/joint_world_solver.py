"""Joint, camera-symmetric structural stereo geometry inference (v1.6).

Unknowns are ONE set of world plane equations and the supporting physical
sheet membership of L/VC/CC intersection components in BOTH source views.
The original native label arrays are never changed. One source component can
be split where competing matched boundary arcs provide evidence; adjacency is
soft and MUST NOT imply a 3D weld. No dense disparity, RGB, semantic labels,
GT, or square image tiling enters this solver.

Alternating optimization: two-view arc/patch support -> joint normalized graph
assignment -> globally refit geometry on the SAME matched curves. The update
is deterministic, with bounded iterations and explicit unassigned observations.
This is a locally optimized model, not a proof of unique geometry or a global
optimum over unenumerated stereo correspondences.
"""
from __future__ import annotations
import numpy as np
from scipy import sparse
from scipy.sparse.csgraph import connected_components
from .sheet_solver import _patches, _split_conflicting_native_patches, _patch_graph
from .plane_fitting import _irls


def _observed_components(obs, side, xy, labels, confidence, k):
    """Native connected intersections; allow within-region evidence-backed folds.

    Source membership is an annotation, not a physical-surface identity.
    No fold is inferred merely from 2D adjacency.
    """
    patch = _patches(obs, side)
    h,w=patch.shape
    native_count=int(patch.max())+1
    seeds = np.full(patch.shape, 0, np.int32)
    patch,seeds,folds=_split_conflicting_native_patches(
        patch,seeds,xy,labels,confidence,k)
    return patch, dict(native_regions=native_count, geometry_evidenced_splits=folds,
                       optimization_regions=int(patch.max())+1)


def _sample_patch_ids(patch,xy):
    h,w=patch.shape
    xx=np.clip(np.rint(xy[:,0]).astype(np.int64),0,w-1)
    yy=np.clip(np.rint(xy[:,1]).astype(np.int64),0,h-1)
    return patch[yy,xx]


def _cross_camera_edges(il,ir,conf,nl,nr):
    # Same matched *partial boundary* supplies a cross-camera equality clue;
    # unlike a 2D neighbor, this has direct stereo support. Still a soft term.
    index=il.astype(np.int64)*nr+ir.astype(np.int64)
    uniq,inv=np.unique(index,return_inverse=True)
    values=np.bincount(inv,weights=np.clip(conf,0.,1.),minlength=len(uniq))
    a=(uniq//nr).astype(np.int32)
    b=(uniq%nr+nl).astype(np.int32)
    return sparse.coo_matrix((np.r_[values,values],(np.r_[a,b],np.r_[b,a])),
                             shape=(nl+nr,nl+nr)).tocsr(),len(uniq)


def _rigid_joint_graph(obs, patches, il,ir, confidence, node_prior):
    left,right=patches
    nl=int(left.max())+1;nr=int(right.max())+1
    lgraph=_patch_graph(left,obs,'left')
    rgraph=_patch_graph(right,obs,'right')
    native=sparse.block_diag((lgraph,rgraph),format='csr')
    # Native adjacency is only weak continuity *evidence*.  Crossing a
    # measured depth transition (two independently supported different sheet
    # models) must not couple the two components into one plane.
    coo=native.tocoo()
    i,j=coo.row,coo.col
    v=coo.data.copy()
    distinct=(node_prior[i]>=0)&(node_prior[j]>=0)&(node_prior[i]!=node_prior[j])
    v*=np.where(distinct,.015,.12)
    native=sparse.coo_matrix((v,(i,j)),shape=native.shape).tocsr()
    cross,cross_count=_cross_camera_edges(il,ir,confidence,nl,nr)
    # One measured stereo arc acts in both cameras together.  Evidence is
    # allowed to disagree; cross-links do NOT equate entire native elements.
    return native+cross*.85,cross_count


def _boundary_likelihood(xl,xr,coef,conf):
    h,w=xl.shape[0],coef.shape[0]
    # No dense image computation: only original paired curve sample locations.
    a=np.column_stack((xl[:,0],xl[:,1],np.ones(len(xl))))
    d=xl[:,0]-xr[:,0]
    residual=np.abs(a@coef.T-d[:,None])
    # A robust truncated likelihood admits real occlusions and unexplained
    # boundaries; it does not force any sample to a surface.
    score=np.square(np.maximum(0,1-(residual/2.5)**2))
    return score*np.clip(conf[:,None],.01,1.),residual


def _update_joint_labels(graph, il,ir, likelihood, confidence, nleft, nright,
                         k, current_labels=None, iterations=18):
    n=nleft+nright
    # Curves vote for the physical surface from both cameras. Weighted stereo
    # measurements are accumulated before graph propagation, not afterwards.
    votes=np.zeros((n,k),np.float32)
    weights=np.asarray(confidence,np.float32)
    for side_ids in (il, ir+nleft):
        np.add.at(votes,side_ids,likelihood.astype(np.float32))
    votes/=np.maximum(1e-6,np.bincount(np.r_[il,ir+nleft],weights=np.r_[weights,weights],
                                      minlength=n)[:,None]).astype(np.float32)
    evidence=votes.max(axis=1)
    if current_labels is not None:
        prior=(np.arange(k)[None,:]==current_labels[:,None]).astype(np.float32)
        votes+=prior*.015*(evidence[:,None]>0)
    degree=np.asarray(graph.sum(axis=1)).ravel().astype(np.float32)
    # External field from direct stereo evidence; unsupported regions see
    # only adjacent measured geometry and never create their own false pairs.
    measured=evidence>.04
    prior=votes.sum(axis=0)
    prior=(prior+1e-4)/max(1e-4,float(prior.sum())+k*1e-4)
    scores=votes+.0005*prior[None,:]
    for _ in range(iterations):
        neigh=graph@scores
        scores=(neigh+.95*votes+.0005*prior[None,:])/(degree[:,None]+.95+.0005)
    labels=np.argmax(scores,axis=1).astype(np.int32)
    # Unanchored disconnected structures are not silently assigned by a
    # distant global class prior; geometry completion separately records them
    # as hypotheses using existing surfaces.
    components,count=connected_components(graph,directed=False,return_labels=True)
    anchored=np.bincount(count,weights=measured.astype(np.int32),minlength=components)>0
    labels[~anchored[count]]=-1
    return labels,dict(anchored_patches=int(np.count_nonzero(measured)),
                       unanchored_patches=int(np.count_nonzero(~anchored[count])))


def _joint_refit_symmetric(coef,xl,xr,il,ir,labels,nleft,confidence):
    d=xl[:,0]-xr[:,0]
    A=np.column_stack((xl[:,0],xl[:,1],np.ones(len(xl))))
    left=labels[il];right=labels[ir+nleft]
    out=coef.copy()
    accepted=[]
    for k in range(len(coef)):
        both=(left==k)&(right==k)
        single=((left==k)|(right==k))&~both
        # Stereo agreement is much more reliable than either camera's sole
        # attribution; the latter is permitted but downweighted.
        fitweights=np.where(both,1.,np.where(single,.22,0.))*confidence
        active=fitweights>.01
        if active.sum()<6 or np.linalg.matrix_rank(A[active])<3:
            accepted.append(False);continue
        initial=coef[k]
        fitted=_irls(A[active],d[active],fitweights[active],initial,steps=4)
        # The model must stay in front on measured points. Check hard residual
        # rather than minimizing an unrelated image-space regularizer.
        predicted=A[active]@fitted
        if np.median(predicted)<=0 or not np.isfinite(fitted).all():
            accepted.append(False);continue
        old=np.abs(A[active]@initial-d[active])
        new=np.abs(predicted-d[active])
        if np.median(new)>max(2.,1.15*np.median(old)):
            accepted.append(False);continue
        out[k]=.7*fitted+.3*initial
        accepted.append(True)
    return out,int(sum(accepted))


def _merge_consistent_planes(coef,labels,il,ir,xl,xr,nleft,conf):
    """Remove multiple plane IDs if a SINGLE jointly refitted model explains
    both sets of measured arcs. Compare at each group's *own* observation
    locations; a mean coefficient or depth threshold is not enough.
    """
    k=len(coef)
    if k<2:return coef,labels,0
    X=np.column_stack((xl[:,0],xl[:,1],np.ones(len(xl))))
    d=xl[:,0]-xr[:,0]
    owner_l=labels[il];owner_r=labels[ir+nleft]
    owner=np.where(owner_l==owner_r,owner_l,-1)
    parent=np.arange(k)
    for a in range(k):
        if parent[a]!=a:continue
        aid=np.flatnonzero(owner==a)
        if len(aid)<6:continue
        for b in range(a+1,k):
            if parent[b]!=b:continue
            bid=np.flatnonzero(owner==b)
            if len(bid)<6:continue
            # Either model's prediction must explain the other's actual
            # stereo arc evidence (not just lie nearby in the midpoint).
            ab=np.median(np.abs(X[aid]@coef[b]-d[aid]))
            ba=np.median(np.abs(X[bid]@coef[a]-d[bid]))
            if max(ab,ba)<.60:
                parent[b]=a
    if not np.any(parent!=np.arange(k)):return coef,labels,0
    mapping=np.full(k,-1,np.int32)
    reps=np.unique(parent)
    mapping[reps]=np.arange(len(reps))
    for b in range(k):mapping[b]=mapping[parent[b]]
    newlabels=labels.copy()
    good=newlabels>=0
    newlabels[good]=mapping[newlabels[good]]
    co=coef[reps].copy()
    return co,newlabels,k-len(reps)


def joint_solve(obs,matches,initial_coefficients,initial_sample_plane,progress=lambda _:None,
                rounds=4):
    """Return one global model + two sets of structurally coupled source plates.

    Plane coefficients parameterize d(x_left,y); conversion to world XYZ is
    performed once by the normal sheet solver after optimization.
    """
    left=np.asarray(matches.left_xy,np.float64)
    right=np.asarray(matches.right_xy,np.float64)
    conf=np.clip(np.asarray(matches.confidence,np.float32),.01,1.)
    labs=np.asarray(initial_sample_plane,np.int32)
    coef=np.asarray(initial_coefficients,np.float64).copy()
    lp,lstats=_observed_components(obs,'left',left,labs,conf,len(coef))
    rp,rstats=_observed_components(obs,'right',right,labs,conf,len(coef))
    nl=int(lp.max())+1;nr=int(rp.max())+1
    li=_sample_patch_ids(lp,left);ri=_sample_patch_ids(rp,right)
    # Direct measured support for cross-camera graph gating; weak native links
    # are not allowed to weld independently observed depth jumps.
    seed=np.full(nl+nr,-1,np.int32)
    vote=np.zeros((nl+nr,len(coef)),np.float32)
    valid=labs>=0
    for idx in (li,ri+nl):
        np.add.at(vote,(idx[valid],labs[valid]),conf[valid])
    enough=vote.max(axis=1)>0
    seed[enough]=vote[enough].argmax(axis=1)
    graph,cross_count=_rigid_joint_graph(obs,(lp,rp),li,ri,conf,seed)
    rounds_done=0;fit_count=0
    for iteration in range(rounds):
        likelihood,residual=_boundary_likelihood(left,right,coef,conf)
        labels,infos=_update_joint_labels(graph,li,ri,likelihood,conf,nl,nr,len(coef),
                                          current_labels=seed if iteration else None)
        newcoef,fit_count=_joint_refit_symmetric(coef,left,right,li,ri,labels,nl,conf)
        change=float(np.max(np.abs(newcoef-coef)))
        changed=int(np.count_nonzero(labels!=seed))
        coef=newcoef;seed=labels;rounds_done+=1
        progress(f'Joint world {iteration+1}: {fit_count} shared geometry models refit; '
                 f'{changed} changed source components, {infos["unanchored_patches"]} unanchored')
        if iteration>0 and changed==0 and change<.0005:break
    coef,labels,merged=_merge_consistent_planes(coef,labels,li,ri,left,right,nl,conf)
    # Remap each real source component; native L/VC/CC membership is untouched.
    lassign=labels[:nl];rassign=labels[nl:]
    # Recover per-boundary model ONLY when the two cameras jointly support it
    # and its residual agrees with the actually observed corresponding curves.
    choose_l=lassign[li];choose_r=rassign[ri]
    sample=np.where(choose_l==choose_r,choose_l,-1).astype(np.int32)
    valid=sample>=0
    aa=np.column_stack((left[:,0],left[:,1],np.ones(len(left))))
    error=np.full(len(left),np.inf)
    if valid.any():error[valid]=np.abs(np.sum(aa[valid]*coef[sample[valid]],axis=1)-
                                      (left[valid,0]-right[valid,0]))
    sample[error>2.6]=-1
    diagnostics=dict(geometry_optimizer='joint_two_camera_boundary_network_alternating_IRLS_graph',
        geometry_unknowns='common stereo supported plane coefficients AND source region ownership',
        original_domain_pixels_preserved=True,adjacency_not_forced_3D_continuity=True,
        both_camera_labels_optimized_simultaneously=True,
        source_RGB_disparity_map_received=False,nonsemantic=True,
        local_optimum_not_global_proof=True,
        optimizer_rounds=rounds_done,globally_refitted_models=fit_count,
        evidence_joined_camera_components=cross_count,
        merged_duplicate_geometry_models=merged,
        jointly_explained_boundary_samples=int(np.count_nonzero(sample>=0)),
        disagreement_boundary_samples=int(np.count_nonzero((choose_l>=0)&(choose_r>=0)&(choose_l!=choose_r))),
        left=lstats,right=rstats,**infos)
    return coef,lp,rp,lassign,rassign,sample,diagnostics
