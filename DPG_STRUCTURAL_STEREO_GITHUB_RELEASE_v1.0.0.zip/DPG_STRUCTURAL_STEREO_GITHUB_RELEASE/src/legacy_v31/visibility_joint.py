"""Visibility-aware iterated sheet refinement for two rectified cameras.

Estimate occlusion from the CURRENT common 3D sheet model. Contradictory
candidate correspondences are soft-rejected, then the *joint* plane and native
patch solver is run again. This is an alternating approximation, not proof of
global optimality. Geometry/visibility cannot each override a well-supported
stereo measurement solely on the basis of the same candidate.
"""
from __future__ import annotations
import numpy as np
import cv2
from world_render import source_geometry


def check_pair_visibility(world,matches,margin=.025):
    camera=world.camera
    planes=world.world_planes
    maps={'left':world.left_plane,'right':world.right_plane}
    geom={s:source_geometry(maps[s],planes,camera.focal,camera.cx,camera.cy,camera.baseline,s)
          for s in ('left','right')}
    n=len(matches.left_xy)
    rejected=np.zeros(n,bool)
    error_depth=np.zeros(n,np.float32)
    flags={}
    for src,dst,xy in (('left','right',matches.left_xy),('right','left',matches.right_xy)):
        h,w=maps[src].shape
        x=np.clip(np.rint(xy[:,0]).astype(np.int32),0,w-1)
        y=np.clip(np.rint(xy[:,1]).astype(np.int32),0,h-1)
        zsrc=geom[src][2][y,x]
        # Project the source sheet from its camera along the SAME calibrated
        # world ray into the other camera, with no RGB disparity field.
        sign=1. if src=='left' else -1.
        with np.errstate(divide='ignore',invalid='ignore'):
            tx=xy[:,0]-sign*camera.focal*camera.baseline/zsrc
        destination=geom[dst][2]
        pred=cv2.remap(destination,tx.astype(np.float32).reshape(1,-1),
                       xy[:,1].astype(np.float32).reshape(1,-1),
                       cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT,
                       borderValue=float('nan')).ravel()
        # Reject only CLEAR positive foreground conflicts, not missing data,
        # identity disagreement or boundary uncertainty.
        valid=(np.isfinite(zsrc)&np.isfinite(pred)&(zsrc>0)&(pred>0)&
               (tx>=0)&(tx<w))
        conflict=valid&(zsrc>pred*(1.+margin))
        rejected|=conflict
        error_depth=np.maximum(error_depth,np.where(valid,(zsrc-pred)/np.maximum(zsrc,1e-6),0.))
        flags[src]=int(conflict.sum())
    return rejected,error_depth,flags


def refine(obs,matches,camera,progress,*,max_rounds=1,initial_world=None):
    from .sheet_solver import solve as solve_world
    current=initial_world if initial_world is not None else solve_world(obs,matches,camera=camera,progress=progress)
    history=[]
    start_conf=matches.confidence.copy()
    for step in range(max_rounds):
        blocked,delta,flags=check_pair_visibility(current,matches)
        # Do not let a poorly-initialized plane suppress the entire set of
        # real correspondence evidence. Occlusion only vetoes geometrically
        # inconsistent minority measurements in each round.
        rejected_count=int(blocked.sum())
        fraction=float(blocked.mean()) if len(blocked) else 0.
        history.append(dict(iteration=step+1,rejected_candidates=rejected_count,
                            fraction=fraction,side_conflicts=flags))
        if rejected_count<8 or fraction>.38:
            break
        # Do not erase original matches or silently reclassify conflicts as
        # verified occlusions. Their confidence is lowered for the next solve.
        matches.confidence[blocked]=np.minimum(matches.confidence[blocked],.025)
        progress(f'Näkyvyyden yhteistarkennus {step+1}: {rejected_count} ristiriitaista pariehdokasta')
        try:
            current=solve_world(obs,matches,camera=camera,progress=progress)
        except Exception:
            matches.confidence[:]=start_conf
            raise
    remaining,delta,flags=check_pair_visibility(current,matches)
    return current,dict(strategy='alternating_visibility_and_shared_plane_assignment',
           approximation_not_global_optimum=True,iterations=history,
           remaining_visibility_conflicts=int(remaining.sum()),
           final_confidence_reductions=int((matches.confidence<start_conf).sum())),remaining
