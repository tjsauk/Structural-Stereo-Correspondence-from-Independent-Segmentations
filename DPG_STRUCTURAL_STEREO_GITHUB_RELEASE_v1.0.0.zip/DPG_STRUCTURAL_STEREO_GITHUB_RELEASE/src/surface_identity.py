"""V3: One world-surface identity and three observed visibility classes.

This module does NOT infer object semantics or use ground-truth depth.
One surface is a connected same-plane native sheet, optionally merged with
its other-camera observation by reliable, measured boundary correspondences.
Original L/VC/CC membership is retained independently of surface IDs.

Codes: 1 LEFT, 2 RIGHT, 3 BOTH. Zero is reserved for a *missing 2D pixel*,
not a fourth class of 3D geometry. Duplicated right-camera samples of the
same physical sheet are removed, rather than retained as parallel layers.
"""
from __future__ import annotations
import numpy as np
import cv2
from skimage.measure import label as connected_equal_labels
from world_render import source_geometry


def _source_component(plane_map):
    """A connected model surface, even across artificial DPG color seams."""
    # +1 makes non-negative plane 0 a foreground label.
    return (connected_equal_labels(np.asarray(plane_map,np.int32)+1,
                                   background=0,connectivity=1)-1).astype(np.int32)


def assign_surfaces(world,matches,*,min_support=3,min_confidence=.30):
    """Build cross-camera IDs only from jointly explained repeated arc pairs."""
    left=_source_component(world.left_plane)
    right=_source_component(world.right_plane)
    nl=int(left.max())+1;nr=int(right.max())+1
    parent=np.arange(nl+nr,dtype=np.int32)
    rank=np.zeros(nl+nr,np.uint8)
    def root(v):
        while parent[v]!=v:
            parent[v]=parent[parent[v]];v=int(parent[v])
        return int(v)
    def union(a,b):
        a=root(int(a));b=root(int(b))
        if a==b:return
        if rank[a]<rank[b]:a,b=b,a
        parent[b]=a
        if rank[a]==rank[b]:rank[a]+=1
    h,w=left.shape
    lx=np.clip(np.rint(matches.left_xy[:,0]).astype(np.int32),0,w-1)
    ly=np.clip(np.rint(matches.left_xy[:,1]).astype(np.int32),0,h-1)
    rx=np.clip(np.rint(matches.right_xy[:,0]).astype(np.int32),0,w-1)
    ry=np.clip(np.rint(matches.right_xy[:,1]).astype(np.int32),0,h-1)
    li=left[ly,lx];ri=right[ry,rx]
    lplane=world.left_plane[ly,lx];rplane=world.right_plane[ry,rx]
    common=np.asarray(world.sample_plane,np.int32)
    ok=(common>=0)&(lplane==rplane)&(lplane==common)&(li>=0)&(ri>=0)&\
       (np.asarray(matches.confidence)>=min_confidence)&\
       (np.abs(matches.left_xy[:,1]-matches.right_xy[:,1])<=1.5)
    # Exclude non-physical, huge reprojection residuals. Same-plane identity
    # cannot be established from merely close final rendered RGB samples.
    d=matches.left_xy[:,0]-matches.right_xy[:,0]
    coef=world.world_planes[lplane[ok]] if np.any(ok) else np.empty((0,3))
    idx=np.flatnonzero(ok)
    if len(idx):
        # world plane defines a physical disparity at LEFT view sample.
        yy=matches.left_xy[idx,1];xx=matches.left_xy[idx,0]
        plane=coef
        off=-.5*world.camera.baseline
        den=plane[:,0]*(xx-world.camera.cx)/world.camera.focal+\
            plane[:,1]*(yy-world.camera.cy)/world.camera.focal+plane[:,2]
        z=np.divide(1.-plane[:,0]*off,den,out=np.full(len(idx),np.nan),where=np.abs(den)>1.e-9)
        predicted=world.camera.focal*world.camera.baseline/z
        valid=np.isfinite(z)&(z>.001)&(np.abs(d[idx]-predicted)<2.8)
        idx=idx[valid]
    pairs=np.column_stack((li[idx],ri[idx]+nl)).astype(np.int64) if len(idx) else np.empty((0,2),np.int64)
    nlinks=0
    if len(pairs):
        unique,counts=np.unique(pairs,axis=0,return_counts=True)
        for (a,b),num in zip(unique,counts):
            if num>=min_support:
                union(a,b);nlinks+=1
    # A planar sheet can be identical between cameras even when the DPG
    # generates no corresponding appearance boundary. Join disconnected
    # camera charts ONLY when a forward projection of the ALREADY SOLVED
    # physical plane lands on the same plane and a compatible observed
    # depth in the opposite native view. This is not a pixel disparity
    # search; the candidate XYZ comes only from joint stereo plane models.
    planes=world.world_planes
    cam=world.camera
    geom_l=source_geometry(world.left_plane,planes,cam.focal,cam.cx,cam.cy,cam.baseline,'left')
    geom_r=source_geometry(world.right_plane,planes,cam.focal,cam.cx,cam.cy,cam.baseline,'right')
    yy,xx=np.mgrid[2:h:5,2:w:5]
    zl=geom_l[2][yy,xx]
    with np.errstate(divide='ignore',invalid='ignore'):
        xr=xx-cam.focal*cam.baseline/zl
    ri=np.rint(np.nan_to_num(xr,nan=-1e6)).astype(np.int32)
    inside=np.isfinite(zl)&(zl>.001)&(ri>=2)&(ri<w-2)
    ri=np.clip(ri,0,w-1)
    zr=geom_r[2][yy,ri]
    similar=inside&np.isfinite(zr)&(np.abs(zl-zr)<np.maximum(.003,.008*np.minimum(zl,zr)))&            (world.left_plane[yy,xx]==world.right_plane[yy,ri])
    comps=np.column_stack((left[yy[similar],xx[similar]],right[yy[similar],ri[similar]]+nl))
    overlap_links=0
    if len(comps):
        # Repeated interior support is necessary: one chance crossing does
        # not establish a shared surface identity or object identity.
        uniq,count=np.unique(comps,axis=0,return_counts=True)
        for (a,b),num in zip(uniq,count):
            if num>=5:
                union(a,b);overlap_links+=1
    roots=np.array([root(i) for i in range(nl+nr)],np.int32)
    _,mapping=np.unique(roots,return_inverse=True)
    lcomponent=mapping[:nl].astype(np.int32)
    rcomponent=mapping[nl:].astype(np.int32)
    identity={'left':lcomponent[left], 'right':rcomponent[right]}
    surface_count=int(len(np.unique(mapping)))
    report=dict(surface_ids=surface_count,camera_components_left=nl,
                camera_components_right=nr,stereo_linked_component_pairs=nlinks,
                same_plane_projection_overlap_links=overlap_links,
                cross_camera_links_evidence_only=True,
                same_plane_alone_never_joins_distant_components=True,
                object_semantics_inferred=False)
    return identity,report


def _target_camera_projection(source_z, yy, side, camera):
    h,w=source_z.shape
    xx=np.broadcast_to(np.arange(w,dtype=np.float32),(h,w))
    shift=camera.focal*camera.baseline/source_z
    target_x=xx-shift if side=='left' else xx+shift
    return np.nan_to_num(target_x,nan=-1e6,posinf=-1e6,neginf=-1e6).astype(np.float32)


def _target_agreement(geom,source_id,target_id,camera,source_side,depth_tolerance=.012):
    """Project an observed 3D sheet into the OTHER camera's native image.

    Agreement requires the *same physical surface ID*, geometric depth and
    valid image footprint. Opposite camera foreground implies occlusion.
    Opposite surface behind a source sheet that is **not** visible there
    signals an invalid cross-camera foreground prediction, not permission to
    overwrite that camera's real source observation.
    """
    source_z=np.asarray(geom[source_side][2],np.float32)
    target_side='right' if source_side=='left' else 'left'
    target_z=np.asarray(geom[target_side][2],np.float32)
    h,w=source_z.shape
    tx=_target_camera_projection(source_z,None,source_side,camera)
    # nearest pixel lookup avoids creating a dense disparity solution. All
    # 3D locations were already established by native element planes.
    xi=np.rint(tx).astype(np.int32)
    inside=(xi>=0)&(xi<w)&np.isfinite(source_z)&(source_z>.001)
    yy=np.broadcast_to(np.arange(h,dtype=np.int32)[:,None],(h,w))
    ix=np.clip(xi,0,w-1)
    dst_z=target_z[yy,ix]
    same_id=(source_id==target_id[yy,ix])&(source_id>=0)
    depth_agree=np.abs(source_z-dst_z)<=np.maximum(.003,depth_tolerance*np.minimum(source_z,dst_z))
    matched=inside&np.isfinite(dst_z)&same_id&depth_agree
    # False-front: a proposed sheet would be strictly in front of a *native*
    # observation in the other camera but is not that observed surface.
    false_front=inside&np.isfinite(dst_z)&(source_z<dst_z*.988)&~matched
    behind=inside&np.isfinite(dst_z)&(source_z>dst_z*1.012)
    return matched,false_front,behind,tx


def build_surface_atlas(images,world,identity,confidence=None,progress=lambda _:None):
    """Create ONE atlas, removing re-observed same-surface camera samples.

    All LEFT native pixels are represented once. RIGHT pixels which match
    the left native observation of the same 3D surface are deduplicated.
    Remaining RIGHT pixels form nonduplicated RIGHT-only samples. Every
    physical sample has exactly one visibility class, 1/2/3. The native
    RGB observations remain available in original left/right files.
    """
    camera=world.camera
    planes=world.world_planes
    maps={'left':world.left_plane,'right':world.right_plane}
    geom={s:source_geometry(maps[s],planes,camera.focal,camera.cx,camera.cy,
                            camera.baseline,s) for s in ('left','right')}
    lm,lf,lb,lt=_target_agreement(geom,identity['left'],identity['right'],camera,'left')
    rm,rf,rb,rt=_target_agreement(geom,identity['right'],identity['left'],camera,'right')
    h,w=maps['left'].shape
    ly,lx=np.indices((h,w),dtype=np.int32)
    # An R sample accepted into the corresponding left surface pixel makes
    # that LEFT sample BOTH, even if L->R maps between native R pixel centers.
    l_both=lm.copy()
    if np.any(rm):
        tx=np.rint(rt[rm]).astype(np.int32)
        ty=ly[rm]
        l_both[ty,np.clip(tx,0,w-1)]=True
    # Same-surface right samples are represented by left vertices. Do not
    # discard anything that lacks actual compatible left-native evidence.
    keep_right=geom['right'][3]&~rm
    keep_left=geom['left'][3]
    xyz=[];rgb=[];vid=[];sid=[];pid=[];sxy=[];source=[];eligible=[];prov=[]
    for s,mask,vis,front in (('left',keep_left,np.where(l_both,3,1),lf),
                             ('right',keep_right,np.full((h,w),2,np.uint8),rf)):
        mx,yy,z,valid=geom[s]
        y,x=np.nonzero(mask)
        dep=z[y,x]
        u=(x-camera.cx)/camera.focal
        off=(-.5 if s=='left' else .5)*camera.baseline
        xyz.append(np.column_stack((off+u*dep,(y-camera.cy)/camera.focal*dep,dep)).astype(np.float32))
        colors=np.asarray(images[0 if s=='left' else 1],np.uint8)[y,x].copy()
        if s=='left':
            both=l_both[y,x]
            if np.any(both):
                tx=lt[y[both],x[both]]
                yb=y[both].astype(np.float32)
                # cv2.remap is limited to 32767 columns, so a flattened
                # full-resolution matched point array is NOT a valid image.
                # Rows are rectified: interpolate only horizontally, directly.
                x0=np.clip(np.floor(tx).astype(np.int32),0,w-1)
                x1=np.minimum(x0+1,w-1)
                a=np.clip(tx-x0,0,1).astype(np.float32)
                row=y[both]
                other_rgb=np.asarray(images[1],np.float32)
                from_right=other_rgb[row,x0]*(1.-a[:,None])+other_rgb[row,x1]*a[:,None]
                colors[both]=np.clip((colors[both].astype(np.float32)+from_right)*.5+.5,0,255).astype(np.uint8)
        rgb.append(colors)
        vid.append(np.asarray(vis,np.uint8)[y,x])
        sid.append(np.asarray(identity[s],np.int32)[y,x])
        pid.append(maps[s][y,x].astype(np.int16))
        sxy.append(np.column_stack((x,y)).astype(np.uint16))
        source.append(np.full(len(x),0 if s=='left' else 1,np.uint8))
        # Preserve every original 3D observation as a possible midpoint
        # surface. Opposite-camera conflicts are diagnostics, NOT grounds
        # for erasing a one-camera-visible physical observation. In the fixed
        # source camera the atlas visibility bit still protects that view.
        eligible.append(np.ones(len(x),bool))
        if confidence is None:
            prov.append(np.zeros(len(x),np.uint8))
        else:prov.append(np.asarray(confidence[s],np.uint8)[y,x])
    atlas={'xyz':np.concatenate(xyz),'rgb':np.concatenate(rgb),
           'visibility':np.concatenate(vid),'surface_id':np.concatenate(sid),
           'plane_id':np.concatenate(pid),'source_xy':np.concatenate(sxy),
           'source_camera':np.concatenate(source),'midpoint_eligible':np.concatenate(eligible),
           'confidence':np.concatenate(prov)}
    assert atlas['xyz'].shape[0]==atlas['visibility'].shape[0]
    assert np.isin(atlas['visibility'],[1,2,3]).all()
    report=dict(total_unique_surface_samples=int(len(atlas['xyz'])),
                left_native_surface_samples=int(keep_left.sum()),
                right_only_extra_surface_samples=int(keep_right.sum()),
                deduplicated_other_camera_samples=int(rm.sum()),
                both_visible_left_source_samples=int(l_both.sum()),
                left_false_foreground_projections=int(lf.sum()),
                right_false_foreground_projections=int(rf.sum()),
                retained_for_original_camera_even_if_midpoint_conflict=True,
                visibility_classes={'left_only':int(np.count_nonzero(atlas['visibility']==1)),
                    'right_only':int(np.count_nonzero(atlas['visibility']==2)),
                    'both':int(np.count_nonzero(atlas['visibility']==3))},
                confirmed_reobservations_deduplicated=True,
                unverified_duplicate_free_geometry_not_proven=True)
    progress('Shared surface atlas: '+str(report['total_unique_surface_samples'])+
             ' observed points; matching duplicate camera observations removed '+
             str(report['deduplicated_other_camera_samples']))
    return atlas,geom,report
