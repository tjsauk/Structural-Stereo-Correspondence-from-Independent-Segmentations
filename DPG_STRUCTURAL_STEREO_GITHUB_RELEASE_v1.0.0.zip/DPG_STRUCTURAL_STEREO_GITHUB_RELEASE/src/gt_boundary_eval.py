"""Independent GT validation of original right-camera segmentation seams.

GT NEVER changes matching/plane fitting. Compare two projections of exactly the
same visible RIGHT-camera element seam: predicted right->left by solved planes,
and reference right->left by depth GT. A source-paired residual, same-element
symmetric nearest-contour error, 1/2/3px contour F1, and independently
observable coverage are reported. No invented correspondence for occluded areas.
"""
from __future__ import annotations
import numpy as np
from scipy.spatial import cKDTree
from native_observation import DOMAINS, native_edge_mask


def _summary(a:np.ndarray):
    if not len(a):
        return {'n':0,'mae_px':None,'median_px':None,'p90_px':None,
                'within_1px_pct':None,'within_2px_pct':None,'within_3px_pct':None}
    a=np.asarray(a,np.float32)
    return {'n':int(len(a)), 'mae_px':round(float(a.mean()),4),
            'median_px':round(float(np.median(a)),4),
            'p90_px':round(float(np.percentile(a,90)),4),
            'within_1px_pct':round(100.*float((a<=1).mean()),3),
            'within_2px_pct':round(100.*float((a<=2).mean()),3),
            'within_3px_pct':round(100.*float((a<=3).mean()),3)}


def evaluate_boundary_projection(labels:dict[str,np.ndarray], ref_left_x:np.ndarray,
                                 pred_left_x:np.ndarray, gt_checkable:np.ndarray,
                                 pred_valid:np.ndarray, *, max_neighbors=0):
    """Compare same-*source-element* projected edges on GT-checkable subset.

    labels: original right-camera label maps keyed L, VC, CC, with 0=empty.
    gt_checkable: *independent* GT usable mask (not conditioned on prediction).
    pred_valid: predicted geometry exists and projects to image.
    All masks are right-camera indexed. Coverage denominator is ALL original
    source seam pixels, including those outside GT and with missing predictions.
    """
    shape=ref_left_x.shape
    if any(v.shape!=shape for v in (pred_left_x,gt_checkable,pred_valid)):
        raise ValueError('GT boundary arrays must share original right-image shape')
    h,w=shape
    gt_checkable=(np.asarray(gt_checkable,bool)&np.isfinite(ref_left_x)&
                  (ref_left_x>=0)&(ref_left_x<w))
    pred_checkable=(np.asarray(pred_valid,bool)&np.isfinite(pred_left_x)&
                    (pred_left_x>=0)&(pred_left_x<w))
    # Coverage is measured in *unique original right-image boundary pixels*;
    # repeated DPG domain observations do not artificially triple coverage.
    union_seam=np.zeros(shape,bool)
    domain_counts=[]
    source_delta=[];boundary_to_gt=[];gt_to_boundary=[]
    unique_measured=np.zeros(shape,bool)
    unique_gt=np.zeros(shape,bool)
    for dom in DOMAINS:
        label=labels[dom]
        if label.shape!=shape:raise ValueError('GT boundary label shape mismatch')
        if not np.any(label>0):continue
        seam=native_edge_mask(label)&(label>0)
        union_seam|=seam
        sy,sx=np.nonzero(seam)
        if not len(sy):continue
        n_label=label[sy,sx]
        gt_here=gt_checkable[sy,sx]
        both_here=gt_here&pred_checkable[sy,sx]
        domain_counts.append(dict(domain=dom,total_source_samples=int(len(sy)),
                                  gt_checkable_samples=int(gt_here.sum()),
                                  measured_samples=int(both_here.sum())))
        if not both_here.any():continue
        iy=sy[both_here];ix=sx[both_here];owners=n_label[both_here]
        unique_gt[sy[gt_here],sx[gt_here]]=True
        unique_measured[iy,ix]=True
        # GT and predicted contours use SAME independent observable source subset.
        # Consequently missing GT never counts as a mismatch; missing predicted
        # geometry reduces coverage and is reported, not silently omitted.
        order=np.argsort(owners,kind='stable')
        owners=owners[order];iy=iy[order];ix=ix[order]
        splits=np.r_[0, np.flatnonzero(owners[1:]!=owners[:-1])+1, len(owners)]
        for j in range(len(splits)-1):
            a,b=int(splits[j]),int(splits[j+1])
            if b-a<3:continue
            yy=iy[a:b];xx=ix[a:b]
            g=np.column_stack([ref_left_x[yy,xx], yy]).astype(np.float32)
            p=np.column_stack([pred_left_x[yy,xx],yy]).astype(np.float32)
            # Image-coordinate Euclidean nearest distance, ID-constrained;
            # never reward an incorrect neighboring element's line.
            p_to_g=cKDTree(g).query(p,k=1,workers=1)[0].astype(np.float32)
            g_to_p=cKDTree(p).query(g,k=1,workers=1)[0].astype(np.float32)
            boundary_to_gt.append(p_to_g)
            gt_to_boundary.append(g_to_p)
            source_delta.append(np.abs(p[:,0]-g[:,0]))
    # Mark GT-verifiable edge pixels regardless of prediction and domain overlap.
    unique_gt|=union_seam&gt_checkable
    total=int(union_seam.sum())
    gt_n=int(unique_gt.sum()); checked=int(unique_measured.sum())
    a=np.concatenate(boundary_to_gt) if boundary_to_gt else np.empty(0,np.float32)
    b=np.concatenate(gt_to_boundary) if gt_to_boundary else np.empty(0,np.float32)
    source=np.concatenate(source_delta) if source_delta else np.empty(0,np.float32)
    result={
        'metric':'same_original_right_element_GT_vs_solved_projected_boundary_to_left',
        'GT_only_posthoc':True, 'gt_checkable_boundary_pixels':gt_n,
        'total_source_boundary_pixels':total,
        'checked_boundary_pixels':checked,
        'GT_observable_boundary_pct':round(100.*gt_n/max(1,total),3),
        'measured_boundary_pct':round(100.*checked/max(1,total),3),
        'predicted_valid_among_GT_boundary_pct':round(100.*checked/max(1,gt_n),3),
        'per_domain_samples':domain_counts,
        'source_indexed_error':_summary(source),
        'predicted_to_GT_distance':_summary(a),
        'GT_to_predicted_distance':_summary(b),
        'symmetric_boundary_mae_px':round(float((a.mean()+b.mean())/2),4) if len(a) and len(b) else None,
    }
    for tol in (1,2,3):
        precision=float((a<=tol).mean()) if len(a) else 0.
        recall=float((b<=tol).mean()) if len(b) else 0.
        f1=2.*precision*recall/(precision+recall) if precision+recall else 0.
        result[f'boundary_precision_{tol}px_pct']=round(100.*precision,3) if len(a) else None
        result[f'boundary_recall_{tol}px_pct']=round(100.*recall,3) if len(b) else None
        result[f'boundary_f1_{tol}px_pct']=round(100.*f1,3) if len(a) and len(b) else None
    return result


def gt_pair_support(matches:dict[str,np.ndarray], ref_left_x:np.ndarray,
                    gt_checkable:np.ndarray, *, tolerance_px=3.):
    """GT-consistency of solver's accepted source boundary correspondences.

    Not an independently labelled true-match recall: GT only validates whether
    accepted boundary sample endpoints are stereogeometrically consistent.
    """
    if not all(x in matches for x in ('left_xy','right_xy','confidence')):
        return {'accepted_pair_samples':0, 'GT_checked_pair_samples':0,
                'GT_checked_pair_pct':0.,'GT_consistent_pair_pct':None,'GT_pair_error_mae_px':None}
    L=np.asarray(matches['left_xy']);R=np.asarray(matches['right_xy'])
    confidence=np.asarray(matches['confidence'])
    accepted=confidence>=.30
    if 'kind' in matches:accepted &= np.asarray(matches['kind'])==0
    h,w=ref_left_x.shape
    rx=np.rint(R[:,0]).astype(np.int32);ry=np.rint(R[:,1]).astype(np.int32)
    inside=(rx>=0)&(rx<w)&(ry>=0)&(ry<h)
    ids=np.flatnonzero(accepted&inside)
    valid=ids[gt_checkable[ry[ids],rx[ids]]]
    total=int(accepted.sum())
    if not len(valid):
        return {'accepted_pair_samples':total,'GT_checked_pair_samples':0,
                'GT_checked_pair_pct':0.,'GT_consistent_pair_pct':None,'GT_pair_error_mae_px':None}
    error=np.abs(L[valid,0]-ref_left_x[ry[valid],rx[valid]])
    good=np.isfinite(error)
    error=error[good]
    return {'accepted_pair_samples':total,'GT_checked_pair_samples':int(len(error)),
            'GT_checked_pair_pct':round(100.*len(error)/max(1,total),3),
            'GT_consistent_pair_pct':round(100.*float((error<=tolerance_px).mean()),3) if len(error) else None,
            'GT_pair_error_mae_px':round(float(error.mean()),4) if len(error) else None}
