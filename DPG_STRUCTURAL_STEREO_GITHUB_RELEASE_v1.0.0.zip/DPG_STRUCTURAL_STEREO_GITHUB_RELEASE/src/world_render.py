"""CPU midpoint Z-compositing and 3D sampling of original DPG-supported sheets.

Nothing in here computes a stereo match or fits geometry. All XYZ values are
ray/plane intersections with already solved world planes. Left/right observations
are kept as distinct source layers and are merged only in the rendered view.
"""
from __future__ import annotations
import numpy as np
import cv2
from native_observation import DOMAINS,native_edge_mask,canonical_seam_mask


def source_geometry(plane_ids, planes, focal, cx, cy, baseline, side):
    """World XYZ of each camera pixel on its assigned physical plane.

    Camera centers: left=(-B/2,0,0), right=(+B/2,0,0).
    World plane equation: n.X=1.
    """
    ids=np.asarray(plane_ids,np.int32)
    h,w=ids.shape
    yy,xx=np.indices((h,w),dtype=np.float32)
    safe=np.clip(ids,0,len(planes)-1)
    normals=np.asarray(planes,dtype=np.float32)[safe]
    ox=(-.5 if side=='left' else .5)*baseline
    u=(xx-cx)/focal
    v=(yy-cy)/focal
    denom=normals[...,0]*u+normals[...,1]*v+normals[...,2]
    numerator=1.-normals[...,0]*ox
    with np.errstate(divide='ignore',invalid='ignore',over='ignore'):
        z=numerator/denom
        X=ox+u*z
        Y=v*z
        midx=cx+focal*X/z
    valid=(ids>=0)&np.isfinite(z)&np.isfinite(midx)&(z>.001)&(z<1e6)
    z=np.where(valid,z,np.nan).astype(np.float32)
    midx=np.where(valid,midx,np.nan).astype(np.float32)
    return midx,yy,z,valid


def _dest(midx,yy,valid,w,h,dx,dy):
    xf=np.nan_to_num(midx,nan=-1e6,posinf=-1e6,neginf=-1e6)
    xx=np.floor(xf).astype(np.int32)+dx
    y=np.asarray(yy,dtype=np.int32)+dy
    ok=valid&(xx>=0)&(xx<w)&(y>=0)&(y<h)
    return (y[ok].astype(np.int64)*w+xx[ok].astype(np.int64)),ok,xx


def render_midpoint(images,plane_ids,planes,camera,progress=lambda _:None):
    """Two-pass 2x2 Z-buffer rasterization (same physical plane in both views).

    RGB of jointly visible surfaces is a depth-consistent weighted average.
    Background proxies avoid black pixels but are labelled *unverified*.
    """
    h,w=images[0].shape[:2]
    f,cx,cy,B=camera.focal,camera.cx,camera.cy,camera.baseline
    geom={s:source_geometry(plane_ids[s],planes,f,cx,cy,B,s) for s in ('left','right')}
    zbuf=np.full(h*w,np.inf,dtype=np.float32)
    for s in ('left','right'):
        mx,yy,z,valid=geom[s]
        for dx in (0,1):
            for dy in (0,1):
                idx,sel,_=_dest(mx,yy,valid,w,h,dx,dy)
                if len(idx):np.minimum.at(zbuf,idx,z[sel])
    progress('Midpoint: Z-buffer ja kahden kameran RGB-yhdistely')
    sum_rgb=np.zeros((h*w,3),np.float32)
    weights=np.zeros(h*w,np.float32)
    coverage=np.zeros((2,h*w),np.uint8)
    for side_index,s in enumerate(('left','right')):
        mx,yy,z,valid=geom[s]
        source_rgb=np.asarray(images[side_index],np.float32)
        frac=np.nan_to_num(mx-np.floor(mx),nan=0.)
        for dx in (0,1):
            wx=frac if dx else (1.-frac)
            for dy in (0,1):
                idx,sel,_=_dest(mx,yy,valid,w,h,dx,dy)
                if not len(idx):continue
                near=(z[sel]<=zbuf[idx]+np.maximum(.002*zbuf[idx],1e-4))
                if not near.any():continue
                idx=idx[near]
                weighted=(wx[sel][near] * (.55 if dy else .45)).astype(np.float32)
                keep=weighted>0.01
                if not keep.any():continue
                idx=idx[keep];weighted=weighted[keep]
                np.add.at(weights,idx,weighted)
                rgb=source_rgb[sel][near][keep]
                for c in range(3):
                    sum_rgb[:,c]+=np.bincount(idx,weights=(rgb[:,c]*weighted),minlength=h*w).astype(np.float32)
                coverage[side_index,idx]=1
    out=np.zeros((h*w,3),np.uint8)
    filled=weights>0
    out[filled]=np.clip(sum_rgb[filled]/weights[filled,None]+.5,0,255).astype(np.uint8)
    unfilled=~filled
    # Every final display pixel receives RGB. Unknown regions are a clearly
    # marked background proxy, not a claimed reconstructed surface.
    out[unfilled]=np.asarray(images[0],np.uint8).reshape(-1,3)[unfilled]
    classmask=(coverage[0]+2*coverage[1]).reshape(h,w)
    classmask[unfilled.reshape(h,w)]=0
    return out.reshape(h,w,3),classmask,geom,dict(
        filled_by_3d_raster_pct=round(float(filled.mean()*100),3),
        background_proxy_pixels=int(unfilled.sum()),
        simultaneous_2view_projection_pct=round(float(np.mean(classmask==3)*100),3),
        notes='Code 3: both camera observations contribute only at matching Z; 1/2 single-camera, 0 unverified backdrop')


def project_boundary_masks(obs,planes,plane_ids,camera,geom, matches=None, sample_plane=None, surface_ids=None):
    """Render each native 2D contour ONCE in its source camera.

    Native matcher uses samples from BOTH sides of a seam. Visualization
    instead uses one deterministic canonical native source-pixel per seam.
    Stereo-supported paired samples are a distinct green class; their
    corresponding same-source blue/red pixels are consumed rather than drawn
    again as duplicate parallel lines. Unpaired source arc parts remain visible.
    Frame perimeter is never counted as a native seam.
    """
    h,w=obs['left_L'].shape
    layers={}
    is_pair=None
    if matches is not None and sample_plane is not None and len(matches.left_xy):
        ids=np.asarray(sample_plane,np.int32)
        kind=getattr(matches,'kind',None)
        if kind is None:kind=np.zeros(len(matches.left_xy),np.uint8)
        is_pair=(ids>=0)&(kind==0)&(matches.confidence>=.30)
        if surface_ids is not None:
            h0,w0=obs['left_L'].shape
            xleft=np.clip(np.rint(matches.left_xy[:,0]).astype(np.int32),0,w0-1)
            yleft=np.clip(np.rint(matches.left_xy[:,1]).astype(np.int32),0,h0-1)
            xright=np.clip(np.rint(matches.right_xy[:,0]).astype(np.int32),0,w0-1)
            yright=np.clip(np.rint(matches.right_xy[:,1]).astype(np.int32),0,h0-1)
            # Green means ONE shared physical surface, not merely two
            # nearly overlapping boundaries of independent sheets.
            is_pair &= (surface_ids['left'][yleft,xleft]==
                        surface_ids['right'][yright,xright])
    for domain_id,d in enumerate(DOMAINS):
        paired_sources={}
        if is_pair is not None:
            good=is_pair&(matches.domain==domain_id)
            for side,xy in (('left',matches.left_xy),('right',matches.right_xy)):
                at=np.zeros((h,w),np.uint8)
                pts=xy[good]
                if len(pts):
                    x=np.clip(np.rint(pts[:,0]).astype(np.int32),0,w-1)
                    y=np.clip(np.rint(pts[:,1]).astype(np.int32),0,h-1)
                    at[y,x]=1
                # A two-sided search sample can sit on either side of the
                # canonical seam pixel. This small 3x3 owner-independent
                # support test does not thicken the DISPLAYED contour.
                paired_sources[side]=cv2.dilate(at,np.ones((3,3),np.uint8))>0
        for side in ('left','right'):
            edge=canonical_seam_mask(obs[f'{side}_{d}'])
            if side in paired_sources:edge &= ~paired_sources[side]
            mx,yy,z,valid=geom[side]
            xx=np.rint(np.nan_to_num(mx,nan=-1e6)).astype(np.int32)
            mask=edge&valid&(xx>=0)&(xx<w)
            target=np.zeros((h,w),np.uint8)
            target[yy[mask].astype(np.int32),xx[mask]]=1
            layers[f'{d}_{side}']=target
        layers[f'{d}_common']=np.zeros((h,w),np.uint8)
        if is_pair is not None:
            good=is_pair&(matches.domain==domain_id)
            ll=matches.left_xy[good];rr=matches.right_xy[good]
            if len(ll):
                xm=.5*(ll[:,0]+rr[:,0]);ym=.5*(ll[:,1]+rr[:,1])
                goodcoords=(np.abs(ll[:,1]-rr[:,1])<=2)&(xm>=0)&(xm<w)&(ym>=0)&(ym<h)
                xi=np.clip(np.rint(xm[goodcoords]).astype(np.int32),0,w-1)
                yi=np.clip(np.rint(ym[goodcoords]).astype(np.int32),0,h-1)
                layers[f'{d}_common'][yi,xi]=1
    return layers


def opposite_visibility(plane_ids,planes,camera):
    """Approximate physical occlusion detection, not photometric inference."""
    from scipy.ndimage import map_coordinates
    geom={s:source_geometry(plane_ids[s],planes,camera.focal,camera.cx,camera.cy,camera.baseline,s)
          for s in ('left','right')}
    result={}
    for src,dst in (('left','right'),('right','left')):
        mx,yy,z,valid=geom[src]
        xf=np.nan_to_num(mx,nan=-1e5)
        # mid -> opposite camera (baseline shift w.r.t midpoint)
        sign=-.5 if dst=='left' else .5
        with np.errstate(divide='ignore',invalid='ignore'):
            destx=xf-sign*camera.focal*camera.baseline/z
        zx=geom[dst][2]
        depth_dst=cv2.remap(zx.astype(np.float32),np.nan_to_num(destx,nan=-1e5).astype(np.float32),
                            yy.astype(np.float32),cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
        inside=np.isfinite(destx)&(destx>=0)&(destx<z.shape[1])
        occluded=valid&inside&(depth_dst>0)&np.isfinite(depth_dst)&(z>depth_dst*1.005)
        not_seen=valid&(~inside|occluded)
        unknown=valid&inside&(~np.isfinite(depth_dst)|(depth_dst<=0))
        result[f'{src}_not_visible_from_other']=not_seen.astype(np.uint8)
        result[f'{src}_visibility_unknown']=unknown.astype(np.uint8)
        result[f'{src}_estimated_visible_other']=(valid&inside&(~occluded)&(~unknown)).astype(np.uint8)
    return result


def render_surface_atlas(atlas, source_left_rgb, camera, progress=lambda _:None):
    """V3 midpoint Z-raster of a SINGLE deduplicated physical-surface atlas.

    Two RGB observations were averaged *only at the same 3D surface sample*
    during atlas assembly. Close-but-different sheet hypotheses can never be
    averaged merely because their projected Z happens to be similar.

    The winning midpoint surface is chosen by Z, then splat colours are
    accumulated only from that *same* surface ID. This prevents cross-object
    ghosting at equal depths. Zero in the output mask means 2D background,
    not a fourth type of world surface.
    """
    xyz=np.asarray(atlas['xyz'],np.float32)
    rgb=np.asarray(atlas['rgb'],np.uint8)
    vis=np.asarray(atlas['visibility'],np.uint8)
    ids=np.asarray(atlas['surface_id'],np.int32)
    eligible=np.asarray(atlas['midpoint_eligible'],bool)
    h,w=np.asarray(source_left_rgb).shape[:2]
    size=h*w
    depth=xyz[:,2]
    with np.errstate(divide='ignore',invalid='ignore'):
        xmid=camera.cx+camera.focal*xyz[:,0]/depth
        ymid=camera.cy+camera.focal*xyz[:,1]/depth
    base_valid=eligible&(depth>.001)&np.isfinite(depth)&(depth<1e6)&\
        np.isfinite(xmid)&np.isfinite(ymid)
    # Reuse a compact projected point cloud for all four passes; no dense
    # stereo disparity volume is generated at any point.
    ix=np.floor(np.nan_to_num(xmid,nan=-99999)).astype(np.int32)
    iy=np.floor(np.nan_to_num(ymid,nan=-99999)).astype(np.int32)
    alpha_x=np.clip(np.nan_to_num(xmid-ix,nan=0),0,1).astype(np.float32)
    alpha_y=np.clip(np.nan_to_num(ymid-iy,nan=0),0,1).astype(np.float32)
    pix=np.arange(len(depth),dtype=np.int32)
    zbuf=np.full(size,np.inf,np.float32)
    def destinations(dx,dy):
        x=ix+dx;y=iy+dy
        good=base_valid&(x>=0)&(x<w)&(y>=0)&(y<h)
        return good,(y[good].astype(np.int64)*w+x[good].astype(np.int64))
    for dy in (0,1):
        for dx in (0,1):
            keep,target=destinations(dx,dy)
            if len(target):np.minimum.at(zbuf,target,depth[keep])
    # Select a deterministic depth winner per destination. It identifies one
    # physical surface; a competing (even coplanar) surface cannot join its
    # colour or visibility. Min original atlas index resolves exact Z ties.
    winner=np.full(size,np.iinfo(np.int32).max,np.int32)
    for dy in (0,1):
        for dx in (0,1):
            keep,target=destinations(dx,dy)
            if not len(target):continue
            z=depth[keep]
            at_min=np.abs(z-zbuf[target])<np.maximum(1.e-6,1.e-6*zbuf[target])
            if np.any(at_min):np.minimum.at(winner,target[at_min],pix[keep][at_min])
    found=winner<np.iinfo(np.int32).max
    surface_at=np.full(size,-1,np.int32)
    surface_at[found]=ids[winner[found]]
    rgb_sum=np.zeros((size,3),np.float32)
    weight=np.zeros(size,np.float32)
    classes=np.zeros(size,np.uint8)
    confidence_at=np.zeros(size,np.uint8)
    source_confidence=np.asarray(atlas.get('confidence',np.zeros(len(depth),np.uint8)),np.uint8)
    progress('Midpoint V3: unique 3D surfaces, depth test and per-surface RGB')
    for dy in (0,1):
        for dx in (0,1):
            keep,target=destinations(dx,dy)
            if not len(target):continue
            samples=pix[keep];z=depth[samples]
            same=(ids[samples]==surface_at[target])
            near=(z<=zbuf[target]+np.maximum(zbuf[target]*.003,1.e-4))
            use=same&near
            if not np.any(use):continue
            selected=samples[use];dest=target[use]
            wa=((alpha_x[selected] if dx else 1.-alpha_x[selected])*
                (alpha_y[selected] if dy else 1.-alpha_y[selected]))
            # Source sampling is not a texture atlas: splats of the SAME
            # physical surface should blend to avoid holes, not overwrite.
            wgt=np.asarray(wa,np.float32)
            accept=wgt>.001
            if not np.any(accept):continue
            dest=dest[accept];selected=selected[accept];wgt=wgt[accept]
            np.add.at(weight,dest,wgt)
            c=rgb[selected].astype(np.float32)
            for channel in range(3):
                rgb_sum[:,channel]+=np.bincount(dest,weights=c[:,channel]*wgt,
                                                 minlength=size).astype(np.float32)
            np.bitwise_or.at(classes,dest,vis[selected])
            np.maximum.at(confidence_at,dest,source_confidence[selected])
    filled=weight>0
    output=np.asarray(source_left_rgb,np.uint8).reshape(size,3).copy()
    output[filled]=np.clip(rgb_sum[filled]/weight[filled,None]+.5,0,255).astype(np.uint8)
    classes[~filled]=0
    # Raster-only repair of SMALL holes fully enclosed by the SAME 3D sheet.
    # No unknown background pixel is declared 3D merely because neighbouring
    # colours look similar. This continues an already fitted planar surface
    # across a subpixel sampling void, never across a surface-ID boundary.
    planar_raster_fills=0
    out3=output.reshape(h,w,3)
    state=classes.reshape(h,w)
    prov=confidence_at.reshape(h,w)
    sheet=surface_at.reshape(h,w)
    valid=filled.reshape(h,w)
    for _ in range(2):
        neighbour_ids=[];neighbour_valid=[];neighbour_rgb=[];neighbour_state=[];neighbour_conf=[]
        for ys,xs,yt,xt in ((slice(1,None),slice(None),slice(None,-1),slice(None)),
                            (slice(None,-1),slice(None),slice(1,None),slice(None)),
                            (slice(None),slice(1,None),slice(None),slice(None,-1)),
                            (slice(None),slice(None,-1),slice(None),slice(1,None))):
            ids_n=np.full((h,w),-1,np.int32)
            valid_n=np.zeros((h,w),bool)
            rgb_n=np.zeros((h,w,3),np.uint16)
            state_n=np.zeros((h,w),np.uint8)
            conf_n=np.zeros((h,w),np.uint8)
            ids_n[ys,xs]=sheet[yt,xt];valid_n[ys,xs]=valid[yt,xt]
            rgb_n[ys,xs]=out3[yt,xt].astype(np.uint16)*valid[yt,xt][...,None]
            state_n[ys,xs]=state[yt,xt]*valid[yt,xt]
            conf_n[ys,xs]=prov[yt,xt]*valid[yt,xt]
            neighbour_ids.append(ids_n);neighbour_valid.append(valid_n)
            neighbour_rgb.append(rgb_n);neighbour_state.append(state_n);neighbour_conf.append(conf_n)
        stack=np.stack(neighbour_ids,axis=0)
        good=np.stack(neighbour_valid,axis=0)
        first=np.max(np.where(good,stack,-1),axis=0)
        count=good.sum(axis=0)
        same=(np.all((~good)|(stack==first[None]),axis=0))
        hole=(~valid)&(count>=3)&same&(first>=0)
        if not np.any(hole):break
        cols=np.sum(np.stack(neighbour_rgb,axis=0),axis=0)
        filled_rgb=np.clip(cols/np.maximum(count[...,None],1)+.5,0,255).astype(np.uint8)
        out3[hole]=filled_rgb[hole]
        combined=np.bitwise_or.reduce(np.stack(neighbour_state,axis=0),axis=0)
        state[hole]=combined[hole]
        # Raster extrapolation is NOT fresh stereo evidence. Even if the
        # enclosing samples were stereo-supported, classify fill as inferred.
        near_conf=np.max(np.stack(neighbour_conf,axis=0),axis=0)
        prov[hole]=np.minimum(near_conf[hole],1)
        sheet[hole]=first[hole]
        valid[hole]=True
        planar_raster_fills+=int(hole.sum())
    filled=valid.ravel()
    classes=state.ravel()
    confidence_at=prov.ravel()
    report=dict(filled_by_3d_raster_pct=round(float(filled.mean()*100),3),
        background_proxy_pixels=int((~filled).sum()),
        simultaneous_2view_projection_pct=round(float(np.mean(classes==3)*100),3),
        surface_identity_gated_rgb=True,all_world_samples_one_visibility_class=True,
        source_layers_not_rendered_as_duplicate_world_surfaces=True,
        native_source_rgb_background_is_not_a_3d_sheet=True,
        planar_raster_interior_fill_pixels=int(planar_raster_fills))
    return output.reshape(h,w,3),classes.reshape(h,w),report,confidence_at.reshape(h,w)
