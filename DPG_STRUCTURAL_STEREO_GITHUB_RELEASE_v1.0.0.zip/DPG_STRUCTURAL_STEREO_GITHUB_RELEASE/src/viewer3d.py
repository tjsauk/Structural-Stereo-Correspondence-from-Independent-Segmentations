"""Continuous CPU surface viewer without source-sample downsampling.
Mouse drag and camera pose selectors use surface homographies, not point splats.
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from pathlib import Path
import numpy as np
from PIL import Image,ImageTk
from surface_viewer_raster import render_planes
from sheet_solver import Camera

class Viewer3D:
    def __init__(self,parent,fd):
        fd=Path(fd)
        with np.load(fd/'world.npz',allow_pickle=False) as z:
            self.camera=Camera(*[float(z[k]) for k in ('focal','cx','cy','baseline')])
            self.planes=z['planes'].copy()
            self.maps={s:z[s+'_plane'].copy() for s in ('left','right')}
        with np.load(fd/'surface_identity.npz',allow_pickle=False) as z:
            self.identities={s:z[s+'_surface_id'].copy() for s in ('left','right')}
        self.images={s:np.asarray(Image.open(fd/(s+'.png')).convert('RGB')) for s in ('left','right')}
        self.source_shape=self.images['left'].shape[:2]
        self.win=tk.Toplevel(parent)
        self.win.title('Structural Stereo - 3D surfaces')
        self.win.geometry('1150x790')
        self.mode='orbit';self.yaw=0.;self.pitch=0.
        self.pan=np.zeros(2,np.float64)
        self.center=np.array([0,0,3.],np.float64)
        self.distance=4.
        self._photo=None;self._pending=False;self._last=(0,0)
        row=ttk.Frame(self.win,padding=6);row.pack(fill='x')
        ttk.Label(row,text='Left drag: rotate | Right drag: pan | Wheel: zoom | R: reset').pack(side='left',padx=4)
        ttk.Button(row,text='Left camera',command=lambda:self.set_camera('left')).pack(side='right',padx=3)
        ttk.Button(row,text='Right camera',command=lambda:self.set_camera('right')).pack(side='right',padx=3)
        ttk.Button(row,text='Midpoint',command=lambda:self.set_camera('midpoint')).pack(side='right',padx=3)
        ttk.Button(row,text='Free 3D',command=self.reset).pack(side='right',padx=3)
        self.info=ttk.Label(self.win,text='Continuous 3D surface rasterization')
        self.info.pack(fill='x',padx=8)
        self.canvas=tk.Canvas(self.win,bg='#181c22',highlightthickness=0)
        self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Configure>',lambda e:self._queue())
        self.canvas.bind('<ButtonPress-1>',lambda e:self._mark(e))
        self.canvas.bind('<B1-Motion>',self._rotate)
        self.canvas.bind('<ButtonPress-3>',lambda e:self._mark(e))
        self.canvas.bind('<B3-Motion>',self._move)
        self.canvas.bind('<MouseWheel>',self._wheel)
        self.canvas.bind('<Button-4>',lambda e:self._wheel(e,1))
        self.canvas.bind('<Button-5>',lambda e:self._wheel(e,-1))
        self.win.bind('r',lambda e:self.reset());self.win.bind('R',lambda e:self.reset())
        self._choose_orbit_center()
        self._queue()
    def _choose_orbit_center(self):
        # Use a small random-free grid of ORIGINAL full-size plane samples
        # only to position the orbit camera; never for display rendering.
        samples=[];h,w=self.source_shape
        y,x=np.mgrid[0:h:24,0:w:24].astype(np.float64)
        for side in ('left','right'):
            ids=self.maps[side][::24,::24]
            ok=ids>=0
            if not np.any(ok):continue
            n=self.planes[np.clip(ids,0,len(self.planes)-1)]
            ox=(-.5 if side=='left' else .5)*self.camera.baseline
            u=(x-self.camera.cx)/self.camera.focal;v=(y-self.camera.cy)/self.camera.focal
            with np.errstate(divide='ignore',invalid='ignore'):
                z=(1.-n[...,0]*ox)/(n[...,0]*u+n[...,1]*v+n[...,2])
            good=ok&np.isfinite(z)&(z>.01)&(z<1e5)
            if np.any(good):samples.append(np.column_stack([ox+u[good]*z[good],v[good]*z[good],z[good]]))
        if not samples:return
        pts=np.concatenate(samples)
        high=np.quantile(pts[:,2],.985)
        pts=pts[pts[:,2]<=high]
        if len(pts):
            self.center=np.median(pts,axis=0)
            spread=np.quantile(pts,.92,axis=0)-np.quantile(pts,.08,axis=0)
            self.distance=max(.4,float(np.linalg.norm(spread))*1.25)
    def _mark(self,e):self._last=(e.x,e.y)
    def _rotate(self,e):
        if self.mode!='orbit':self.reset()
        dx=e.x-self._last[0];dy=e.y-self._last[1];self._last=(e.x,e.y)
        self.yaw+=dx*.007;self.pitch=np.clip(self.pitch+dy*.007,-1.52,1.52)
        self._queue()
    def _move(self,e):
        if self.mode!='orbit':self.reset()
        dx=e.x-self._last[0];dy=e.y-self._last[1];self._last=(e.x,e.y)
        self.pan+=np.array([dx,dy])*self.distance/max(self.canvas.winfo_height(),250)
        self._queue()
    def _wheel(self,e,override=None):
        if self.mode!='orbit':self.reset()
        d=override if override is not None else (1 if e.delta>0 else -1)
        self.distance=np.clip(self.distance*(.85 if d>0 else 1/.85),.02,1e5)
        self._queue()
    def set_camera(self,mode):self.mode=mode;self._queue()
    def reset(self):self.mode='orbit';self.yaw=0;self.pitch=0;self.pan[:]=0;self._queue()
    def _queue(self):
        if self._pending:return
        self._pending=True;self.win.after(85,self._render)
    def _render(self):
        self._pending=False
        if not self.win.winfo_exists():return
        w=max(self.canvas.winfo_width(),64);h=max(self.canvas.winfo_height(),64)
        if self.mode in ('left','right','midpoint'):
            camx={'left':-.5*self.camera.baseline,'right':.5*self.camera.baseline,'midpoint':0.}[self.mode]
            C=np.array([camx,0,0],np.float64);R=np.eye(3)
            ih,iw=self.source_shape;scale=min(w/iw,h/ih)
            focal=self.camera.focal*scale
            cx=(w-iw*scale)*.5+self.camera.cx*scale
            cy=(h-ih*scale)*.5+self.camera.cy*scale
            sides=('left',) if self.mode=='left' else (('right',) if self.mode=='right' else ('left','right'))
        else:
            cyaw=np.cos(self.yaw);syaw=np.sin(self.yaw)
            cp=np.cos(self.pitch);sp=np.sin(self.pitch)
            R=np.array([[cyaw,0,-syaw],[sp*syaw,cp,sp*cyaw],[cp*syaw,-sp,cp*cyaw]],np.float64)
            C=self.center-R.T@np.array([self.pan[0],self.pan[1],self.distance])
            focal=.95*min(w,h);cx=w*.5;cy=h*.5;sides=('left','right')
        img,present,ids=render_planes(self.images,self.maps,self.planes,self.identities,
                       self.camera,C,R,w,h,focal,cx,cy,use_sides=sides)
        self.info.configure(text=f'{len(self.planes)} 3D planes | {np.count_nonzero(present):,} visible pixels | '
                            'continuous surface rasterization')
        self._photo=ImageTk.PhotoImage(Image.fromarray(img))
        self.canvas.delete('all');self.canvas.create_image(0,0,anchor='nw',image=self._photo)
