from __future__ import annotations

"""Domain Parent Grouping engine.

Reusable sensor-grounded parent grouping with optional parent-local child
queries. This module has no Visual Frame, experiment-GUI or versioned-project
imports.
"""

import colorsys
from functools import lru_cache
import math
import threading
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
try:
    import cv2
    HAS_CV2 = True
except ImportError:
    cv2 = None
    HAS_CV2 = False
from PIL import Image
from scipy import ndimage as ndi
from skimage.measure import label as label_equal_classes

EPS = 1e-08

DOMAIN_NAMES = ('Luminance', 'Vector Color', 'Consistency')

@dataclass
class FastCoreParams:
    lum_mean_window: int = 15
    lum_tau_base: float = 0.042
    lum_tau_std_scale: float = 0.85
    lum_dominance_scale: float = 0.09
    lum_assim_strength: float = 0.56
    lum_contrast_strength: float = 0.2
    lum_k_classes: int = 10
    lum_min_size_base: int = 65
    lum_min_size_div: int = 3500
    color_mean_window: int = 15
    color_tau_base: float = 0.045
    color_tau_std_scale: float = 0.85
    color_dominance_scale: float = 0.08
    color_assim_strength: float = 0.54
    color_contrast_strength: float = 0.36
    color_tau_sat: float = 0.06  # Euclidean distance to gray axis
    color_tau_strong: float = 0.12
    cc_component_mean_gate: bool = True  # CC-only v1.5.8 extra mean evidence
    color_local_neutral_support: bool = True  # shared VC/CC: weak chroma must beat nearby achromatic evidence
    color_tau_black: float = 0.13
    color_tau_white: float = 0.68
    color_k_chromatic: int = 12
    color_min_size_base: int = 45
    color_min_size_div: int = 3200
    # Enable global CC compensation only for a detected dominant tint
    # whose gray-axis radial distance exceeds this threshold.
    cc_global_tint_min_radius: float = 0.12
    use_local_vector_field: bool = False
    cons_alpha: float = 0.75
    cons_sample_stride: int = 2
    parent_min_overlap_px: int = 1
    parent_overlap_half_smaller_group: bool = False
    absorb_unassigned_pixels: bool = False
    keep_float_fields: bool = False
    make_visuals: bool = True
    capture_color_stages: bool = False  # diagnostics only; no overhead in normal processing
    processing_max_dim: int = 1100

def as_float_rgb(rgb: np.ndarray) -> np.ndarray:
    arr = np.asarray(rgb)
    if arr.ndim != 3 or arr.shape[2] < 3:
        raise ValueError('Input must be an H x W x 3 RGB array.')
    arr = arr[:, :, :3]
    if arr.dtype == np.uint8:
        return np.ascontiguousarray(arr, dtype=np.float32) / 255.0
    arr = np.ascontiguousarray(arr, dtype=np.float32)
    if float(np.nanmax(arr)) > 1.5:
        arr = arr / 255.0
    return np.clip(arr, 0.0, 1.0).astype(np.float32, copy=False)

def clamp01(x):
    return np.clip(x, 0.0, 1.0)

def luminance(rgb: np.ndarray) -> np.ndarray:
    return (0.2126 * rgb[:, :, 0] + 0.7152 * rgb[:, :, 1] + 0.0722 * rgb[:, :, 2]).astype(np.float32, copy=False)

def gray_to_u8_rgb(gray: np.ndarray) -> np.ndarray:
    g = (clamp01(gray) * 255.0).astype(np.uint8)
    return np.repeat(g[:, :, None], 3, axis=2)

def rgb_float_to_u8(rgb: np.ndarray) -> np.ndarray:
    return (clamp01(rgb) * 255.0).astype(np.uint8)

def resize_rgb_u8_maxdim(rgb_u8: np.ndarray, max_dim: int) -> Tuple[np.ndarray, float]:
    h, w = rgb_u8.shape[:2]
    max_dim = int(max_dim)
    if max_dim <= 0 or max(h, w) <= max_dim:
        return (np.ascontiguousarray(rgb_u8), 1.0)
    scale = float(max_dim) / float(max(h, w))
    nw = max(1, int(round(w * scale)))
    nh = max(1, int(round(h * scale)))
    pil = Image.fromarray(np.asarray(rgb_u8, dtype=np.uint8), mode='RGB')
    pil = pil.resize((nw, nh), Image.Resampling.BILINEAR)
    return (np.asarray(pil, dtype=np.uint8), scale)

def resize_bool_mask(mask: np.ndarray, shape: Tuple[int, int]) -> np.ndarray:
    """Resize a validity mask with nearest-neighbour sampling."""
    mask = np.asarray(mask, dtype=bool)
    h, w = (int(shape[0]), int(shape[1]))
    if mask.shape == (h, w):
        return np.ascontiguousarray(mask)
    pil = Image.fromarray(mask.astype(np.uint8) * 255, mode='L')
    pil = pil.resize((w, h), Image.Resampling.NEAREST)
    return np.asarray(pil, dtype=np.uint8) > 0

def _palette_color_u8(index: int, seed: int=0) -> np.ndarray:
    golden = 0.618033988749895
    h = (index * golden + 0.137 * seed) % 1.0
    s = 0.72 + 0.18 * ((index * 37 + seed) % 3) / 2.0
    v = 0.8 + 0.18 * ((index * 53 + seed) % 2)
    r, g, b = colorsys.hsv_to_rgb(float(h), float(s), float(v))
    return np.asarray([int(r * 255), int(g * 255), int(b * 255)], dtype=np.uint8)

def colorize_labels_fast_u8(labels: np.ndarray, seed: int=0) -> np.ndarray:
    labels = np.asarray(labels, dtype=np.int32)
    n = int(labels.max()) if labels.size else 0
    pal = np.zeros((n + 1, 3), dtype=np.uint8)
    pal[0] = np.asarray([13, 13, 13], dtype=np.uint8)
    for i in range(1, n + 1):
        pal[i] = _palette_color_u8(i, seed=seed)
    return pal[np.clip(labels, 0, n)]

def quantize_scalar_classes(field: np.ndarray, k: int) -> np.ndarray:
    k = max(2, int(k))
    cls = np.floor(clamp01(field) * k).astype(np.int32) + 1
    cls[cls > k] = k
    return cls

def components_from_classes_fast(classes: np.ndarray, min_size: int=25, absorb_unassigned: bool=False) -> np.ndarray:
    """
    Connected components per class.

    Fast path uses OpenCV when available. Fallback is scipy.ndimage.label.
    Rejected tiny regions remain 0; this avoids the expensive
    distance-transform fill.
    """
    classes = np.asarray(classes, dtype=np.int32)
    out = np.zeros(classes.shape, dtype=np.int32)
    min_size = int(max(1, min_size))
    nxt = 1
    uniq = np.unique(classes)
    uniq = uniq[uniq > 0]
    structure = np.ones((3, 3), dtype=np.int8)
    for c in uniq:
        lab, n = ndi.label(classes == int(c), structure=structure)
        if n == 0:
            continue
        counts = np.bincount(lab.ravel())
        valid = np.flatnonzero(counts >= min_size)
        valid = valid[valid > 0]
        if len(valid) == 0:
            continue
        lut = np.zeros(n + 1, dtype=np.int32)
        lut[valid] = np.arange(nxt, nxt + len(valid), dtype=np.int32)
        mapped = lut[lab]
        m = mapped > 0
        out[m] = mapped[m]
        nxt += len(valid)
    if absorb_unassigned and nxt > 1:
        unassigned = out == 0
        if np.any(unassigned):
            nearest = ndi.distance_transform_edt(unassigned, return_distances=False, return_indices=True)
            out[unassigned] = out[tuple((axis[unassigned] for axis in nearest))]
    return out

def components_from_classes_single_pass(classes: np.ndarray, min_size: int=25,
                                        absorb_unassigned: bool=False) -> np.ndarray:
    """Exact same 8-connected class regions as components_from_classes_fast.

    A single equal-valued labeling pass replaces one full-image ndimage scan
    per color class; only arbitrary positive group ID numbering is different.
    Kept specific to VC/CC so original L grouping behavior stays untouched.
    """
    labels = label_equal_classes(np.asarray(classes, dtype=np.int16), background=0,
                                 connectivity=2).astype(np.int32, copy=False)
    if labels.size == 0:
        return labels
    counts = np.bincount(labels.ravel())
    good = np.flatnonzero(counts >= max(1, int(min_size)))
    good = good[good != 0]
    lut = np.zeros(counts.size, dtype=np.int32)
    lut[good] = np.arange(1, len(good) + 1, dtype=np.int32)
    out = lut[labels]
    if absorb_unassigned and good.size:
        missing = out == 0
        if np.any(missing):
            nearest = ndi.distance_transform_edt(missing, return_distances=False,
                                                 return_indices=True)
            out[missing] = out[tuple(v[missing] for v in nearest)]
    return out


def box_filter_float32(arr: np.ndarray, size: int) -> np.ndarray:
    size = max(3, int(size) | 1)
    arr = np.asarray(arr, dtype=np.float32)
    if HAS_CV2:
        return cv2.blur(arr, (size, size), borderType=cv2.BORDER_REFLECT).astype(np.float32, copy=False)
    return ndi.uniform_filter(arr, size=size, mode='reflect').astype(np.float32, copy=False)

def masked_local_mean_and_second(values: np.ndarray, valid_mask: np.ndarray, size: int) -> Tuple[np.ndarray, np.ndarray]:
    """Calculate local moments while giving invalid pixels zero weight."""
    valid_f = np.asarray(valid_mask, dtype=np.float32)
    weight = box_filter_float32(valid_f, size)
    safe_weight = np.maximum(weight, EPS)
    mean = box_filter_float32(values * valid_f, size) / safe_weight
    mean2 = box_filter_float32(values * values * valid_f, size) / safe_weight
    return (mean.astype(np.float32, copy=False), mean2.astype(np.float32, copy=False))

def run_luminance_fast(rgb: np.ndarray, p: FastCoreParams, valid_mask: Optional[np.ndarray]=None) -> Dict[str, Any]:
    Y = luminance(rgb)
    valid = np.ones(Y.shape, dtype=bool) if valid_mask is None else np.asarray(valid_mask, dtype=bool)
    if valid.shape != Y.shape:
        raise ValueError('valid_mask must match the processed image shape.')
    if not np.any(valid):
        raise ValueError('The valid input mask contains no pixels.')
    w = max(3, int(p.lum_mean_window) | 1)
    meanY, meanY2 = masked_local_mean_and_second(Y, valid, w)
    stdY = np.sqrt(np.maximum(meanY2 - meanY * meanY, 0.0)).astype(np.float32, copy=False)
    tau = p.lum_tau_base + p.lum_tau_std_scale * stdY
    dominance = np.exp(-stdY / max(p.lum_dominance_scale, 1e-06)).astype(np.float32, copy=False)
    dY = Y - meanY
    field = np.where(np.abs(dY) < tau, Y + p.lum_assim_strength * dominance * (meanY - Y), Y + p.lum_contrast_strength * dominance * dY)
    field = clamp01(field).astype(np.float32, copy=False)
    field[~valid] = 0.0
    valid_values = field[valid]
    field_min = float(np.min(valid_values))
    field_max = float(np.max(valid_values))
    span = field_max - field_min
    relative_field = np.zeros_like(field, dtype=np.float32)
    if span > EPS:
        relative_field[valid] = (valid_values - field_min) / span
    classes = quantize_scalar_classes(relative_field, p.lum_k_classes)
    classes[~valid] = 0
    valid_count = int(np.count_nonzero(valid))
    min_size = max(int(p.lum_min_size_base), int(valid_count // max(p.lum_min_size_div, 1)))
    groups = components_from_classes_fast(classes, min_size=min_size, absorb_unassigned=p.absorb_unassigned_pixels)
    groups[~valid] = 0
    res = {'classes': classes.astype(np.int16, copy=False), 'groups': groups, 'group_count': int(groups.max()), 'min_size': int(min_size), 'relative_min': field_min, 'relative_max': field_max, 'field_gray': field, 'relative_field_gray': relative_field}
    if p.make_visuals:
        res['field_rgb'] = gray_to_u8_rgb(relative_field)
        res['groups_rgb'] = colorize_labels_fast_u8(groups, seed=1)
    return res

def run_vector_color_field_fast(rgb_input: np.ndarray, p: FastCoreParams, valid_mask: Optional[np.ndarray]=None) -> np.ndarray:
    V = rgb_input.astype(np.float32, copy=True)
    valid = np.ones(V.shape[:2], dtype=bool) if valid_mask is None else np.asarray(valid_mask, dtype=bool)
    w = max(3, int(p.color_mean_window) | 1)
    meanV = np.empty_like(V, dtype=np.float32)
    for ch in range(3):
        meanV[:, :, ch], _ = masked_local_mean_and_second(V[:, :, ch], valid, w)
    dV = V - meanV
    D2 = np.sum(dV * dV, axis=2).astype(np.float32, copy=False)
    D = np.sqrt(D2).astype(np.float32, copy=False)
    stdV = np.sqrt(np.maximum(box_filter_float32(D2, w), 0.0)).astype(np.float32, copy=False)
    tau = p.color_tau_base + p.color_tau_std_scale * stdV
    dominance = np.exp(-stdV / max(p.color_dominance_scale, 1e-06)).astype(np.float32, copy=False)
    out = np.where((D < tau)[:, :, None], V + p.color_assim_strength * dominance[:, :, None] * (meanV - V), V + p.color_contrast_strength * dominance[:, :, None] * dV).astype(np.float32, copy=False)
    out = clamp01(out)
    return out.astype(np.float32, copy=False)

# Orthonormal RGB plane perpendicular to the black-white (1,1,1) axis.
# Coordinates are consistent with estimate_comp_vector_fast (CC tint offset).
_COLOR_EA = np.asarray([1.0, -1.0, 0.0], dtype=np.float32) / np.sqrt(2.0)
_COLOR_EB = np.asarray([1.0, 1.0, -2.0], dtype=np.float32) / np.sqrt(6.0)
_LUM_WEIGHTS = np.asarray([0.2126, 0.7152, 0.0722], dtype=np.float32)


def _neighbor_hue_support(initial_hues: np.ndarray, region: np.ndarray,
                          strong: np.ndarray, k: int) -> Tuple[np.ndarray, np.ndarray]:
    """Strong same/adjacent-hue *element* neighbors via 8-connected contacts.

    The region is a connected set of pixels of one initial hue. Looking up
    the maximum chroma over an entire region (not just a local pixel window)
    makes the result independent of segmentation traversal order.
    """
    prev = np.zeros(strong.size, dtype=bool)
    nxt = np.zeros(strong.size, dtype=bool)
    for dy, dx in ((0, 1), (1, 0), (1, 1), (1, -1)):
        if dx >= 0:
            a = region[:-dy or None, :-dx or None]
            b = region[dy:, dx:]
        else:
            a = region[:-dy or None, -dx:]
            b = region[dy:, :dx]
        ga = a.ravel()
        gb = b.ravel()
        edge = (ga != gb) & (ga > 0) & (gb > 0)
        if not np.any(edge):
            continue
        ga, gb = ga[edge], gb[edge]
        # Each pixel knows its initial class; no group->hue table needed.
        if dx >= 0:
            ha, hb = initial_hues[:-dy or None, :-dx or None], initial_hues[dy:, dx:]
        else:
            ha, hb = initial_hues[:-dy or None, -dx:], initial_hues[dy:, :dx]
        ca, cb = ha.ravel()[edge], hb.ravel()[edge]
        ahead = cb == ((ca + 1) % k)
        behind = cb == ((ca - 1) % k)
        # Each undirected contact contributes evidence in both directions.
        if np.any(ahead):
            nxt[np.unique(ga[ahead & strong[gb]])] = True
            prev[np.unique(gb[ahead & strong[ga]])] = True
        if np.any(behind):
            prev[np.unique(ga[behind & strong[gb]])] = True
            nxt[np.unique(gb[behind & strong[ga]])] = True
    return prev, nxt


def _hue_components(hue: np.ndarray, valid: np.ndarray) -> np.ndarray:
    """Single-pass 8-connected labeling; different hue numbers never connect."""
    coded = np.where(valid, hue + 1, 0).astype(np.int16)
    return label_equal_classes(coded, background=0, connectivity=2).astype(np.int32, copy=False)


def _adaptive_hue_and_achromatic(Cfield: np.ndarray, valid: np.ndarray,
                                   p: FastCoreParams, *, mean_gate: bool = False) -> Tuple[np.ndarray, np.ndarray]:
    """Color-polar projection, 12 hue sectors, and element-supported neutral test.

    Every valid pixel first receives a hue bin. 0.06/0.12 are *Euclidean*
    radii in RGB, not (max-min)/sum saturation. The per-hue-region >0.12
    evidence can support its own region and directly touching adjacent hues.
    """
    k = int(p.color_k_chromatic)
    if k != 12:
        raise ValueError('This chromatic geometry requires 12 hue classes (30 degrees).')
    # The channels are already in the chosen RGB space (original for VC,
    # compensated for CC). Do not change the CC compensation itself.
    ea = Cfield[:, :, 0] * _COLOR_EA[0] + Cfield[:, :, 1] * _COLOR_EA[1]
    eb = (Cfield[:, :, 0] * _COLOR_EB[0] + Cfield[:, :, 1] * _COLOR_EB[1]
          + Cfield[:, :, 2] * _COLOR_EB[2])
    radial = np.hypot(ea, eb)
    theta = np.mod(np.arctan2(eb, ea) * (180.0 / np.pi), 360.0)
    width = 360.0 / k
    initial = np.floor(np.mod(theta + width * 0.5, 360.0) / width).astype(np.int16)
    regions = _hue_components(initial, valid)
    # Includes whole (even tiny) hue components; no min-area clipping here.
    if mean_gate:
        # CC only: judge the strength of a whole INITIAL hue component by
        # its average radial chroma, not its strongest isolated pixels.
        # Both .06 and .12 keep their original meanings; only the evidence
        # for a *component* is changed. np.bincount keeps it O(image pixels).
        n_groups = int(regions.max()) + 1
        component_sum = np.bincount(regions.ravel(), weights=radial.ravel(),
                                    minlength=n_groups)
        component_count = np.bincount(regions.ravel(), minlength=n_groups)
        component_mean = component_sum / np.maximum(component_count, 1)
        strong_group = component_mean > p.color_tau_strong
        strong_group[0] = False
    else:
        # Exact historical VC behavior, including single-pixel strong support.
        strong_pix = (radial > p.color_tau_strong) & valid
        strong_group = np.bincount(regions[strong_pix].ravel(),
                                    minlength=int(regions.max()) + 1) > 0
        strong_group[0] = False
    prev_support, next_support = _neighbor_hue_support(initial, regions,
                                                       strong_group, k)
    evidence = strong_group[regions] | prev_support[regions] | next_support[regions]
    if mean_gate:
        # An unsupported region with mean <=.12 is achromatic as a whole,
        # including its few exceptional >.12 pixels. A mean <=.06 never
        # becomes chromatic from a neighboring component's support alone.
        # With meaningful support, the original per-pixel .06 floor remains.
        local_mean = component_mean[regions]
        ach = valid & ((radial < p.color_tau_sat) |
                       (local_mean <= p.color_tau_sat) |
                       ((local_mean <= p.color_tau_strong) & ~evidence))
    else:
        ach = valid & ((radial < p.color_tau_sat) |
                       ((radial <= p.color_tau_strong) & ~evidence))

    if p.color_local_neutral_support:
        # A single >.12 observation must not support an entire, arbitrarily
        # long initial hue component. For intermediate .06--.12 pixels,
        # compare the distance to existing achromatic regions against
        # strong chromatic evidence (>.12) of the same / adjacent hue.
        # If achromatic evidence is strictly closer, the pixel is neutral.
        # This resolves weak CC ghost patches attached to neutral surfaces
        # without changing either chroma threshold or the compensation.
        weak = valid & (radial >= p.color_tau_sat) & (radial <= p.color_tau_strong)
        undecided = weak & ~ach
        # Include *all* already-neutral regions, including unsupported weak
        # regions, rather than only pixels whose own radius is below .06.
        neutral_seeds = ach.copy()
        if np.any(undecided) and np.any(neutral_seeds):
            strong_seeds = valid & (radial > p.color_tau_strong) & strong_group[regions]
            if not np.any(strong_seeds):
                ach[undecided] = True
            else:
                # cv2's C implementation handles a full image in a few ms;
                # scipy is the portability fallback. No per-pixel Python BFS.
                def distance_to_seeds(seeds):
                    non_seeds = (~seeds).astype(np.uint8)
                    if HAS_CV2:
                        return cv2.distanceTransform(non_seeds, cv2.DIST_L2,
                                                     cv2.DIST_MASK_PRECISE)
                    return ndi.distance_transform_edt(non_seeds).astype(np.float32)
                distance_neutral = distance_to_seeds(neutral_seeds)
                for hue_id in range(k):
                    area = undecided & (initial == hue_id)
                    if not np.any(area):
                        continue
                    allowed_strong = strong_seeds & ((initial == hue_id) |
                        (initial == ((hue_id - 1) % k)) |
                        (initial == ((hue_id + 1) % k)))
                    if not np.any(allowed_strong):
                        ach[area] = True
                        continue
                    distance_strong = distance_to_seeds(allowed_strong)
                    ach[area] = distance_neutral[area] < distance_strong[area]

    # Luminance-equal rays from black with equal tilt to gray axis:
    # r(theta) = gray_unit*cos(tilt) + chroma_unit(theta)*sin(tilt).
    # A shorter ray at the same luminance has a LARGER luminance-per-length.
    # Since the gray component and tilt are equal, comparing the projection
    # on the chroma plane is exact and tilt-independent (for positive rays).
    ang = np.arange(k, dtype=np.float32) * (2.0 * np.pi / k)
    luminosity_per_length = (_LUM_WEIGHTS @ _COLOR_EA) * np.cos(ang) + (_LUM_WEIGHTS @ _COLOR_EB) * np.sin(ang)
    weaker_than_next = luminosity_per_length > np.roll(luminosity_per_length, -1)
    weaker_than_prev = luminosity_per_length > np.roll(luminosity_per_length, 1)

    # Start with equal 30-degree sectors. Only the weak side of a boundary
    # needs adjustment: weak alone -> 15 deg from weak (default), both ->
    # 12 deg from weak, strong alone -> 20 deg from strong (=10 from weak).
    final_hue = initial.copy()
    delta = ((theta - initial * width + 180.0) % 360.0) - 180.0
    positive_edge = weaker_than_next[initial] & (delta >= 0)
    negative_edge = weaker_than_prev[initial] & (delta < 0)
    strong_current = strong_group[regions]
    if np.any(positive_edge):
        other = next_support[regions]
        boundary = np.where(other, np.where(strong_current, 12.0, 10.0), 15.0)
        move = positive_edge & (delta >= boundary)
        final_hue[move] = (initial[move] + 1) % k
    if np.any(negative_edge):
        other = prev_support[regions]
        boundary = np.where(other, np.where(strong_current, 12.0, 10.0), 15.0)
        move = negative_edge & (-delta >= boundary)
        final_hue[move] = (initial[move] - 1) % k
    return final_hue, ach


def _slot_achromatic_classes(luminance_res: Dict[str, Any], ach: np.ndarray,
                              p: FastCoreParams, pre_merge: Optional[Dict[str, np.ndarray]]=None) -> np.ndarray:
    """Black/gray/white within L slots; transitive white(low)-black(high) joins.

    A component consists of connected achromatic pixels *in one L slot*,
    regardless of preliminary black/gray/white label. Adjacent-slot links
    require white in the lower slot contacting black in the higher slot.
    Multiple links are unioned before any reclassification, preserving chains.
    Unconnected parts of the same slot remain independent.
    """
    slot = np.asarray(luminance_res['classes'], dtype=np.int16)
    rel = np.asarray(luminance_res['relative_field_gray'], dtype=np.float32)
    k = int(p.lum_k_classes)
    neutral = np.zeros(slot.shape, dtype=np.uint8)
    if not np.any(ach):
        return neutral
    # The slot interval is [slot-1, slot]/k in normalized L-field units.
    local = np.clip(rel * k - (slot.astype(np.float32) - 1), 0, 1)
    black = ach & (local < p.color_tau_black)
    white = ach & (local > p.color_tau_white)
    neutral[ach] = 2
    neutral[black] = 1
    neutral[white] = 3
    if pre_merge is not None:
        pre_merge["neutral_classes"] = neutral.copy()

    # One scan labels all ten L-slot-connected neutral regions. Components
    # connect across preliminary B/G/W, but not across different L slots.
    slot_color = np.where(ach, slot, 0).astype(np.int16)
    regions = label_equal_classes(slot_color, background=0, connectivity=2).astype(np.int32, copy=False)
    next_id = int(regions.max()) + 1
    if next_id == 1:
        return neutral
    region_slots = np.zeros(next_id, dtype=np.int16)  # only linked components needed

    # Enumerate only eligible cross-slot 8-neighbor contacts, not all edges.
    pairs = []
    for dy, dx in ((0, 1), (1, 0), (1, 1), (1, -1)):
        if dx >= 0:
            ar, br = regions[:-dy or None, :-dx or None], regions[dy:, dx:]
            aslot, bslot = slot[:-dy or None, :-dx or None], slot[dy:, dx:]
            aclass, bclass = neutral[:-dy or None, :-dx or None], neutral[dy:, dx:]
        else:
            ar, br = regions[:-dy or None, -dx:], regions[dy:, :dx]
            aslot, bslot = slot[:-dy or None, -dx:], slot[dy:, :dx]
            aclass, bclass = neutral[:-dy or None, -dx:], neutral[dy:, :dx]
        contact = ((ar > 0) & (br > 0) & (np.abs(aslot.astype(np.int16) - bslot.astype(np.int16)) == 1)
                   & (((aslot < bslot) & (aclass == 3) & (bclass == 1)) |
                      ((bslot < aslot) & (bclass == 3) & (aclass == 1))))
        if np.any(contact):
            # Only regions incident on an eligible cross-slot link can merge.
            region_slots[ar[contact]] = aslot[contact]
            region_slots[br[contact]] = bslot[contact]
            a = ar[contact].astype(np.int64)
            b = br[contact].astype(np.int64)
            pairs.append(np.unique(np.minimum(a, b) * next_id + np.maximum(a, b)))
    if not pairs:
        return neutral
    pair_codes = np.unique(np.concatenate(pairs))
    parent = np.arange(next_id, dtype=np.int32)
    rank = np.zeros(next_id, dtype=np.uint8)

    def root(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for code in pair_codes:
        a = root(int(code // next_id))
        b = root(int(code % next_id))
        if a != b:
            if rank[a] < rank[b]:
                a, b = b, a
            parent[b] = a
            if rank[a] == rank[b]:
                rank[a] += 1
    roots = np.fromiter((root(i) for i in range(next_id)), dtype=np.int32, count=next_id)
    low = np.full(next_id, k + 1, dtype=np.int16)
    high = np.zeros(next_id, dtype=np.int16)
    linked = np.flatnonzero(region_slots > 0)
    np.minimum.at(low, roots[linked], region_slots[linked])
    np.maximum.at(high, roots[linked], region_slots[linked])
    # Each set stores its full slot span, not per-pixel field min/max.
    affected = ach & (low[roots[regions]] < high[roots[regions]])
    if np.any(affected):
        r = roots[regions[affected]]
        u = np.clip((rel[affected] * k - (low[r] - 1)) /
                    (high[r] - low[r] + 1), 0.0, 1.0)
        new_class = np.full(u.shape, 2, dtype=np.uint8)
        new_class[u < p.color_tau_black] = 1
        new_class[u > p.color_tau_white] = 3
        neutral[affected] = new_class
    return neutral


def classify_vector_color_fast(Cfield: np.ndarray, Lfield: np.ndarray,
                               p: FastCoreParams, valid_mask: Optional[np.ndarray]=None,
                               luminance_res: Optional[Dict[str, Any]]=None,
                               stage: Optional[Dict[str, np.ndarray]]=None,
                               *, mean_gate: bool = False) -> Tuple[np.ndarray, np.ndarray]:
    """Shared 12-hue classifier; optional CC-only mean radial support gate."""
    valid = np.ones(Lfield.shape, dtype=bool) if valid_mask is None else np.asarray(valid_mask, dtype=bool)
    if not np.any(valid):
        raise ValueError('Color domain has no valid pixels.')
    hues, ach = _adaptive_hue_and_achromatic(Cfield, valid, p, mean_gate=mean_gate)
    classes = np.zeros(valid.shape, dtype=np.int16)
    classes[valid] = hues[valid] + 4
    if luminance_res is not None:
        neutral = _slot_achromatic_classes(luminance_res, ach, p, pre_merge=stage)
    else:
        neutral = np.zeros(valid.shape, dtype=np.uint8)
        neutral[ach] = 2
        neutral[ach & (Lfield < p.color_tau_black)] = 1
        neutral[ach & (Lfield > p.color_tau_white)] = 3
    classes[ach] = neutral[ach]
    if stage is not None:
        before = classes.copy()
        if 'neutral_classes' in stage:
            before[ach] = stage.pop('neutral_classes')[ach]
        stage['pre_classes'] = before
    valid_count = int(np.count_nonzero(valid))
    min_size = max(int(p.color_min_size_base), int(valid_count // max(p.color_min_size_div, 1)))
    groups = components_from_classes_single_pass(classes, min_size=min_size,
                                                 absorb_unassigned=p.absorb_unassigned_pixels)
    groups[~valid] = 0
    return groups, classes


def color_field_visual_fast_u8(Cfield: np.ndarray, Lfield: np.ndarray, classes: np.ndarray) -> np.ndarray:
    """Draw exactly the classifications used for groups, not old fixed limits."""
    vis = np.clip(Cfield, 0.0, 1.0).copy()
    black = classes == 1
    gray = classes == 2
    white = classes == 3
    vis[black] = 0.0
    # Keep the original gray visualization: display the actual L-field.
    vis[gray] = Lfield[gray][:, None]
    vis[white] = 1.0
    vis[classes == 0] = 0.0
    return rgb_float_to_u8(vis)

def run_vector_color_fast(rgb: np.ndarray, luminance_res: Dict[str, Any], p: FastCoreParams, valid_mask: Optional[np.ndarray]=None) -> Dict[str, Any]:
    Lfield = luminance_res.get('field_gray')
    if Lfield is None:
        Lfield = luminance_res['field_rgb'][:, :, 0].astype(np.float32) / 255.0
    if p.use_local_vector_field:
        Cfield = run_vector_color_field_fast(rgb, p, valid_mask)
    else:
        Cfield = rgb.astype(np.float32, copy=False)
    stage = {} if p.capture_color_stages else None
    groups, classes = classify_vector_color_fast(Cfield, Lfield, p, valid_mask, luminance_res, stage=stage)
    res = {'classes': classes, 'groups': groups, 'group_count': int(groups.max())}
    if stage is not None:
        res.update(stage)
    if p.keep_float_fields:
        res['field_rgb_values'] = Cfield
        res['color_input_rgb'] = rgb
    if p.make_visuals:
        res['field_rgb'] = color_field_visual_fast_u8(Cfield, Lfield, classes)
        res['groups_rgb'] = colorize_labels_fast_u8(groups, seed=2)
        res['classes_rgb'] = colorize_labels_fast_u8(classes.astype(np.int32), seed=22)
    return res

def estimate_comp_vector_fast(rgb: np.ndarray, alpha: float=0.75, sample_stride: int=2, valid_mask: Optional[np.ndarray]=None) -> Tuple[np.ndarray, Dict[str, Any]]:
    EA = np.asarray([1.0, -1.0, 0.0], dtype=np.float32) / np.sqrt(2.0)
    EB = np.asarray([1.0, 1.0, -2.0], dtype=np.float32) / np.sqrt(6.0)
    stride = max(1, int(sample_stride))
    base = rgb[::stride, ::stride] if stride > 1 else rgb
    valid = np.ones(base.shape[:2], dtype=bool) if valid_mask is None else np.asarray(valid_mask, dtype=bool)[::stride, ::stride]
    pixels = base[valid]
    if pixels.size == 0:
        zero = np.zeros(3, dtype=np.float32)
        return (zero, {'tint_angle_deg': 0.0, 'comp_angle_deg': 180.0, 'L_dom': 0.0, 'L_opp': 0.0, 'comp_mag': 0.0, 'comp_rgb': zero.copy()})
    m = pixels.mean(axis=1, keepdims=True)
    q = pixels - m
    u = q[:, 0] * EA[0] + q[:, 1] * EA[1] + q[:, 2] * EA[2]
    v = q[:, 0] * EB[0] + q[:, 1] * EB[1] + q[:, 2] * EB[2]
    r = np.sqrt(u * u + v * v).astype(np.float32, copy=False)
    theta = (np.degrees(np.arctan2(v, u)) + 360.0) % 360.0
    bins = np.floor(theta).astype(np.int32) % 360
    mass = np.bincount(bins.ravel(), weights=r.ravel(), minlength=360).astype(np.float32)
    count = np.bincount(bins.ravel(), minlength=360).astype(np.float32)
    mean_r = mass / np.maximum(count, 1.0)
    Ls = (np.roll(mean_r, 2) + 2 * np.roll(mean_r, 1) + 3 * mean_r + 2 * np.roll(mean_r, -1) + np.roll(mean_r, -2)) / 9.0
    k_dom = int(np.argmax(Ls))
    k_opp = (k_dom + 180) % 360
    L_dom = float(Ls[k_dom])
    L_opp = float(Ls[k_opp])
    comp_mag = max(0.0, float(alpha) * (L_dom - L_opp))
    tint_angle = k_dom + 0.5
    comp_angle = (tint_angle + 180.0) % 360.0
    rad = math.radians(comp_angle)
    comp_u = comp_mag * math.cos(rad)
    comp_v = comp_mag * math.sin(rad)
    comp_rgb = comp_u * EA + comp_v * EB
    info = {'tint_angle_deg': tint_angle, 'comp_angle_deg': comp_angle, 'L_dom': L_dom, 'L_opp': L_opp, 'comp_mag': comp_mag, 'comp_rgb': comp_rgb.astype(np.float32)}
    return (comp_rgb.astype(np.float32), info)

def run_consistency_fast(rgb: np.ndarray, luminance_res: Dict[str, Any], p: FastCoreParams,
                         valid_mask: Optional[np.ndarray]=None,
                         vc_res: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    """Original global hue opposition + conservative 0.12 tint gate.

    The selected global tint's mean smoothed Euclidean radius (L_dom) must
    exceed cc_global_tint_min_radius before any compensation is applied.
    A missing/weak dominant tint returns the VC result *exactly*, without
    recomputation or CC segmentation. L/VC remain untouched.
    """
    if vc_res is None:
        vc_res = run_vector_color_fast(rgb, luminance_res, p, valid_mask)
    comp, info = estimate_comp_vector_fast(rgb, alpha=p.cons_alpha,
                                           sample_stride=p.cons_sample_stride,
                                           valid_mask=valid_mask)
    radius = float(info['L_dom'])
    enabled = radius > float(p.cc_global_tint_min_radius) and float(np.linalg.norm(comp)) > EPS
    info = dict(info)
    info['mode'] = 'global_tint_gated'
    info['dominant_tint_radial'] = radius
    info['tint_min_radial'] = float(p.cc_global_tint_min_radius)
    info['compensation_applied'] = bool(enabled)

    if not enabled:
        # This is an exact copy of the VC classification and element topology,
        # not a second run that might differ through filtering or group IDs.
        classes = vc_res['classes'].copy()
        groups = vc_res['groups'].copy()
        info['comp_rgb'] = np.zeros(3, dtype=np.float32)
        info['comp_mag'] = 0.0
        res = {'classes': classes, 'groups': groups,
               'group_count': int(vc_res['group_count']), 'info': info}
        if p.capture_color_stages:
            for key in ('pre_classes',):
                if key in vc_res:
                    res[key] = vc_res[key].copy()
            res['pre_comp_classes'] = classes.copy()
        if p.keep_float_fields:
            vc_field = vc_res.get('field_rgb_values')
            if vc_field is None:
                vc_field = run_vector_color_field_fast(rgb, p, valid_mask) if p.use_local_vector_field else rgb
            res['field_rgb_values'] = vc_field.copy()
            res['shifted_rgb'] = vc_field.copy()
        if p.make_visuals:
            for key in ('field_rgb', 'groups_rgb', 'classes_rgb'):
                if key in vc_res:
                    res[key] = vc_res[key].copy()
        return res

    Lfield = luminance_res.get('field_gray')
    if Lfield is None:
        Lfield = luminance_res['field_rgb'][:, :, 0].astype(np.float32) / 255.0
    shifted = clamp01(rgb + comp.reshape(1, 1, 3)).astype(np.float32, copy=False)
    stage = {} if p.capture_color_stages else None
    groups, classes = classify_vector_color_fast(shifted, Lfield, p, valid_mask,
                                                  luminance_res, stage=stage,
                                                  mean_gate=p.cc_component_mean_gate)
    res = {'classes': classes, 'groups': groups,
           'group_count': int(groups.max()), 'info': info}
    if stage is not None:
        res.update(stage)
        res['pre_comp_classes'] = vc_res['classes'].copy()
    if p.keep_float_fields:
        res['field_rgb_values'] = shifted
        res['shifted_rgb'] = shifted
    if p.make_visuals:
        res['field_rgb'] = color_field_visual_fast_u8(shifted, Lfield, classes)
        res['groups_rgb'] = colorize_labels_fast_u8(groups, seed=3)
        res['classes_rgb'] = colorize_labels_fast_u8(classes.astype(np.int32), seed=33)
    return res


@lru_cache(maxsize=1)
def color_class_palette_u8() -> np.ndarray:
    """Fixed 12-hue diagnostic palette: linear-RGB Y=0.60, gray-axis tilt <=30°.

    A 30° ray at Y=0.60 is outside the RGB cube for some hues (magenta,
    blue, red). In those directions reduce tilt only enough to stay in gamut,
    retaining hue azimuth and exactly 0.60 luminance. Never clip channels,
    which would change hue and luminance arbitrarily.
    """
    pal = np.zeros((16,3), np.uint8)
    pal[1] = (15,15,15)
    pal[2] = (128,128,128)
    pal[3] = (245,245,245)
    axis = np.ones(3, dtype=np.float64) / np.sqrt(3)
    lum = _LUM_WEIGHTS.astype(np.float64)
    for i in range(12):
        a = i * np.pi / 6
        chroma = np.cos(a)*_COLOR_EA.astype(np.float64) + np.sin(a)*_COLOR_EB.astype(np.float64)
        base = np.cos(np.pi/6)*axis
        direct = np.sin(np.pi/6)*chroma
        # binary search along radial direction, not a hue-changing RGB clip
        lo, hi = 0., 1.
        for _ in range(22):
            mid = (lo+hi)*.5
            ray = base + mid*direct
            rgb = .6 * ray / np.dot(lum, ray)
            if np.all((rgb >= 0) & (rgb <= 1)):
                lo=mid
            else:hi=mid
        ray=base+lo*direct
        pal[4+i] = np.round(255 * (.6*ray/np.dot(lum,ray))).astype(np.uint8)
    return pal


def diagnostic_class_image(classes: np.ndarray, only_neutral: bool=False) -> np.ndarray:
    """Class-ID image, explicitly not original RGB or random component colors."""
    palette = color_class_palette_u8().copy()
    if only_neutral:
        palette[4:] = (51,64,75)
    return palette[np.clip(np.asarray(classes, dtype=np.int16), 0, 15)]


def build_parent_hierarchy_fast(labels_by_domain: Dict[str, np.ndarray], min_overlap_px: int=1, overlap_half_smaller_group: bool=False) -> Dict[str, Any]:
    """
    Non-recursive parent grouping over all domain label maps.

    Rule:
    - For every overlapping pair from two different domains, the physically
      larger group is a parent of the smaller group.
    - If a child overlaps multiple larger groups, all of them are parents.
    - Parent-of-parent is not collapsed or recursively simplified.
    - Groups with at least one child remain as final parent groups.
    """
    domain_names = [d for d in DOMAIN_NAMES if d in labels_by_domain]
    domain_index = {name: i for i, name in enumerate(domain_names)}
    group_table: List[Dict[str, Any]] = []
    local_to_gid: Dict[Tuple[int, int], int] = {}
    areas_by_domain: Dict[str, np.ndarray] = {}
    for name in domain_names:
        labels = np.asarray(labels_by_domain[name], dtype=np.int32)
        areas = np.bincount(labels.ravel())
        areas_by_domain[name] = areas
        di = domain_index[name]
        for lab in range(1, len(areas)):
            area = int(areas[lab])
            if area <= 0:
                continue
            gid = len(group_table) + 1
            local_to_gid[di, lab] = gid
            group_table.append({'gid': gid, 'domain': name, 'domain_index': di, 'label': int(lab), 'area': area})
    relationships: Dict[Tuple[int, int], int] = {}
    min_overlap_px = max(1, int(min_overlap_px))
    for ai in range(len(domain_names)):
        for bi in range(ai + 1, len(domain_names)):
            name_a = domain_names[ai]
            name_b = domain_names[bi]
            A = np.asarray(labels_by_domain[name_a], dtype=np.int32)
            B = np.asarray(labels_by_domain[name_b], dtype=np.int32)
            if A.shape != B.shape:
                raise ValueError('All domain label maps must have the same shape.')
            a = A.ravel()
            b = B.ravel()
            mask = (a > 0) & (b > 0)
            if not np.any(mask):
                continue
            max_b = int(B.max())
            codes = a[mask].astype(np.int64) * np.int64(max_b + 1) + b[mask].astype(np.int64)
            uniq, counts = np.unique(codes, return_counts=True)
            labs_a = (uniq // np.int64(max_b + 1)).astype(np.int32)
            labs_b = (uniq % np.int64(max_b + 1)).astype(np.int32)
            areas_a = areas_by_domain[name_a]
            areas_b = areas_by_domain[name_b]
            for la, lb, ov in zip(labs_a, labs_b, counts):
                area_a = int(areas_a[int(la)]) if int(la) < len(areas_a) else 0
                area_b = int(areas_b[int(lb)]) if int(lb) < len(areas_b) else 0
                if area_a <= 0 or area_b <= 0 or area_a == area_b:
                    continue
                required_overlap = min_overlap_px
                if overlap_half_smaller_group:
                    required_overlap = int(math.ceil(0.5 * min(area_a, area_b)))
                if int(ov) < required_overlap:
                    continue
                gid_a = local_to_gid.get((ai, int(la)))
                gid_b = local_to_gid.get((bi, int(lb)))
                if gid_a is None or gid_b is None:
                    continue
                if area_a > area_b:
                    parent_gid, child_gid = (gid_a, gid_b)
                else:
                    parent_gid, child_gid = (gid_b, gid_a)
                relationships[parent_gid, child_gid] = relationships.get((parent_gid, child_gid), 0) + int(ov)
    children_of_parent: Dict[int, List[int]] = {}
    parents_of_child: Dict[int, List[int]] = {}
    relationship_rows: List[Dict[str, int]] = []
    for (parent_gid, child_gid), overlap in sorted(relationships.items()):
        children_of_parent.setdefault(parent_gid, []).append(child_gid)
        parents_of_child.setdefault(child_gid, []).append(parent_gid)
        relationship_rows.append({'parent_gid': int(parent_gid), 'child_gid': int(child_gid), 'overlap_px': int(overlap)})
    parent_gids = sorted(children_of_parent.keys())
    parent_set = set(parent_gids)
    parent_rows = []
    by_gid = {g['gid']: g for g in group_table}
    for gid in parent_gids:
        g = dict(by_gid[gid])
        g['child_count'] = len(children_of_parent.get(gid, []))
        parent_rows.append(g)
    return {'group_table': group_table, 'parents': parent_rows, 'parent_gids': parent_gids, 'relationships': relationship_rows, 'children_of_parent': {str(k): v for k, v in children_of_parent.items()}, 'parents_of_child': {str(k): v for k, v in parents_of_child.items()}, 'parent_set': parent_set}

def parent_groups_rgb_fast(labels_by_domain: Dict[str, np.ndarray], hierarchy: Dict[str, Any]) -> np.ndarray:
    first = next(iter(labels_by_domain.values()))
    h, w = first.shape
    acc = np.zeros((h, w, 3), dtype=np.float32)
    cnt = np.zeros((h, w), dtype=np.float32)
    parent_rows = hierarchy.get('parents', [])
    if not parent_rows:
        return np.zeros((h, w, 3), dtype=np.uint8) + 13
    rows_by_domain: Dict[str, List[Dict[str, Any]]] = {}
    for i, row in enumerate(parent_rows):
        row = dict(row)
        row['_parent_order'] = i + 1
        rows_by_domain.setdefault(row['domain'], []).append(row)
    for domain, rows in rows_by_domain.items():
        labels = np.asarray(labels_by_domain[domain], dtype=np.int32)
        max_lab = int(labels.max())
        lut = np.zeros((max_lab + 1, 3), dtype=np.float32)
        hit = np.zeros(max_lab + 1, dtype=np.float32)
        for row in rows:
            lab = int(row['label'])
            if 0 <= lab <= max_lab:
                lut[lab] = _palette_color_u8(int(row['_parent_order']), seed=77).astype(np.float32)
                hit[lab] = 1.0
        acc += lut[np.clip(labels, 0, max_lab)]
        cnt += hit[np.clip(labels, 0, max_lab)]
    out = np.zeros((h, w, 3), dtype=np.uint8) + 13
    mask = cnt > 0
    if np.any(mask):
        out[mask] = np.clip(acc[mask] / cnt[mask, None], 0, 255).astype(np.uint8)
    return out

def process_numpy_array(rgb_array: np.ndarray, params: Optional[FastCoreParams]=None, valid_mask: Optional[np.ndarray]=None) -> Dict[str, Any]:
    """
    Standalone fast core:
        numpy RGB array -> domain groups + parent hierarchy

    Returns:
        {
          "rgb_u8": uint8 original,
          "domains": {
             "Luminance": {"groups": int32, "classes": int16, ...},
             "Vector Color": {...},
             "Consistency": {...}
          },
          "parents": hierarchy dict,
          "parent_groups_rgb": uint8 visualization if make_visuals=True,
          "runtime_ms": timing dict
        }
    """
    p = params or FastCoreParams()
    rgb_full = as_float_rgb(rgb_array)
    if valid_mask is None:
        valid_full = np.ones(rgb_full.shape[:2], dtype=bool)
    else:
        valid_full = np.asarray(valid_mask, dtype=bool)
        if valid_full.shape != rgb_full.shape[:2]:
            raise ValueError('valid_mask must match the input image height and width.')
        if not np.any(valid_full):
            raise ValueError('The valid input mask contains no pixels.')
    rgb_full_u8 = rgb_float_to_u8(rgb_full)
    rgb_u8, processing_scale = resize_rgb_u8_maxdim(rgb_full_u8, p.processing_max_dim)
    rgb = as_float_rgb(rgb_u8)
    valid = resize_bool_mask(valid_full, rgb.shape[:2])
    runtime_ms: Dict[str, float] = {}
    domains: Dict[str, Dict[str, Any]] = {}
    t0 = time.perf_counter()
    lum = run_luminance_fast(rgb, p, valid)
    runtime_ms['Luminance'] = (time.perf_counter() - t0) * 1000.0
    domains['Luminance'] = lum
    t0 = time.perf_counter()
    col = run_vector_color_fast(rgb, lum, p, valid)
    runtime_ms['Vector Color'] = (time.perf_counter() - t0) * 1000.0
    domains['Vector Color'] = col
    t0 = time.perf_counter()
    cons = run_consistency_fast(rgb, lum, p, valid, vc_res=col)
    runtime_ms['Consistency'] = (time.perf_counter() - t0) * 1000.0
    domains['Consistency'] = cons
    labels_by_domain = {name: domains[name]['groups'] for name in DOMAIN_NAMES}
    t0 = time.perf_counter()
    parents = build_parent_hierarchy_fast(labels_by_domain, min_overlap_px=p.parent_min_overlap_px, overlap_half_smaller_group=p.parent_overlap_half_smaller_group)
    runtime_ms['Parent hierarchy'] = (time.perf_counter() - t0) * 1000.0
    result: Dict[str, Any] = {'rgb_u8': rgb_u8, 'original_shape': tuple((int(x) for x in rgb_full.shape[:2])), 'processing_shape': tuple((int(x) for x in rgb.shape[:2])), 'processing_scale': float(processing_scale), 'valid_mask': valid, 'domains': domains, 'parents': parents, 'runtime_ms': runtime_ms, 'params': asdict(p)}
    if p.make_visuals:
        t0 = time.perf_counter()
        result['parent_groups_rgb'] = parent_groups_rgb_fast(labels_by_domain, parents)
        runtime_ms['Parent visualization'] = (time.perf_counter() - t0) * 1000.0
    runtime_ms['Total'] = sum((v for k, v in runtime_ms.items() if k != 'Total'))
    return result

