"""Only original DPG observations, with source identities kept intact."""
from __future__ import annotations
import cv2
import numpy as np
from dpg_engine import FastCoreParams, process_numpy_array
from native_observation import DOMAINS, native_edge_mask

NAMES = {'L':'Luminance', 'VC':'Vector Color', 'CC':'Consistency'}
COLORS = {'L':(255,75,75), 'VC':(70,225,250), 'CC':(250,205,60)}

def extract(images, progress=lambda _:None):
    result={}
    for side,rgb in zip(('left','right'), images):
        progress('DPG '+side)
        # Full image resolution; source labels are never resized to save compute.
        params=FastCoreParams(processing_max_dim=max(rgb.shape[:2]),
                              make_visuals=False,keep_float_fields=False)
        data=process_numpy_array(rgb,params)
        for dom,name in NAMES.items():
            d=data['domains'][name]
            result[f'{side}_{dom}']=np.asarray(d['groups'],np.int32).copy()
            result[f'{side}_{dom}_class']=np.asarray(d['classes'],np.int16).copy()
    return result

def edge(labels):
    return native_edge_mask(labels)

def draw_edges(rgb, observation, side, domain='ALL', selected=None):
    out=rgb.copy()
    for d in (DOMAINS if domain=='ALL' else (domain,)):
        labels=observation[f'{side}_{d}']
        if selected is not None and selected['domain']==d:
            ident=selected['left'] if side=='left' else selected['right']
            e=edge((labels==ident).astype(np.uint8))
        elif selected is None:e=edge(labels)
        else:continue
        out[e]=COLORS[d]
    return out
