"""Non-learning segmentation baselines for V7.

All baselines produce independent left/right segmentations at native resolution.
They are converted to the same observation container shape that the existing
DPG pipeline expects. Only one active domain (L) is used; VC/CC are left empty.
"""
from __future__ import annotations
import numpy as np
from skimage.segmentation import felzenszwalb, slic
from skimage.measure import label as cc_label

METHODS={
    'dpg': 'DPG (three domains)',
    'felzenszwalb': 'Felzenszwalb graph segmentation (one domain)',
    'slic': 'SLIC superpixels (one domain)',
}


def _reindex_positive(labels: np.ndarray) -> np.ndarray:
    labels=np.asarray(labels)
    uniq=np.unique(labels)
    uniq=uniq[uniq>=0]
    out=np.zeros(labels.shape,np.int32)
    nxt=1
    for u in uniq:
        if u==0:
            continue
        out[labels==u]=nxt
        nxt+=1
    if labels.min()<0:
        bg=(labels<0)
        out[bg]=0
    elif 0 in uniq:
        out[labels==0]=1 if out.max()==0 else out[labels==0]
    return out


def _remove_tiny(labels: np.ndarray, min_size: int = 16) -> np.ndarray:
    labels=np.asarray(labels,np.int32)
    if min_size<=1:
        return labels
    out=labels.copy()
    counts=np.bincount(out.ravel())
    tiny=np.flatnonzero(counts<min_size)
    tiny=tiny[tiny>0]
    if len(tiny)==0:
        return out
    h,w=out.shape
    for ident in tiny:
        ys,xs=np.nonzero(out==ident)
        for y,x in zip(ys,xs):
            vals=[]
            if y>0 and out[y-1,x]!=ident: vals.append(out[y-1,x])
            if y+1<h and out[y+1,x]!=ident: vals.append(out[y+1,x])
            if x>0 and out[y,x-1]!=ident: vals.append(out[y,x-1])
            if x+1<w and out[y,x+1]!=ident: vals.append(out[y,x+1])
            vals=[v for v in vals if v>0]
            if vals:
                # choose most common immediate neighbor id
                u,c=np.unique(vals,return_counts=True)
                out[y,x]=int(u[np.argmax(c)])
    return _reindex_connected(out)


def _reindex_connected(labels: np.ndarray) -> np.ndarray:
    """Every final id is 8-connected, positive and compactly renumbered."""
    labels=np.asarray(labels)
    out=np.zeros(labels.shape,np.int32)
    nxt=1
    for ident in np.unique(labels):
        if ident<=0:
            continue
        cc=cc_label(labels==ident, connectivity=2, background=0)
        for cid in range(1, int(cc.max())+1):
            out[cc==cid]=nxt
            nxt+=1
    return out


def segment_single(rgb: np.ndarray, method: str) -> np.ndarray:
    rgb=np.asarray(rgb)
    if method=='felzenszwalb':
        raw=felzenszwalb(rgb, scale=120, sigma=0.8, min_size=60)
        labels=_reindex_connected(raw.astype(np.int32)+1)
        labels=_remove_tiny(labels, min_size=18)
        return labels
    if method=='slic':
        # Deliberately very different from DPG/Felzenszwalb: compact, nearly uniform superpixels.
        raw=slic(rgb, n_segments=max(180, (rgb.shape[0]*rgb.shape[1])//5000), compactness=12.0,
                 sigma=0.8, start_label=1, convert2lab=True, enforce_connectivity=True)
        labels=_reindex_connected(raw.astype(np.int32))
        labels=_remove_tiny(labels, min_size=18)
        return labels
    raise ValueError(f'Unknown segmentation method: {method}')


def build_observations(images, method: str, progress=lambda _ : None):
    if method=='dpg':
        try:
            from observations import extract
        except ImportError:  # pragma: no cover
            from .observations import extract
        return extract(images, progress=progress)
    result={}
    for side,rgb in zip(('left','right'), images):
        progress(f'{method} {side}')
        labels=segment_single(rgb, method)
        result[f'{side}_L']=labels.astype(np.int32, copy=False)
        result[f'{side}_L_class']=np.zeros(labels.shape, np.int16)
        # One-domain baselines: keep VC/CC empty but well-formed.
        for dom in ('VC','CC'):
            result[f'{side}_{dom}']=np.zeros(labels.shape, np.int32)
            result[f'{side}_{dom}_class']=np.zeros(labels.shape, np.int16)
    return result
