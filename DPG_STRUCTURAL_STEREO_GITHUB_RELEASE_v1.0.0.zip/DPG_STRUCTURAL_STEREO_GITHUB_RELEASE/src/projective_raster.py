"""One continuous, source-textured planar raster shared with the 3D viewer.

Each native (source camera, surface id, plane) patch is a planar area, not a
point splat. The mask and RGB are mapped through an exact plane-induced
homography, with area coverage and inverse-resampled original pixels. A
Z-buffer decides the visible sheet; RGB may combine LEFT and RIGHT only when
both samples share one surface ID. Unresolved geometry stays unresolved.
"""
from __future__ import annotations
import numpy as np
from surface_viewer_raster import render_planes


def render_continuous_midpoint(images,world,identities,confidence=None,progress=lambda _:None):
    h,w=images[0].shape[:2]
    camera=world.camera
    progress('V5: continuous 3D planes, native RGB textures and depth buffer')
    source={'left':np.asarray(images[0],np.uint8),'right':np.asarray(images[1],np.uint8)}
    maps={'left':np.asarray(world.left_plane,np.int32),'right':np.asarray(world.right_plane,np.int32)}
    if confidence is None:
        texture,visible,surface=render_planes(source,maps,world.world_planes,identities,
               camera,np.zeros(3),np.eye(3),w,h,camera.focal,camera.cx,camera.cy)
        conf=np.zeros((h,w),np.uint8)
    else:
        texture,visible,surface,conf=render_planes(source,maps,world.world_planes,identities,
               camera,np.zeros(3),np.eye(3),w,h,camera.focal,camera.cx,camera.cy,confidence=confidence)
    out=texture.copy()
    empty=visible==0
    out[empty]=source['left'][empty] # 2D backdrop, never a 3D surface
    report={
        'raster_method':'V5_continuous_native_texture_plane_homography',
        'pixels_from_3d':int(np.count_nonzero(~empty)),
        'filled_by_3d_raster_pct':round(float(np.mean(~empty)*100),3),
        'background_proxy_pixels':int(np.count_nonzero(empty)),
        'simultaneous_2view_projection_pct':round(float(np.mean(visible==3)*100),3),
        'same_surface_rgb_required':True,'continuous_area_not_forward_pixel_splat':True,
        'native_RGB_bilinearly_resampled':True,
        'original_surface_identity_unchanged':True,
        'unknown_geometry_not_created_by_raster':True,
        'no_postprocess_hole_filling':True}
    return out,visible,report,conf
