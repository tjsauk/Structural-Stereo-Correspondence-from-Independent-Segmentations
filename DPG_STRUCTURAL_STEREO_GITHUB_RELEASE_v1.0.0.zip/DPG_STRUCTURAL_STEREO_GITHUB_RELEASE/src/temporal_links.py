"""GT-blind temporal correspondences between native DPG ELEMENTS.

Registration is 2D because same-camera temporal pairs are not rectified
stereo pairs. Pixels are never optimized into a dense optical-flow map:
we register a global camera-motion hypothesis, then match DPG label supports.
Each accepted link has a continuous affine mapping for querying arbitrary
source coordinates, together with confidence and split/merge evidence.
"""
from __future__ import annotations
import numpy as np
import cv2

DOMAINS=('L','VC','CC')

def global_affine(image_a, image_b, downscale=.5):
    """Estimate full-frame background alignment, never a semantic/object GT.

    OpenCV ECC is untrained and optimized in a Gaussian pyramid. A fallback
    to phase correlation or identity preserves an inspectable link result.
    Returned matrix maps coordinates of image_a -> image_b.
    """
    ga=cv2.cvtColor(image_a,cv2.COLOR_RGB2GRAY).astype(np.float32)/255.
    gb=cv2.cvtColor(image_b,cv2.COLOR_RGB2GRAY).astype(np.float32)/255.
    h,w=ga.shape
    scale=min(float(downscale), min(1.,900./max(w,h)))
    if scale<1:
        sz=(max(32,round(w*scale)),max(32,round(h*scale)))
        a=cv2.resize(ga,sz,interpolation=cv2.INTER_AREA)
        b=cv2.resize(gb,sz,interpolation=cv2.INTER_AREA)
    else:a=ga;b=gb
    try:
        # Phase correlation estimates the large translation without assuming
        # an epipolar x-only temporal motion.
        shift,response=cv2.phaseCorrelate(a,b)
        initial=np.eye(2,3,dtype=np.float32)
        if response>.015 and max(abs(v) for v in shift)<max(a.shape)*.4:
            initial[:,2]=shift
        # findTransformECC template a, input b returns W transforming
        # template -> input when called with WARP_INVERSE_MAP for the image.
        # This is the inverse of the usual forward-transform warpAffine call.
        # Use the inverse below to form source->target explicitly.
        warp=np.asarray(initial,np.float32).copy()
        cv2.findTransformECC(a,b,warp,cv2.MOTION_AFFINE,
            (cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,70,1e-5),None,5)
        # ECC warp maps a-coordinates to b-coordinates, although ECC's
        # sample convention uses inverse warping in its image calls.
        forward=warp
        success=True
    except cv2.error:
        forward=np.asarray(initial,np.float32)
        success=False
    forward=forward.astype(np.float64)
    if scale<1:forward[:,2]/=scale
    if not np.isfinite(forward).all() or abs(np.linalg.det(forward[:,:2]))<.1:
        forward=np.eye(2,3,dtype=np.float64);success=False
    return forward.astype(np.float32), {'ecc_success':bool(success),
        'scale':float(scale),'affine_2x3':forward.tolist()}

def _pairs(src,dst, M, min_intersection=10, minimum_score=.12):
    """Create multiple weighted element links from intersecting warped label regions."""
    h,w=src.shape
    warped=cv2.warpAffine(np.asarray(src,np.float32),M,(w,h),
                 flags=cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT,borderValue=0).astype(np.int32)
    dst=np.asarray(dst,np.int32)
    good=(warped>0)&(dst>0)
    if not np.any(good):return []
    s=warped[good].astype(np.int64)
    t=dst[good].astype(np.int64)
    encoded=s*(int(dst.max())+1)+t
    key,count=np.unique(encoded,return_counts=True)
    n=int(dst.max())+1
    src_labels=(key//n).astype(np.int32)
    dst_labels=(key%n).astype(np.int32)
    src_area=np.bincount(warped.ravel().clip(min=0)).astype(np.int32)
    dst_area=np.bincount(dst.ravel().clip(min=0)).astype(np.int32)
    entries=[]
    for si,ti,num in zip(src_labels,dst_labels,count):
        if num<min_intersection or src_area[si]<min_intersection or dst_area[ti]<min_intersection:continue
        iou=float(num)/(int(src_area[si])+int(dst_area[ti])-int(num))
        containment=float(num)/max(1,min(int(src_area[si]),int(dst_area[ti])))
        score=.7*iou+.3*containment
        if score<minimum_score:continue
        entries.append((int(si),int(ti),int(num),float(score)))
    # A source element can split, or several source elements can merge.
    by_src={}
    for rec in entries:by_src.setdefault(rec[0],[]).append(rec)
    accepted=[]
    for sid,edges in by_src.items():
        edges.sort(key=lambda r:r[3],reverse=True)
        for e in edges[:4]:
            if e[3]>=max(minimum_score,edges[0][3]*.36):accepted.append(e)
    return accepted

def _moments(labels, ids):
    h,w=labels.shape
    iy,ix=np.indices((h,w),dtype=np.float64)
    flat=labels.ravel().astype(np.int32)
    count=np.bincount(flat,minlength=int(flat.max())+1).astype(float)
    x=np.bincount(flat,weights=ix.ravel(),minlength=len(count))/np.maximum(count,1)
    y=np.bincount(flat,weights=iy.ravel(),minlength=len(count))/np.maximum(count,1)
    return {int(i):np.array([x[i],y[i]],np.float32) for i in ids if i<len(count) and count[i]>0}

def match_camera_frames(image_a,image_b,labels_a,labels_b,side,
                        *,domain_names=DOMAINS,global_matrix=None):
    M,global_info=(global_affine(image_a,image_b) if global_matrix is None else
                   (np.asarray(global_matrix,np.float32),{'provided_global':True}))
    records=[]
    for domain in domain_names:
        old=np.asarray(labels_a[side+'_'+domain],np.int32)
        new=np.asarray(labels_b[side+'_'+domain],np.int32)
        if old.shape!=new.shape:raise ValueError('Temporal images and DPG labels have different shapes')
        edges=_pairs(old,new,M)
        if not edges:continue
        # Shift each source element by a conservative piecewise affine
        # centroid correction. Its linear part follows the estimated camera
        # transform; individual boundary pixels are NOT moved separately.
        src_pts=_moments(old,{e[0] for e in edges})
        dst_pts=_moments(new,{e[1] for e in edges})
        for a,b,support,score in edges:
            src_c=src_pts[a];dst_c=dst_pts[b]
            predicted=M[:,:2]@src_c+M[:,2]
            residual=dst_c-predicted
            # Partial visibility can change the centroid dramatically.
            # Never let a low-confidence match translate far from its
            # geometric overlap; flag it instead of inventing certainty.
            correction=np.clip(residual,-20.,20.)*float(np.clip(score,0.,.75))
            A=M.copy();A[:,2]+=correction
            records.append((domain,int(a),int(b),float(score),int(support),A))
    return records,M,global_info

def save_links(path,records,Mleft,Mright,metadata=None):
    from pathlib import Path
    import json
    out=Path(path);out.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out,
        domain=np.asarray([DOMAINS.index(r[0]) for r in records],np.uint8),
        src=np.asarray([r[1] for r in records],np.int32),
        dst=np.asarray([r[2] for r in records],np.int32),
        score=np.asarray([r[3] for r in records],np.float32),
        support=np.asarray([r[4] for r in records],np.int32),
        matrix=np.asarray([r[5] for r in records],np.float32).reshape(-1,2,3),
        side=np.asarray([r[6] for r in records],np.uint8),
        global_left=np.asarray(Mleft,np.float32),global_right=np.asarray(Mright,np.float32))
    return {'links':len(records), 'left_links':sum(r[6]==0 for r in records),
            'right_links':sum(r[6]==1 for r in records),**(metadata or {})}

def load_links(path):
    with np.load(path,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}

def follow_element(session, frame, target, side, domain, element_id,
                   *, min_score=.12):
    """Trace a DPG element across ordered frames; return multiple branches.

    A missing link is explicitly a missing observation, not a hallucinated
    pixel or a guessed reappearance.
    """
    from pathlib import Path
    import json
    session=Path(session)
    info=json.loads((session/'SESSION.json').read_text(encoding='utf-8'))
    frames=info['completed_frames']
    if frame not in frames or target not in frames:raise ValueError('Frame missing from completed session')
    sid=0 if side=='left' else 1
    did=DOMAINS.index(domain)
    tracks=[(int(element_id),np.eye(3,dtype=np.float64),1.)]
    a=frames.index(frame);b=frames.index(target)
    step=1 if b>a else -1
    for i in range(a,b,step):
        frm=frames[i];to=frames[i+step]
        path=session/'temporal'/f'links_{min(frm,to):06d}_{max(frm,to):06d}.npz'
        links=load_links(path)
        select=(links['side']==sid)&(links['domain']==did)&(links['score']>=min_score)
        candidate=[]
        for label,composite,score in tracks:
            inds=np.flatnonzero(select&(links['src' if step>0 else 'dst']==label))
            for j in inds:
                affine=np.eye(3)
                affine[:2,:3]=links['matrix'][j]
                if step<0:affine=np.linalg.inv(affine)
                candidate.append((int(links['dst' if step>0 else 'src'][j]),
                                  affine@composite,float(score*links['score'][j])))
        if not candidate:return []
        # Keep the most reliable path to each resulting element.
        best={}
        for label,M,score in candidate:
            if label not in best or score>best[label][2]:best[label]=(label,M,score)
        tracks=sorted(best.values(),key=lambda v:-v[2])[:32]
    return tracks
