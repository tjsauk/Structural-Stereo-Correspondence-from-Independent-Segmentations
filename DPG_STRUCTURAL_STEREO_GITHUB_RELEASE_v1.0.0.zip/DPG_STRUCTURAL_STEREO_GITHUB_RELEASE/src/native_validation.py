"""Source-observation validation of competing structural stereo solutions.

No GT data and no sparse/dense feature disparity. This is a physical
reprojection constraint: a sheet from one camera may not reproject strictly
IN FRONT of a different sheet originally observed in the other camera.
Use it to accept/reject entire pre-render geometry hypotheses; not an
image-plane postprocessing filter or invented physical surface.
"""
from __future__ import annotations
import numpy as np
from world_render import source_geometry


def evaluate(world,*,margin=.012,tile=96):
    cam=world.camera
    depth={s:source_geometry(getattr(world,s+'_plane'),world.world_planes,
             cam.focal,cam.cx,cam.cy,cam.baseline,s)[2] for s in ('left','right')}
    h,w=depth['left'].shape
    yy,xx=np.indices((h,w),dtype=np.float32)
    result={};tilemap={}
    for target,source in (('left','right'),('right','left')):
        dep=depth[source]
        # Reproject the opposite camera's native sheet into this camera.
        with np.errstate(divide='ignore',invalid='ignore'):
            disp=cam.focal*cam.baseline/dep
        tx=xx+disp if source=='right' else xx-disp
        q=np.rint(np.nan_to_num(tx,nan=-1e6)).astype(np.int32)
        valid=np.isfinite(dep)&(q>=0)&(q<w)
        q=np.clip(q,0,w-1)
        native=depth[target][yy.astype(np.int32),q]
        conflict=valid&np.isfinite(native)&(dep<native*(1.-margin))
        raster=np.zeros((h,w),bool)
        raster[yy[conflict].astype(np.int32),q[conflict]]=True
        count=int(raster.sum())
        result[target]={'contradictory_native_pixels':count,
                        'fraction':round(count/(h*w),7)}
        cells=[]
        for y0 in range(0,h,tile):
            row=[]
            for x0 in range(0,w,tile):
                row.append(float(raster[y0:min(h,y0+tile),x0:min(w,x0+tile)].mean()))
            cells.append(row)
        tilemap[target]=np.asarray(cells,np.float32)
    return result,tilemap


def accept_candidate(base,candidate,base_tiles,cand_tiles,*,allowed_global=.005,
                     allowed_tile=.06):
    """Conservative physics gate, no chosen image-specific ROI or GT tuning.

    An experimental candidate cannot replace a baseline if it increases
    total contradicted source pixels in either camera by >0.5% of the image,
    or raises a generic fixed-area tile's contradiction fraction by >6%.
    A significant improvement somewhere is required, not just equal cost.
    """
    reasons=[]
    significant=False
    for s in ('left','right'):
        a=float(base[s]['fraction']);b=float(candidate[s]['fraction'])
        if b>a+allowed_global:reasons.append(s+':more_original_visibility_conflicts')
        if b<a-.005:significant=True
        if np.any(cand_tiles[s]>base_tiles[s]+allowed_tile):
            reasons.append(s+':local_tile_visibility_regression')
    if not significant:reasons.append('no_significant_native_visibility_improvement')
    return not reasons,reasons
