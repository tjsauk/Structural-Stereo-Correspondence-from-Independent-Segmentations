"""Shared 3D sheet assembly from matched DPG boundary arcs.

One 3D plane is defined as nx*X + ny*Y + nz*Z = 1, with XYZ in the
RECTIFIED midpoint camera, forward Z>0, relative baseline B=1.  Plane
proposals use boundary *pairs*, never a source image disparity field.

The original image L/VC/CC partitions induce common sheet PATCHES (atomic
intersections). A patch, not an independent RGB pixel, owns a facet. Each
patch is linked to neighboring patches through the native DPG topology.
Thus multiple source elements can share one physical facet and one source
element can contain several facets; no per-pixel disparity interpolation.

These are evidence-conditioned sheet hypotheses; the solver diagnoses gaps
and does not pretend that every bend/occlusion can be uniquely reconstructed.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy import sparse, ndimage
from skimage.measure import label as connected_equal_labels
from native_observation import DOMAINS
from plane_fitting import discover_planes

@dataclass(frozen=True)
class Camera:
    focal:float
    cx:float
    cy:float
    baseline:float=1.0

@dataclass
class SheetSolution:
    # Geometry is the original 3D world, NOT pixel disparity maps.
    world_planes:np.ndarray   # K x 3 plane coefficients: dot(normal, XYZ)=1
    left_plane:np.ndarray
    right_plane:np.ndarray
    left_patch:np.ndarray
    right_patch:np.ndarray
    left_patch_planes:np.ndarray
    right_patch_planes:np.ndarray
    sample_plane:np.ndarray
    camera:Camera
    model_report:list
    stats:dict
    structure_ids:np.ndarray|None=None  # many local charts may form one 3D structure

def camera_from_shape(shape, focal=None, cx=None, cy=None, baseline=1.0):
    h,w=shape
    return Camera(float(focal if focal is not None else w*.8),
                  float(cx if cx is not None else (w-1)*.5),
                  float(cy if cy is not None else (h-1)*.5),float(baseline))


def triangulate_boundary(left,right,camera,far_parallax=None):
    """Only the paired BOUNDARY coordinates are triangulated; never images."""
    l=np.asarray(left,np.float64);r=np.asarray(right,np.float64)
    d=l[:,0]-r[:,0]
    # A zero-parallax contour represents a direction at infinity. Use the
    # same finite *display* proxy as the sheet library, without modifying the
    # source pair or pretending this is a measured metric distance.
    if far_parallax is None:
        positives=d[np.isfinite(d)&(d>0)]
        far_parallax=max(1.e-5,min(.01,float(positives.min())*.01)) if len(positives) else .01
    safe=np.where(d==0,far_parallax,d)
    safe=np.maximum(safe,np.finfo(np.float64).tiny)
    z=camera.focal*camera.baseline/safe
    x=((l[:,0]+r[:,0])*.5-camera.cx)*z/camera.focal
    y=((l[:,1]+r[:,1])*.5-camera.cy)*z/camera.focal
    return np.column_stack((x,y,z))


def ray_intersect(x,y,n,camera):
    """Intersect midpoint rays with explicit 3D planes; output world XYZ."""
    x=np.asarray(x,dtype=np.float32);y=np.asarray(y,dtype=np.float32)
    n=np.asarray(n,dtype=np.float32)
    u=(x-camera.cx)/camera.focal
    v=(y-camera.cy)/camera.focal
    invz=n[...,0]*u+n[...,1]*v+n[...,2]
    z=np.divide(1.,invz,out=np.full(np.broadcast_shapes(u.shape,invz.shape),np.nan,np.float32),where=invz>0)
    return np.stack(np.broadcast_arrays(u*z,v*z,z),axis=-1)


def project_xyz(xyz,camera,side):
    """Reproject an already solved physical 3D point into a real source camera."""
    z=xyz[...,2]
    off=(.5 if side=='left' else -.5)*camera.baseline
    return (camera.cx+camera.focal*(xyz[...,0]+off)/z,
            camera.cy+camera.focal*xyz[...,1]/z)


def _patches(obs,side):
    """Native connected L∩VC∩CC intersections; NO image-space square tiling.

    A facet may span many domain elements, and a native intersection can
    subsequently be split only by *conflicting stereo-supported plane* data.
    Image-grid coordinates must never introduce artificial 3D fold lines.
    """
    l=np.asarray(obs[f'{side}_L'],np.int32)
    v=np.asarray(obs[f'{side}_VC'],np.int32)
    c=np.asarray(obs[f'{side}_CC'],np.int32)
    triplets=np.stack((l.ravel(),v.ravel(),c.ravel()),axis=1)
    _,code=np.unique(triplets,axis=0,return_inverse=True)
    # label joins only 4-connected pixels with identical domain membership.
    # No tile index appears in the grouping key.
    patch=connected_equal_labels(code.reshape(l.shape).astype(np.int32),
                                 background=-1,connectivity=1)
    return np.asarray(patch-1,np.int32)


def _split_conflicting_native_patches(patch, plane_image, coords, planeids, conf, nplanes, require_support=False):
    """Allow a native L/VC/CC intersection to bend only when boundary evidence
    supports distinct planes WITHIN it. The split follows nearest matched
    boundary arcs, not a fixed image grid, and never invents a disparity field.
    """
    h,w=patch.shape
    x=np.clip(np.rint(coords[:,0]).astype(np.int32),0,w-1)
    y=np.clip(np.rint(coords[:,1]).astype(np.int32),0,h-1)
    good=np.asarray(planeids)>=0
    x,y=x[good],y[good]
    pi=np.asarray(planeids[good],np.int32)
    weight=np.asarray(conf[good],np.float32)
    groups=patch[y,x]
    order=np.argsort(groups,kind='stable')
    groups=groups[order];x=x[order];y=y[order];pi=pi[order];weight=weight[order]
    unique,offset,count=np.unique(groups,return_index=True,return_counts=True)
    regions=ndimage.find_objects(patch+1)
    changed=0
    for g,off,cnt in zip(unique,offset,count):
        if cnt<2:continue
        ids=pi[off:off+cnt]
        mass=np.bincount(ids,weights=weight[off:off+cnt],minlength=nplanes)
        # A different model from ONE accidental stereo match must not
        # split a complete native element into Voronoi sheets. A genuine
        # second geometric chart requires repeatable, spatially spread arc
        # support, not merely a nonzero label vote. This is an observability
        # test at the ORIGINAL patch-splitting stage, not a post-process.
        total_mass=float(mass.sum())
        viable=[]
        if not require_support:
            viable=np.flatnonzero(mass>0).tolist()
        else:
            for k in np.flatnonzero(mass>0):
                take=np.flatnonzero(ids==k)
                weights=weight[off:off+cnt][take]
                effective=float(weights.sum()**2/max(np.dot(weights,weights),1e-9))
                span=max(np.ptp(x[off:off+cnt][take]),np.ptp(y[off:off+cnt][take])) if len(take)>1 else 0
                # Enough independent sampling and line extent to form an arc;
                # relative mass rejects a one-point disagreement on a long rim.
                if effective>=4. and span>=5 and mass[k]>=max(2.,.08*total_mass):
                    viable.append(int(k))
        if len(viable)<2:continue
        viable=np.asarray(viable,np.int32)
        roi=regions[int(g)]
        if roi is None:continue
        mask=patch[roi]==g
        ox=roi[1].start;oy=roi[0].start
        local_x=x[off:off+cnt]-ox;local_y=y[off:off+cnt]-oy
        distances=[]
        for k in viable:
            yy=local_y[ids==k];xx=local_x[ids==k]
            seed=np.zeros(mask.shape,bool)
            seed[yy,xx]=True
            # EDT returns a smooth Voronoi partition of the 2D sheet based on
            # stereomatched boundary samples; it is NOT a depth interpolation.
            distances.append(ndimage.distance_transform_edt(~seed))
        closest=viable[np.argmin(np.stack(distances,axis=0),axis=0)]
        output=plane_image[roi]
        output[mask]=closest[mask]
        changed+=1
    if not changed:return patch,plane_image,0
    # Make each connected native-intersection / plane combination into an
    # explicit piece, retaining the original observation's pixel identities.
    new_code=patch.astype(np.int64)*(nplanes+1)+plane_image
    new_patch=connected_equal_labels(new_code,background=-1,connectivity=1)-1
    return new_patch.astype(np.int32),plane_image,changed



def _fold_from_native_neighbor_joins(patch,plane_image,nplanes):
    """Give a continuous DPG patch multiple facets when its *boundaries*
    contact different already-inferred world planes. This is a topological
    fold hypothesis, not a per-pixel depth solve or an artificial tile grid.
    Region-wide boundary seed curves select the parts of the patch to bend.
    """
    h,w=patch.shape
    rois=ndimage.find_objects(patch+1)
    out=plane_image.copy()
    changed=0
    for ident,roi in enumerate(rois):
        if roi is None:continue
        sub=patch[roi];mask=sub==ident
        if mask.sum()<2:continue
        sy,sx=np.nonzero(mask)
        x=sx+roi[1].start;y=sy+roi[0].start
        source={}
        for dx,dy in ((-1,0),(1,0),(0,-1),(0,1)):
            nx=x+dx;ny=y+dy
            inside=(nx>=0)&(nx<w)&(ny>=0)&(ny<h)
            if not inside.any():continue
            j=np.flatnonzero(inside)
            j=j[patch[ny[j],nx[j]]!=ident]
            if not len(j):continue
            model=plane_image[ny[j],nx[j]]
            for k in np.unique(model[model>=0]):
                pick=j[model==k]
                seed=source.setdefault(int(k),np.zeros(mask.shape,bool))
                seed[sy[pick],sx[pick]]=True
        if len(source)<2:continue
        labels=np.fromiter(sorted(source),np.int32)
        distances=np.stack([ndimage.distance_transform_edt(~source[int(k)]) for k in labels])
        target=labels[np.argmin(distances,axis=0)]
        roi_out=out[roi]
        roi_out[mask]=target[mask]
        changed+=1
    if not changed:return patch,plane_image,0
    # A fold is represented by NEW CONNECTED REGION SUPPORTS. The three
    # original DPG domain label arrays remain completely unchanged.
    code=patch.astype(np.int64)*(nplanes+1)+out
    revised=(connected_equal_labels(code,background=-1,connectivity=1)-1).astype(np.int32)
    return revised,out,changed


def _patch_graph(patch,obs,side):
    """Topological adjacency of native L,VC,CC patches (not nearest disparity)."""
    n=int(patch.max())+1
    aa=[];bb=[];ww=[]
    for a,b,slice_a,slice_b in ((patch[:,:-1],patch[:,1:],(slice(None),slice(None,-1)),(slice(None),slice(1,None))),
                                (patch[:-1,:],patch[1:,:],(slice(None,-1),slice(None)),(slice(1,None),slice(None)))):
        diff=a!=b
        if not diff.any():continue
        u=a[diff];v=b[diff]
        # Native boundaries do not automatically mean a 3D fold. Same member
        # across one or more domains is positive sheet-continuity evidence.
        same=np.zeros(a.shape,np.float32)
        for domain in DOMAINS:
            m=obs[f'{side}_{domain}'];same+=((m[slice_a]==m[slice_b])&(m[slice_a]>0)).astype(np.float32)/3.
        aa.append(u);bb.append(v);ww.append((.28+1.6*same[diff]).astype(np.float32))
    if not aa:return sparse.csr_matrix((n,n),dtype=np.float32)
    a=np.concatenate(aa);b=np.concatenate(bb);strength=np.concatenate(ww)
    return sparse.coo_matrix((np.r_[strength,strength],(np.r_[a,b],np.r_[b,a])),shape=(n,n)).tocsr()


def _patch_assignment(obs,side,coords,planeids,conf,nplanes,progress):
    patch=_patches(obs,side)
    n=int(patch.max())+1
    h,w=patch.shape
    xs=np.clip(np.rint(coords[:,0]).astype(int),0,w-1)
    ys=np.clip(np.rint(coords[:,1]).astype(int),0,h-1)
    valid=planeids>=0
    grp=patch[ys[valid],xs[valid]];pid=planeids[valid].astype(int)
    weights=np.asarray(conf[valid],np.float32)
    votes=np.bincount(grp*nplanes+pid,weights=weights,minlength=n*nplanes).reshape(n,nplanes).astype(np.float32)
    anchor_mass=votes.sum(axis=1)
    # A direct boundary match is evidence about the WHOLE intersected sheet
    # patch, not a hard depth constraint on that exact pixel.
    quality=np.divide(votes,anchor_mass[:,None],out=np.zeros_like(votes),where=anchor_mass[:,None]>0)
    g=_patch_graph(patch,obs,side)
    degree=np.asarray(g.sum(axis=1)).ravel().astype(np.float32)
    # Graph harmonic extension of sheet identities with fixed structural
    # evidence. There is NO pixelwise disparity propagation here.
    prior=votes.sum(axis=0)
    prior=(prior+1.)/(prior.sum()+nplanes)
    scores=np.tile(prior.astype(np.float32),(n,1))
    strength=np.minimum(anchor_mass,15.).astype(np.float32)*2.5
    for iteration in range(55):
        neighbor=g@scores
        scores=(neighbor+strength[:,None]*quality+.025*prior[None,:])/\
               (degree[:,None]+strength[:,None]+.025)
    winners=np.argmax(scores,axis=1).astype(np.int32)
    direct=(anchor_mass>0)
    # Block implausible labels in patches with direct data: don't silently
    # replace majority boundary evidence with topological diffusion.
    winners[direct]=np.argmax(votes[direct],axis=1).astype(np.int32)
    total_valid=int(np.count_nonzero(anchor_mass))
    plane_image=winners[patch].copy()
    patch,plane_image,folded=_split_conflicting_native_patches(
        patch,plane_image,coords,planeids,conf,nplanes)
    patch,plane_image,folded_neighbors=_fold_from_native_neighbor_joins(
        patch,plane_image,nplanes)
    # The new connected pieces inherit their nearest *geometrically measured*
    # plane. No new plane is created just because a tile boundary exists.
    newn=int(patch.max())+1
    newwinners=np.zeros(newn,np.int32)
    newwinners[patch.ravel()]=plane_image.ravel()
    progress(f'{side}: {n} native L∩VC∩CC regions, {total_valid} with boundary evidence; '
             f'{folded} multi-plane regions split by observed geometry; '
             f'{folded_neighbors} native patches folded by adjacent boundary structures')
    return patch,newwinners,plane_image,dict(patches=newn,native_regions=n,
       original_tiled_patches_removed=True,stereo_supported_multi_plane_splits=folded,
       neighbor_guided_folds=folded_neighbors,
       with_boundary_evidence=total_valid,
       patch_evidence_fraction=float(total_valid/max(n,1)),same_source_pixel_one_sheet=True,
       original_element_not_assumed_equal_to_physical_plane=True)


def _couple_supported_creases(world,obs,left_labels,matches,match_ids,camera):
    """One simultaneous 3D fit of facet planes AND supported shared hinges.

    A crease is a single 3D line: its two incident planes must intersect
    along the same spatial curve. Only small existing gaps with continuity
    evidence in at least one source domain qualify. Real 3D depth jumps are
    intentionally NOT welded. This is soft-constrained, because the available
    DPG boundaries do not establish every true physical hinge.
    """
    from scipy.sparse.linalg import lsqr
    h,w=left_labels.shape;K=len(world)
    if K<2:return world,dict(supported_crease_samples=0,refinement='not_needed')
    triples=[]
    yy,xx=np.indices((h,w),dtype=np.int32)
    for axis in (0,1):
        if axis==0:
            la,lb=left_labels[::5,:-1:5],left_labels[::5,1::5]
            # Sample adjacent ORIGINAL pixels, not adjacent sampled indices.
            yy0,xx0=np.mgrid[0:h:5,0:w-1:5]
            la=left_labels[yy0,xx0];lb=left_labels[yy0,xx0+1]
            neighbors=[(obs[f'left_{d}'][yy0,xx0]==obs[f'left_{d}'][yy0,xx0+1]) for d in DOMAINS]
        else:
            yy0,xx0=np.mgrid[0:h-1:5,0:w:5]
            la=left_labels[yy0,xx0];lb=left_labels[yy0+1,xx0]
            neighbors=[(obs[f'left_{d}'][yy0,xx0]==obs[f'left_{d}'][yy0+1,xx0]) for d in DOMAINS]
        candidate=(la>=0)&(lb>=0)&(la!=lb)
        if not candidate.any():continue
        same=np.sum(neighbors,axis=0)
        candidate &= same>=1
        if not candidate.any():continue
        yi=yy0[candidate].astype(np.float32)
        xi=xx0[candidate].astype(np.float32)
        aa=la[candidate].astype(np.int32);bb=lb[candidate].astype(np.int32)
        continuity=same[candidate].astype(np.float32)
        ray=np.column_stack(((xi-camera.cx)/camera.focal,
                             (yi-camera.cy)/camera.focal,np.ones(len(xi),np.float32)))
        q1=np.sum(world[aa]*ray,axis=1)
        q2=np.sum(world[bb]*ray,axis=1)
        gap=np.abs(q1-q2)*camera.focal*camera.baseline
        include=(gap<2.0)&(q1>0)&(q2>0)
        if include.any():triples.append((aa[include],bb[include],ray[include],continuity[include],gap[include]))
    if not triples:return world,dict(supported_crease_samples=0,refinement='no_geometrically_supported_hinges')
    a=np.concatenate([p[0] for p in triples]);b=np.concatenate([p[1] for p in triples])
    xyz=np.concatenate([p[2] for p in triples]);c=np.concatenate([p[3] for p in triples]);gap=np.concatenate([p[4] for p in triples])
    # Retain multiple locations along the same crease, not only an endpoint.
    # Add one weighted planar observation equation per 3D boundary pair.
    ids=np.asarray(match_ids,np.int32)
    good=ids>=0
    l=np.asarray(matches.left_xy)[good];r=np.asarray(matches.right_xy)[good]
    d=l[:,0]-r[:,0]
    mid=(l+r)*.5
    rr=np.column_stack(((mid[:,0]-camera.cx)/camera.focal,
                        (mid[:,1]-camera.cy)/camera.focal,np.ones(len(mid))))
    weights=np.sqrt(np.clip(np.asarray(matches.confidence)[good],.05,1.))
    # Data equation uses triangulated paired boundary coordinates only.
    scale=camera.focal*camera.baseline
    n=len(l);m=len(a)
    i_obs=np.arange(n)[:,None]
    obs_cols=3*ids[good,None]+np.arange(3)[None,:]
    crease_i=np.arange(m)[:,None]+n
    crease_weight=np.sqrt(np.clip(c*.40,.25,1.2))
    row=np.r_[np.repeat(i_obs,3,axis=1).ravel(),
              np.repeat(crease_i,3,axis=1).ravel(),
              np.repeat(crease_i,3,axis=1).ravel(),
              np.arange(3*K)+n+m]
    col=np.r_[obs_cols.ravel(),(3*a[:,None]+np.arange(3)).ravel(),
              (3*b[:,None]+np.arange(3)).ravel(),np.arange(3*K)]
    value=np.r_[(rr*weights[:,None]*scale).ravel(),
                (xyz*crease_weight[:,None]*scale).ravel(),
                (-xyz*crease_weight[:,None]*scale).ravel(),
                np.full(3*K,.05,np.float32)]
    mat=sparse.coo_matrix((value,(row,col)),shape=(n+m+3*K,3*K)).tocsr()
    targets=np.r_[d*weights,np.zeros(m),world.ravel()*.05]
    fitted=lsqr(mat,targets,atol=1e-7,btol=1e-7,iter_lim=200)[0].reshape(K,3).astype(np.float32)
    before=np.abs(np.sum(world[ids[good]]*rr,axis=1)*scale-d)
    after=np.abs(np.sum(fitted[ids[good]]*rr,axis=1)*scale-d)
    bmedian=float(np.median(before));amedian=float(np.median(after))
    positive=(np.sum(fitted[ids[good]]*rr,axis=1)>0).mean()>.995
    # Never sacrifice good observed stereo boundary alignment to fix guessed folds.
    accept=positive and amedian<max(.6,bmedian*1.2)
    return fitted if accept else world,dict(supported_crease_samples=int(m),
        crease_median_gap_px_before=float(np.median(gap)),
        crease_median_gap_px_after=float(np.median(np.abs(np.sum((fitted[a]-fitted[b])*xyz,axis=1))*scale) if accept else np.median(gap)),
        boundary_median_residual_before_px=bmedian,boundary_median_residual_after_px=amedian,
        joint_3d_refinement_accepted=bool(accept))


def _repair_nonphysical_patch_planes(obs,side,patch,assigned,planes,camera):
    """Repair only physically impossible topological plate assignments.

    The prior harmonic propagation can transfer a well-fitted stereo plane to
    another native DPG region on which that plane lies BEHIND the camera. This
    is an invalid geometric inference, even though its plane-ID exists in the
    registry. Reassignment uses ONLY observed adjacency in the original
    L/VC/CC boundary graph and tested positive ray/plane intersections.
    No pixel disparity, RGB color or invented geometric plane is involved.
    """
    h,w=patch.shape
    n=int(patch.max())+1
    if not n or not len(planes):return assigned,dict(corrected_patches=0,unresolved_patches=0)
    ids=np.asarray(assigned,dtype=np.int32).copy()
    ys,xs=np.mgrid[2:h:5,2:w:5]
    if not ys.size:ys,xs=np.indices((h,w))
    p=patch[ys,xs].ravel()
    count=np.bincount(p,minlength=n)
    uv=(xs.ravel()-camera.cx)/camera.focal
    vv=(ys.ravel()-camera.cy)/camera.focal
    off=(-.5 if side=='left' else .5)*camera.baseline
    feasible=np.zeros((n,len(planes)),dtype=np.float32)
    for k,coef in enumerate(planes):
        den=coef[0]*uv+coef[1]*vv+coef[2]
        z=np.divide(1.-coef[0]*off,den,out=np.full_like(den,np.nan),where=np.abs(den)>1.e-10)
        ok=np.isfinite(z)&(z>0)
        feasible[:,k]=np.bincount(p,weights=ok.astype(np.float32),minlength=n)/np.maximum(1,count)
    # Regions too small to hit the 5 px test grid are tested at actual region
    # representatives; no small element is discarded from the model.
    missing=np.flatnonzero(count==0)
    if len(missing):
        flat=patch.ravel();first=np.full(n,len(flat),np.int64)
        np.minimum.at(first,flat,np.arange(len(flat)))
        # The vectorized minimum above finds one original pixel per native patch.
        for k,coef in enumerate(planes):
            yy=first[missing]//w;xx=first[missing]%w
            den=coef[0]*(xx-camera.cx)/camera.focal+coef[1]*(yy-camera.cy)/camera.focal+coef[2]
            z=np.divide(1.-coef[0]*off,den,out=np.full_like(den,np.nan,dtype=np.float64),where=np.abs(den)>1.e-10)
            feasible[missing,k]=(np.isfinite(z)&(z>0)).astype(np.float32)
    valid_ids=(ids>=0)&(ids<len(planes))
    current=np.where(valid_ids,feasible[np.arange(n),np.clip(ids,0,len(planes)-1)],0.)
    problematic=current<.25
    if not problematic.any():return ids,dict(corrected_patches=0,unresolved_patches=0)
    graph=_patch_graph(patch,obs,side).tocsr()
    original=ids.copy()
    # Boundary-connected propagation first; all propagated planes must pass
    # the per-region physical ray test. Unanchored islands stay unresolved.
    for _ in range(16):
        changed=0
        for i in np.flatnonzero(problematic):
            start,end=graph.indptr[i:i+2]
            neighbors=graph.indices[start:end]
            if not len(neighbors):continue
            candidate=ids[neighbors]
            keep=(candidate>=0)&(candidate<len(planes))
            candidate=candidate[keep]
            weight=graph.data[start:end][keep]
            if not len(candidate):continue
            plausible=feasible[i,candidate]>=.65
            if not plausible.any():continue
            candidate=candidate[plausible];weight=weight[plausible]
            scores=np.bincount(candidate,weights=weight,minlength=len(planes))
            best=int(np.argmax(scores))
            if scores[best]>0 and ids[i]!=best:
                ids[i]=best;problematic[i]=False;changed+=1
        if not changed:break
    ids[problematic]=-1
    # Caller maps only native patch IDs; never modifies the original DPG labels.
    return ids,dict(corrected_patches=int(np.count_nonzero((ids!=original)&(ids>=0))),
        unresolved_patches=int(np.count_nonzero(ids<0)),
        strategy='native_adjacency_with_forward_positive_sheet_intersection',
        invented_depth_or_stereo_correspondence=False)



def _complete_unplaced_regions(world,left_ids,right_ids,patches,camera,progress,obs=None):
    """Complete ONLY otherwise unsupported native regions.

    V2 incorrectly selected the plane with the largest inverse depth among
    ALL world planes. That could put a far native observation on a completely
    unrelated foreground sheet and hide observed table legs or small signs.

    V3 ranks geometry from the SAME source DPG element and nearby compatible
    native patches first. No new stereo correspondences are manufactured.
    The fallback is one far, explicitly uncertain horizon plane, not the
    nearest arbitrary reconstructed object. Original domain IDs stay intact.
    """
    from scipy.spatial import cKDTree
    h,w=patches[0].shape
    output=[];inherited=0;adjacent=0;horizon_patches=0
    horizon_id=None
    for side,(ids,patch) in enumerate(zip((left_ids,right_ids),patches)):
        cam_side='left' if side==0 else 'right'
        ids=np.asarray(ids,np.int32).copy()
        missing=np.flatnonzero(ids<0)
        if not len(missing):
            output.append(ids);continue
        count=len(ids)
        flat=patch.ravel(); first=np.full(count,flat.size,np.int64)
        np.minimum.at(first,flat,np.arange(flat.size,dtype=np.int64))
        ry=(first//w).astype(np.int32);rx=(first%w).astype(np.int32)
        domain_ids={d:np.asarray(obs[f'{cam_side}_{d}'])[ry,rx] for d in DOMAINS} if obs is not None else {}
        good=np.flatnonzero(ids>=0)
        # Build inverse element membership indexes once; these are the native
        # source element IDs, never source-specific physical 3D identities.
        members={}
        for d,values in domain_ids.items():
            for k in good:
                key=(d,int(values[k]))
                if key[1]<=0:continue
                members.setdefault(key,[]).append(int(k))
        offset=(-.5 if side==0 else .5)*camera.baseline
        for reg in missing:
            y,x=int(ry[reg]),int(rx[reg]);u=(x-camera.cx)/camera.focal;v=(y-camera.cy)/camera.focal
            candidates={}
            for domain,labels in domain_ids.items():
                identifier=int(labels[reg]);
                if identifier<=0:continue
                same=members.get((domain,identifier),[])
                for peer in same:
                    if peer==reg:continue
                    plane=int(ids[peer])
                    if plane<0:continue
                    distance=float(np.hypot(x-int(rx[peer]),y-int(ry[peer])))
                    # L/VC/CC can overlap on the same physical surface.
                    # The only allowed inheritance evidence here is shared
                    # native membership, with spatial proximity as a weight.
                    candidates[plane]=candidates.get(plane,0.)+1./(1.+distance/25.)
            feasible={}
            for plane,score in candidates.items():
                coef=world[plane]
                den=float(coef[0]*u+coef[1]*v+coef[2])
                z=(1.-float(coef[0])*offset)/den if abs(den)>1.e-10 else -1.
                if np.isfinite(z) and 0.001<z<1.e6:feasible[plane]=score
            if feasible:
                ids[reg]=max(feasible,key=feasible.get);inherited+=1
                continue
            # No same-element support. A nearby native patch may still
            # provide a weak continuation hypothesis, but a distant plane
            # from elsewhere in the room may not.
            if good.size:
                distances=np.square(rx[good].astype(np.float64)-x)+np.square(ry[good].astype(np.float64)-y)
                nearest=good[np.argsort(distances)[:12]]
                for peer in nearest:
                    plane=int(ids[peer]);coef=world[plane]
                    den=float(coef[0]*u+coef[1]*v+coef[2])
                    z=(1.-float(coef[0])*offset)/den if abs(den)>1.e-10 else -1.
                    if np.isfinite(z) and 0.001<z<1.e6 and distances[np.searchsorted(good,peer)]<80.**2:
                        ids[reg]=plane;adjacent+=1;break
            if ids[reg]>=0:continue
            # A completely unsupported native region stays unassigned in
            # 3D. Render may still use a strictly 2D backdrop to preserve
            # picture coverage. A distant fabricated 3D plane would violate
            # the rule that unknown image background is NOT a world surface.
            horizon_patches+=1
        output.append(ids)
    progress(f'Native sheet completion: {inherited} same-DPG-element, '
             f'{adjacent} near-native, {horizon_patches} unassigned 2D-only regions')
    return world,output[0],output[1],dict(same_element_continuations=inherited,
        nearby_native_continuations=adjacent,unresolved_3d_regions=horizon_patches,
        hypothesis_not_stereo_verified=True,horizon_surface_id=None,
        prohibited_arbitrary_nearest_foreground=True)


def solve(obs,matches,progress=lambda _:None,max_planes=None,camera=None,
          geometry_mode='conservative'):
    """v1.6: one joint, camera-symmetric structural geometry optimization.

    Native L/VC/CC elements remain untouched. Local planar charts are
    geometric variables, not original element IDs or predetermined surfaces.
    """
    shape=obs['left_L'].shape
    if camera is None:camera=camera_from_shape(shape)
    for s in ('left','right'):
        for d in DOMAINS:
            if obs[f'{s}_{d}'].shape!=shape:
                raise ValueError('Mismatching original DPG image shapes')
    if geometry_mode not in ('conservative','experimental'):
        raise ValueError('geometry_mode')
    strict=geometry_mode=='experimental'
    coeff0,labs0,_,discovery=discover_planes(matches,shape,max_planes=max_planes,
                                             enforce_monotonic=strict)
    from joint_world_solver import joint_solve
    coeff,lp,rp,lpids,rpids,matched,optimization=joint_solve(
        obs,matches,coeff0,labs0,progress,
        camera=camera if strict else None, strict_folds=strict)
    # A single conversion from jointly determined stereo curve geometry into
    # one 3D world. Never instantiate left/right 3D plane duplicates.
    f=camera.focal;cx=camera.cx;cy=camera.cy;B=camera.baseline
    a,b,c=np.asarray(coeff,np.float64).T
    scale=f*B*(1-.5*a)
    if np.any(np.abs(scale)<1e-8):
        raise ValueError('Degenerate 3D surface after joint boundary fit')
    world=np.column_stack((a*f,b*f,a*cx+b*cy+c))/scale[:,None]
    world=world.astype(np.float32)
    # A non-forward inferred patch is not forced into impossible geometry.
    # Its original observation persists, and structural neighbours may offer
    # a distinct, explicitly uncertain placement hypothesis.
    lpids,lr=_repair_nonphysical_patch_planes(obs,'left',lp,lpids,world,camera)
    rpids,rr=_repair_nonphysical_patch_planes(obs,'right',rp,rpids,world,camera)
    world,lpids,rpids,completion=_complete_unplaced_regions(
        world,lpids,rpids,(lp,rp),camera,progress,obs=obs)
    left=lpids[lp];right=rpids[rp]
    from world_component_graph import structural_components
    components,component_report=structural_components(obs,left,right,world,camera,matched)
    points=triangulate_boundary(matches.left_xy,matches.right_xy,camera,
                                discovery['display_proxy_parallax_px'])
    valid=np.asarray(matched)>=0
    boundary_error=np.full(len(matched),np.nan,np.float64)
    if valid.any():
        boundary_error[valid]=np.abs(np.sum(points[valid]*world[matched[valid]],axis=1)-1)
    residual=boundary_error[valid]
    stats=dict(geometry='v1.6 jointly optimized 3D structural network',
        source_RGB_disparity_map_received=False,no_pixelwise_depth_interpolation=True,
        geometry_mode=geometry_mode,
        shared_world_planes=int(len(world)),
        boundary_fit_world_residual_median=float(np.median(residual)) if residual.size else None,
        left=optimization['left'],right=optimization['right'],
        geometry_repair_left=lr,geometry_repair_right=rr,
        unplaced_region_completion=completion,
        joint_structure=optimization,structure_components=component_report,**discovery)
    physical_report=[]
    for k,n in enumerate(world):
        hits=matched==k
        arc_ids=np.asarray(matches.segment_id)[hits]
        physical_report.append(dict(id=int(k),physical_world_plane_normal=list(map(float,n)),
            plane_equation='normal dot XYZ = 1',
            structure_component=int(components[k]),
            stereo_matched_boundary_samples=int(hits.sum()),
            stereo_partial_arcs=int(len(np.unique(arc_ids))),
            median_matched_boundary_residual_px=float(np.median(np.abs(
                (matches.left_xy[hits,0]-matches.right_xy[hits,0])-
                (coeff[k,0]*matches.left_xy[hits,0]+coeff[k,1]*matches.left_xy[hits,1]+coeff[k,2])))) if hits.any() else None))
    if completion['horizon_surface_id'] is not None:
        physical_report[-1]['hypothesis']='unmatched region display continuation; not stereo verified'
    return SheetSolution(world,left,right,lp,rp,lpids,rpids,
                         matched,camera,physical_report,stats,components)
