"""GT-free diagnostic for internal sheet breaks across an unchanged DPG region.

A split is NOT automatically wrong: appearance regions can span physical
folds. Counts flag the parts of the source plane assignment responsible for
real cracks that no continuous renderer should conceal by hallucination.
"""
import numpy as np

def diagnose(original_labels,plane_maps):
    result={}
    for side in ('left','right'):
        labels=[np.asarray(original_labels[f'{side}_{domain}'],np.int32) for domain in ('L','VC','CC')]
        model=np.asarray(plane_maps[side],np.int32)
        same_x=np.ones((model.shape[0],model.shape[1]-1),bool)
        same_y=np.ones((model.shape[0]-1,model.shape[1]),bool)
        for lab in labels:
            same_x &= (lab[:,1:]==lab[:,:-1])&(lab[:,1:]>0)
            same_y &= (lab[1:,:]==lab[:-1,:])&(lab[1:,:]>0)
        split_x=same_x&(model[:,1:]!=model[:,:-1])
        split_y=same_y&(model[1:,:]!=model[:-1,:])
        mask=np.zeros(model.shape,np.uint8)
        mask[:,1:] |= split_x.astype(np.uint8)
        mask[1:,:] |= split_y.astype(np.uint8)
        result[side]={'internal_native_membership_plane_transitions':int(split_x.sum()+split_y.sum()),
            'stable_membership_neighbor_edges':int(same_x.sum()+same_y.sum()),
            'internal_split_fraction':round(float((split_x.sum()+split_y.sum())/max(1,same_x.sum()+same_y.sum())),7)}
        result[f'{side}_mask']=mask
    return result
