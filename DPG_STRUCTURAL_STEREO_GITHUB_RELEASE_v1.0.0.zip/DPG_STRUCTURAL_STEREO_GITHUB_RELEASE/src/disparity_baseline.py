"""Non-neural full-native-resolution SGBM, two camera views, midpoint resampling.

No DPG/GT input. Computes the SGBM disparity on unresized rectified RGBs,
then independently inverse-samples continuous (non-folding) epipolar stretches
from each source image. Left/right z-selection is based on disparity magnitude.
Unresolved pixels remain a 2D RGB proxy; the mask distinguishes them.
"""
from __future__ import annotations
import csv,json,time,os,traceback
from pathlib import Path
import numpy as np
import cv2
from PIL import Image
from dataset_io import Dataset


def compute_disparities(left, right, num_disparities=256, block_size=5, progress=lambda _:None):
    if left.shape != right.shape:raise ValueError('Stereo image resolutions do not match')
    h,w=left.shape[:2]
    nd=int(num_disparities)
    # On very small images a large search range makes the independently valid
    # left and right scan regions disjoint even when true disparity is tiny.
    if w<2*nd+32:
        nd=min(nd,max(16,(w//3//16)*16))
    if nd%16 or nd<16 or nd>=w-16:
        raise ValueError(f'Disparity-hakualueen on oltava 16:n monikerta, >=16 ja alle leveys-16 ({w-16}). Nyt {nd}.')
    b=int(block_size)
    if b<1 or b%2!=1:raise ValueError('blockSize tulee olla positiivinen pariton luku')
    # True colour SGBM: preserve the three observed colour channels in cost.
    # No input is resized, and no DPG or GT participates in matching.
    L=np.ascontiguousarray(np.asarray(left,np.uint8))
    R=np.ascontiguousarray(np.asarray(right,np.uint8))
    mode=cv2.STEREO_SGBM_MODE_SGBM_3WAY
    def make(min_disp):
        return cv2.StereoSGBM_create(minDisparity=min_disp,numDisparities=nd,
          blockSize=b,P1=8*3*b*b,P2=32*3*b*b,disp12MaxDiff=1,preFilterCap=31,
          uniquenessRatio=8,speckleWindowSize=80,speckleRange=2,mode=mode)
    progress('SGBM left to right at native resolution')
    dl=make(0).compute(L,R).astype(np.float32)/16.
    progress('SGBM right to left at native resolution')
    dr=make(-nd).compute(R,L).astype(np.float32)/16.
    vl=(dl>=0)&(dl<nd)
    vr=(dr<0)&(dr>-nd)
    yy,xx=np.indices((h,w),dtype=np.float32)
    dest_l=xx-dl
    dest_r=xx-dr
    dR_from_L=cv2.remap(dr,np.nan_to_num(dest_l,nan=-1e5).astype(np.float32),yy,cv2.INTER_LINEAR,
                      borderMode=cv2.BORDER_CONSTANT,borderValue=np.nan)
    dL_from_R=cv2.remap(dl,np.nan_to_num(dest_r,nan=-1e5).astype(np.float32),yy,cv2.INTER_LINEAR,
                      borderMode=cv2.BORDER_CONSTANT,borderValue=np.nan)
    good_l=vl&np.isfinite(dR_from_L)&(np.abs(dl+dR_from_L)<=1.5)
    good_r=vr&np.isfinite(dL_from_R)&(np.abs(dr+dL_from_R)<=1.5)
    return dl,dr,vl,vr,good_l,good_r


def _inverse_epipolar_map(disparity,valid,side):
    """Rasterize continuous strips, *not* a forward splat of source centers.

    No joining across invalid pixels, large local disparity jumps, or folding.
    For each target pixel interpolate source x and disparity inside a valid
    source-interval and keep the nearer interval where projected strips overlap.
    """
    h,w=disparity.shape
    invx=np.full((h,w),-1.,np.float32)
    invd=np.zeros((h,w),np.float32)
    xs=np.arange(w,dtype=np.float32)
    sign=1 if side=='left' else -1
    for y in range(h):
        d=disparity[y]
        v=valid[y]
        xmid=xs-sign*d*.5 # right disparity is negative: use physical signed d directly below
        if side=='right':xmid=xs-d*.5
        # left: xM = xL - dL/2. right: xM = xR - dR/2, dR < 0.
        if side=='left':xmid=xs-d*.5
        delta=np.diff(xmid)
        delta_d=np.abs(np.diff(d))
        link=v[:-1]&v[1:]&np.isfinite(delta)&(delta>0.03)&(delta<3.5)&(delta_d<3.5)
        # maximal continuous runs in SOURCE coordinates
        edges=np.flatnonzero(~link)
        starts=np.r_[0,edges+1];stops=np.r_[edges+1,w]
        for a,b in zip(starts,stops):
            if b-a<2:continue
            xp=xmid[a:b]
            begin=max(0,int(np.ceil(xp[0])));end=min(w-1,int(np.floor(xp[-1])))
            if begin>end:continue
            target=np.arange(begin,end+1,dtype=np.int32)
            orig=np.interp(target.astype(np.float32),xp,xs[a:b]).astype(np.float32)
            dep=np.interp(target.astype(np.float32),xp,np.abs(d[a:b])).astype(np.float32)
            better=(dep>invd[y,target])
            invx[y,target[better]]=orig[better]
            invd[y,target[better]]=dep[better]
    return invx,invd


def synthesize_midpoint(left,right,dl,dr,vl,vr,good_l,good_r,progress=lambda _:None):
    h,w=dl.shape
    progress('Back-project both views from continuous epipolar intervals')
    xL,depthL=_inverse_epipolar_map(dl,vl,'left')
    xR,depthR=_inverse_epipolar_map(dr,vr,'right')
    yr=np.broadcast_to(np.arange(h,dtype=np.float32)[:,None],(h,w)).copy()
    rgbL=cv2.remap(left,xL,yr,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0))
    rgbR=cv2.remap(right,xR,yr,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0))
    vL=xL>=0;vR=xR>=0
    # reprojection consistency at continuous source location, for diagnostics
    cL=cv2.remap(good_l.astype(np.uint8),xL,yr,cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT)>0
    cR=cv2.remap(good_r.astype(np.uint8),xR,yr,cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT)>0
    # Corresponding surfaces should have nearly equal positive disparity.
    close=vL&vR&(np.abs(depthL-depthR)<=np.maximum(1.25,.035*np.maximum(depthL,depthR)))
    # A very bad left-right check is not sufficient to overwrite an otherwise
    # valid visible source strip. Both are retained when geometry agrees.
    both=close
    onlyL=vL&(~vR | ((~close)&(depthL>=depthR)))
    onlyR=vR&(~vL | ((~close)&(depthR>depthL)))
    classmap=np.zeros((h,w),np.uint8)
    classmap[onlyL]=1;classmap[onlyR]=2;classmap[both]=3
    out=np.empty_like(left)
    out[:]=left # every final pixel has RGB; these are flagged as 2D proxies
    out[onlyL]=rgbL[onlyL];out[onlyR]=rgbR[onlyR]
    if np.any(both):
        # Visible in both: RGB from BOTH original cameras, not one chosen source.
        out[both]=np.rint((rgbL[both].astype(np.float32)+rgbR[both].astype(np.float32))*.5).astype(np.uint8)
    unknown=classmap==0
    # Fill tiny bounded unsolved gaps photometrically; not new geometry.
    # Big unsupported zones are left as the native left-view RGB backdrop.
    count,names,stats,_=cv2.connectedComponentsWithStats(unknown.astype(np.uint8),connectivity=8)
    small=np.zeros((h,w),np.uint8)
    for i in range(1,count):
        if stats[i,cv2.CC_STAT_AREA]<=64 and stats[i,cv2.CC_STAT_LEFT]>0 and stats[i,cv2.CC_STAT_TOP]>0 and \
           stats[i,cv2.CC_STAT_LEFT]+stats[i,cv2.CC_STAT_WIDTH]<w and stats[i,cv2.CC_STAT_TOP]+stats[i,cv2.CC_STAT_HEIGHT]<h:
            small[names==i]=255
    if np.any(small):
        out=cv2.inpaint(out,small,2.,cv2.INPAINT_TELEA)
    stats=dict(
        native_resolution=[w,h],
        rasterization='bidirectional_continuous_epipolar_inverse_sampling',
        left_only_px=int((classmap==1).sum()),right_only_px=int((classmap==2).sum()),
        both_views_px=int((classmap==3).sum()),unknown_proxy_px=int(unknown.sum()),
        inpaint_small_unknown_px=int((small>0).sum()),
        left_sgbm_valid_px=int(vl.sum()),right_sgbm_valid_px=int(vr.sum()),
        left_right_consistent_source_px=int(good_l.sum()),
        right_left_consistent_source_px=int(good_r.sum()),
        gt_used=False,dpg_used=False)
    return out,classmap,stats


def run_batch(dataset_path,output_root,*,stop_requested=lambda:False,progress=lambda _:None,
              num_disparities=256,block_size=5,start=None,end=None,skip_existing=True):
    dataset=Dataset(dataset_path)
    name=Path(dataset_path).stem if Path(dataset_path).is_file() else Path(dataset_path).name
    name=''.join(c if c.isalnum() or c in '-_.' else '_' for c in name).strip('._') or 'dataset'
    folder=Path(output_root)/name;folder.mkdir(parents=True,exist_ok=True)
    diagnostic=folder/'diagnostics';diagnostic.mkdir(exist_ok=True)
    frames=[v for v in dataset.frames if (start is None or v>=start) and (end is None or v<=end)]
    if not frames:raise ValueError('No stereo pairs in the selected frame interval')
    # A same-named output directory must not silently mix two different datasets.
    prior=folder/'BATCH_REPORT.json'
    if prior.is_file():
        try:
            old=json.loads(prior.read_text(encoding='utf8'))
            if old.get('dataset') and Path(old['dataset']).resolve()!=Path(dataset_path).resolve():
                raise ValueError('Tuloskansiossa on eri datasetin tuloksia. Vaihda tuloskansiota. '+str(folder))
        except json.JSONDecodeError:pass
    items=[]
    failures=[]
    def save_report():
        manifest={'dataset':str(dataset_path),'output':str(folder),'method':'OpenCV_StereoSGBM_3WAY',
             'GT_used':False,'DPG_used':False,'frames_requested':len(frames),
             'frames_done':len(items),'stopped':bool(stop_requested()),
             'frames':items,'failures':failures}
        (folder/'BATCH_REPORT.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
        with (folder/'BATCH_REPORT.csv').open('w',encoding='utf-8-sig',newline='') as f:
            cols=('frame','status','seconds','left_only_px','right_only_px','both_views_px','unknown_proxy_px',
                  'left_sgbm_valid_px','right_sgbm_valid_px')
            writer=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore')
            writer.writeheader();writer.writerows(items)
        return manifest
    # Flush machine-readable history at each frame, to survive graceful stop.
    for i,frame in enumerate(frames):
        if stop_requested():break
        path=folder/f'frame_{frame:06d}.png'
        diag=diagnostic/f'frame_{frame:06d}_visibility.png'
        rec_path=diagnostic/f'frame_{frame:06d}_stats.json'
        if skip_existing and path.is_file() and rec_path.is_file():
            try:
                with Image.open(path) as p:
                    previous=json.loads(rec_path.read_text(encoding='utf8'))
                    parms=previous.get('parameters',{})
                    if (p.size==tuple(previous['native_resolution']) and
                        parms.get('requested_num_disparities')==int(num_disparities) and
                        parms.get('block_size')==int(block_size)):
                        items.append(dict(status='skipped',**previous))
                        progress(f'{i+1}/{len(frames)} frame {frame}: olemassa oleva kuva ohitetaan')
                        continue
            except Exception:pass
        t=time.monotonic()
        progress(f'{i+1}/{len(frames)} frame {frame}: luetaan RGB')
        try:
            left,right=dataset.load(frame)
            effective_nd=min(int(num_disparities),max(16,(left.shape[1]//3//16)*16)) if left.shape[1]<2*int(num_disparities)+32 else int(num_disparities)
            dl,dr,vl,vr,cl,cr=compute_disparities(left,right,num_disparities,block_size,
                progress=lambda msg:progress(f'Frame {frame}: {msg}'))
            if stop_requested():break
            midpoint,visibility,metrics=synthesize_midpoint(left,right,dl,dr,vl,vr,cl,cr,
                progress=lambda msg:progress(f'Frame {frame}: {msg}'))
            metrics.update(frame=int(frame),seconds=round(time.monotonic()-t,2),
                          parameters={'requested_num_disparities':int(num_disparities),
                                      'effective_num_disparities':effective_nd,'block_size':int(block_size)})
            Image.fromarray(midpoint).save(path.with_suffix('.part.png'))
            os.replace(path.with_suffix('.part.png'),path)
            colors=np.array([[27,28,33],[35,110,255],[255,55,65],[20,235,80]],dtype=np.uint8)
            Image.fromarray(colors[visibility]).save(diag)
            disp16=np.clip(np.rint(np.where(vl,dl,0)*256),0,65535).astype(np.uint16)
            cv2.imwrite(str(diagnostic/f'frame_{frame:06d}_disp16.png'),disp16)
            rec_path.write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf8')
            items.append(dict(status='ok',**metrics))
            progress(f'{i+1}/{len(frames)} frame {frame}: tallennettu {path.name}, RGB {metrics["native_resolution"]}')
        except Exception as exc:
            failures.append(dict(frame=int(frame),error=str(exc),trace=traceback.format_exc()))
            progress(f'{i+1}/{len(frames)} frame {frame}: VIRHE {exc}')
        finally:
            save_report()
    return folder,save_report()
