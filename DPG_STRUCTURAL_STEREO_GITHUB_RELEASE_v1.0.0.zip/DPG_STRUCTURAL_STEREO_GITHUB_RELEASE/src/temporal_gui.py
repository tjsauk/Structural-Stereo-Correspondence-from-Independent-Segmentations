"""Interactive native DPG temporal element/ROI tracking for a finite session.

Two original RGB images are always shown, plus exact target-frame membership
vs continuously warped source support on a BLACK panel. A missing matched
DPG region remains missing; it is not synthesized by optical flow.
"""
from __future__ import annotations
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
import numpy as np
import cv2
from PIL import Image
import json
from diagnostic_windows import ZoomCanvas
from temporal_links import follow_element,DOMAINS

BLUE=np.array([35,110,255],np.uint8)
RED=np.array([255,55,65],np.uint8)
GREEN=np.array([20,235,80],np.uint8)

class TimelineInspector:
    def __init__(self,parent,session):
        self.folder=Path(session)
        self.session=json.loads((self.folder/'SESSION.json').read_text(encoding='utf-8'))
        self.frames=list(self.session['completed_frames'])
        if not self.frames:raise ValueError('Session contains no completed frames')
        self.win=tk.Toplevel(parent);self.win.title('Temporal region and element tracking')
        self.win.geometry('1440x950')
        self.source=tk.IntVar(value=self.frames[0]);self.target=tk.IntVar(value=self.frames[-1])
        self.side=tk.StringVar(value='left');self.domain=tk.StringVar(value='L')
        self.status=tk.StringVar(value='Click an element in the left panel or select a region with Shift + drag.')
        self.selection=None;self._drag_start=None
        self._cache={};self._image_cache={}
        controls=ttk.Frame(self.win,padding=5);controls.pack(fill='x')
        ttk.Label(controls,text='Source frame').pack(side='left')
        s=ttk.Combobox(controls,textvariable=self.source,values=self.frames,width=8,state='readonly')
        s.pack(side='left',padx=4);s.bind('<<ComboboxSelected>>',lambda e:self._change_source())
        ttk.Label(controls,text='Target frame').pack(side='left',padx=(10,2))
        t=ttk.Combobox(controls,textvariable=self.target,values=self.frames,width=8,state='readonly')
        t.pack(side='left',padx=4);t.bind('<<ComboboxSelected>>',lambda e:self.update_view())
        ttk.Label(controls,text='Camera').pack(side='left',padx=(12,2))
        box=ttk.Combobox(controls,textvariable=self.side,values=['left','right'],width=7,state='readonly')
        box.pack(side='left');box.bind('<<ComboboxSelected>>',lambda e:self._change_source())
        ttk.Label(controls,text='Domain').pack(side='left',padx=(12,2))
        box=ttk.Combobox(controls,textvariable=self.domain,values=DOMAINS,width=5,state='readonly')
        box.pack(side='left');box.bind('<<ComboboxSelected>>',lambda e:self._change_source())
        ttk.Button(controls,text='Previous',command=lambda:self._advance(-1)).pack(side='left',padx=5)
        ttk.Button(controls,text='Next',command=lambda:self._advance(1)).pack(side='left')
        ttk.Button(controls,text='Save 3 PDFs',command=self.save_pdf).pack(side='right',padx=5)
        ttk.Label(self.win,textvariable=self.status,wraplength=1380).pack(fill='x',padx=8,pady=2)
        container=ttk.Frame(self.win);container.pack(fill='both',expand=True)
        container.columnconfigure(0,weight=1);container.columnconfigure(1,weight=1)
        container.rowconfigure(0,weight=1);container.rowconfigure(1,weight=1)
        self.a=ZoomCanvas(container,'Source RGB - blue selected region - click an element',click=self._pick)
        self.b=ZoomCanvas(container,'Target RGB - green matched / red alternative region')
        self.c=ZoomCanvas(container,'Black background: source projection (blue), target region (red), common (green)')
        self.a.grid(row=0,column=0,sticky='nsew');self.b.grid(row=0,column=1,sticky='nsew');self.c.grid(row=1,column=0,columnspan=2,sticky='nsew')
        self.a.canvas.bind('<Shift-ButtonPress-1>',self._roi_start)
        self.a.canvas.bind('<Shift-B1-Motion>',self._roi_drag)
        self.a.canvas.bind('<Shift-ButtonRelease-1>',self._roi_finish)
        self.images_out=[]
        self.win.after(200,self.update_view)

    def _folder(self,frame):return self.folder/f'frame_{int(frame):06d}'
    def _read(self,frame,side,domain):
        key=(int(frame),side,domain)
        if key not in self._cache:
            with np.load(self._folder(frame)/'dpg_labels.npz',allow_pickle=False) as z:
                self._cache[key]=z[f'{side}_{domain}'].copy()
            if len(self._cache)>15:self._cache.pop(next(iter(self._cache)))
        return self._cache[key]
    def _rgb(self,frame,side):
        key=(int(frame),side)
        if key not in self._image_cache:
            self._image_cache[key]=np.asarray(Image.open(self._folder(frame)/f'{side}.png').convert('RGB'))
            if len(self._image_cache)>10:self._image_cache.pop(next(iter(self._image_cache)))
        return self._image_cache[key]
    def _change_source(self):self.selection=None;self.update_view()
    def _advance(self,d):
        pos=self.frames.index(int(self.target.get()))
        self.target.set(self.frames[max(0,min(len(self.frames)-1,pos+d))]);self.update_view()
    def _pick(self,point):
        x,y=point
        label=self._read(self.source.get(),self.side.get(),self.domain.get())
        if y>=label.shape[0] or x>=label.shape[1]:return
        id=int(label[y,x])
        if id<=0:
            self.status.set('This pixel has no classified element; select another pixel.');return
        self.selection=label==id
        self.update_view()
    def _roi_start(self,e):
        self._drag_start=self.a.xy(e)
    def _roi_drag(self,e):pass
    def _roi_finish(self,e):
        if self._drag_start is None:return
        last=self.a.xy(e)
        if last is None:return
        (x0,y0),(x1,y1)=self._drag_start,last
        shape=self._read(self.source.get(),self.side.get(),self.domain.get()).shape
        selection=np.zeros(shape,bool)
        selection[max(0,min(y0,y1)):min(shape[0],max(y0,y1)+1),
                  max(0,min(x0,x1)):min(shape[1],max(x0,x1)+1)]=True
        self.selection=selection;self.update_view();self._drag_start=None
    def update_view(self):
        frame=int(self.source.get());target=int(self.target.get())
        side=self.side.get();domain=self.domain.get()
        source=self._rgb(frame,side);destination=self._rgb(target,side)
        labels_a=self._read(frame,side,domain);labels_b=self._read(target,side,domain)
        chosen=self.selection
        if chosen is not None and chosen.shape!=labels_a.shape:chosen=None;self.selection=None
        if chosen is None:
            self.a.set_image(source);self.b.set_image(destination)
            self.c.set_image(np.zeros_like(destination));return
        orig=np.asarray(chosen,bool)
        source_vis=source.copy()
        source_vis[orig]=np.rint(source[orig].astype(np.float32)*.48+BLUE*.52).astype(np.uint8)
        src_ids=np.unique(labels_a[orig]);src_ids=src_ids[src_ids>0]
        # The image-space ROIs are transported separately along the chain of
        # DPG links. A source region crossing elements need not move rigidly.
        predicted=np.zeros(labels_b.shape,np.uint8)
        actual=np.zeros(labels_b.shape,np.uint8)
        confirmed=[]
        lost=[]
        n_hyp=0
        limit=80
        for el in src_ids[:limit]:
            sub=orig&(labels_a==el)
            if frame==target:
                tracks=[(int(el),np.eye(3),1.)]
            else:
                tracks=follow_element(self.folder,frame,target,side,domain,int(el))
            if not tracks:lost.append(int(el));continue
            for dest_id,M,score in tracks:
                n_hyp+=1
                patch=cv2.warpAffine(sub.astype(np.uint8),M[:2,:3],
                                  (labels_b.shape[1],labels_b.shape[0]),
                                   flags=cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT)
                predicted|=patch
                actual|=(labels_b==dest_id).astype(np.uint8)
                confirmed.append((int(el),int(dest_id),float(score)))
        P=predicted>0;A=actual>0
        match=P&A;only_source=P&~A;only_target=A&~P
        dst_vis=destination.copy()
        dst_vis[only_target]=np.rint(destination[only_target].astype(float)*.5+RED*.5).astype(np.uint8)
        dst_vis[P]=np.rint(destination[P].astype(float)*.5+BLUE*.5).astype(np.uint8)
        dst_vis[match]=np.rint(destination[match].astype(float)*.55+GREEN*.45).astype(np.uint8)
        mid=np.zeros_like(destination)
        mid[only_source]=BLUE;mid[only_target]=RED;mid[match]=GREEN
        self.images_out=[source_vis,dst_vis,mid]
        self.a.set_image(source_vis);self.b.set_image(dst_vis);self.c.set_image(mid)
        overlap=int(match.sum());denom=int((P|A).sum());iou=overlap/max(denom,1)
        limit_note=(f' | LIMIT: only first {limit} elements were tracked' if len(src_ids)>limit else '')
        self.status.set(f'{frame} -> {target} | {side} / {domain} | {len(src_ids)} source elements | '
             f'{n_hyp} temporal links | {len(lost)} without links | '
             f'projection/element overlap {iou:.1%} | '
             'Target RGB comes from the target frame; occluded content is not synthesized. '+limit_note+' '
             '(Entire source-region identity is not asserted.)')
    def save_pdf(self):
        if len(self.images_out)!=3:return
        name=filedialog.asksaveasfilename(title='Temporal comparison PDF filename prefix',
            defaultextension='.pdf',filetypes=[('PDF','*.pdf')])
        if not name:return
        from result_browser import write_single_image_pdf
        base=Path(name).with_suffix('')
        for i,label in enumerate(('source','target','comparison')):
            write_single_image_pdf(Image.fromarray(self.images_out[i]),
                Path(str(base)+'_'+label+'.pdf'))
    def save(self):
        if len(self.images_out)!=3:return
        name=filedialog.asksaveasfilename(title='Save images: filename prefix',defaultextension='.png',
                                       filetypes=[('PNG','*.png')])
        if not name:return
        base=Path(name).with_suffix('')
        for i,label in enumerate(('source','target','comparison')):
            Image.fromarray(self.images_out[i]).save(str(base)+'_'+label+'.png')
