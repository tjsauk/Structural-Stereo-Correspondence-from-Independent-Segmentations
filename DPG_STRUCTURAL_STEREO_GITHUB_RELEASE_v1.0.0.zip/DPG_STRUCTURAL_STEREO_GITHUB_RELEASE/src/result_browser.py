"""V7.1 read-only result browser and one-image-per-PDF LaTeX export.

The browser never changes or reruns an existing stereo result and never reads
GT except already computed post-hoc summary images/statistics.
"""
from __future__ import annotations

import csv
import json
import os
import queue
import re
import threading
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath
from typing import Callable

import numpy as np
import cv2
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from boundary_matching import BoundaryMatches
from native_observation import canonical_seam_mask, DOMAINS
from world_render import source_geometry

BLUE = np.array([35,110,255], np.uint8)
RED = np.array([255,55,65], np.uint8)
GREEN = np.array([20,235,80], np.uint8)
METHODS = ('dpg', 'felzenszwalb', 'slic', 'disparity')
TITLES = {'dpg':'DPG (L / VC / CC)',
          'felzenszwalb':'Felzenszwalb',
          'slic':'SLIC',
          'disparity':'Disparity / SGBM'}
VIEWS = ('Midpoint', 'Midpoint + boundaries', 'Left RGB + boundaries',
         'Right RGB + boundaries', 'Left-camera overlay (B/G/R)', 'GT error map', 'Visibility')
FRAME_RX = re.compile(r'^frame_(\d+)$')
FRAME_FILE_RX = re.compile(r'^frame_(\d+)\.png$')


def _safe(s: str) -> str:
    s=re.sub(r'[^0-9A-Za-z_.-]+','_',str(s)).strip('._')
    return s or 'dataset'


def _dataset_tag(raw: str) -> str:
    raw=str(raw or 'dataset').rstrip('/\\')
    if '\\' in raw or re.match(r'^[A-Za-z]:',raw):
        raw=PureWindowsPath(raw).name
    else:
        raw=Path(raw).name
    if raw.lower().endswith('.zip'): raw=raw[:-4]
    return _safe(raw)


def _read_json(path: Path) -> dict:
    try:
        with path.open('r',encoding='utf8') as f: return json.load(f)
    except (OSError, json.JSONDecodeError):return {}


def _walk_named(root: Path, name: str):
    for folder, dirs, files in os.walk(root):
        dirs[:]=[d for d in dirs if d not in ('__pycache__','.git','_hypotheses','GT_EVALUATION','diagnostics')]
        if name in files:
            yield Path(folder)/name


def scan_results(folder: str|Path) -> dict[tuple[str,int],dict[str,Path]]:
    """Index existing outputs. Keep latest result per dataset, frame and method."""
    root=Path(folder).resolve()
    if not root.is_dir():raise NotADirectoryError(root)
    result={}
    times={}
    for report_file in _walk_named(root,'REPORT.json'):
        rep=_read_json(report_file)
        if 'frame' not in rep:continue
        try:frame=int(rep['frame'])
        except (TypeError,ValueError):continue
        method=str(rep.get('segmentation_method','dpg')).lower()
        if method not in METHODS[:-1]:continue
        out=report_file.parent
        if not (out/'midpoint.png').is_file():continue
        key=(_dataset_tag(rep.get('dataset') or out.parent.name),frame)
        stamp=report_file.stat().st_mtime
        item=(key,method)
        if stamp>=times.get(item,float('-inf')):
            result.setdefault(key,{})[method]=out
            times[item]=stamp
    for batch_report in _walk_named(root,'BATCH_REPORT.json'):
        rep=_read_json(batch_report)
        directory=batch_report.parent
        tag=_dataset_tag(rep.get('dataset') or directory.name)
        for path in directory.glob('frame_*.png'):
            match=FRAME_FILE_RX.match(path.name)
            if match is None:continue
            frame=int(match.group(1))
            key=(tag,frame);stamp=path.stat().st_mtime
            item=(key,'disparity')
            if stamp>=times.get(item,float('-inf')):
                result.setdefault(key,{})['disparity']=path
                times[item]=stamp
    # Compact batch output retains only PDF images, a CSV and JOB.json.
    # Those jobs should remain browsable after their solver caches are removed.
    for job_file in _walk_named(root,'JOB.json'):
        job=_read_json(job_file)
        if job.get('mode')!='all_range':
            continue
        tag=_dataset_tag(job.get('dataset_name') or job.get('dataset') or job_file.parent.name)
        for frame_str in job.get('completed',[]):
            try: frame=int(frame_str)
            except (ValueError,TypeError): continue
            frame_dir=job_file.parent/'frames'/f'frame_{frame:06d}'
            for method in METHODS[:-1]:
                source=frame_dir/f'{method}__midpoint.pdf'
                if not source.is_file():continue
                key=(tag,frame)
                item=(key,method)
                stamp=source.stat().st_mtime
                if stamp>=times.get(item,float('-inf')):
                    result.setdefault(key,{})[method]=source
                    times[item]=stamp
    return dict(sorted(result.items()))


def _edge_one_pixel(labels:np.ndarray)->np.ndarray:
    out=np.zeros(labels.shape,bool)
    out[:,1:] |= labels[:,1:]!=labels[:,:-1]
    out[1:,:] |= labels[1:,:]!=labels[:-1,:]
    return out


def _rgb_file(path:Path)->Image.Image:
    with Image.open(path) as im: return im.convert('RGB')


def _pdf_rgb(path:Path)->Image.Image:
    """Render an existing one-page PDF for GUI preview only (not re-export)."""
    import pypdfium2 as pdfium
    pdf=pdfium.PdfDocument(str(path))
    try:
        page=pdf[0]
        bitmap=page.render(scale=1)
        return bitmap.to_pil().convert('RGB')
    finally:
        pdf.close()


def _npz_masks(folder: Path, prefix: str)->dict[str,np.ndarray]:
    path=folder/prefix
    if not path.is_file():return {}
    with np.load(path, allow_pickle=False) as data:
        return {k:data[k].copy() for k in data.files}


def _contour_rgb(folder:Path, side:str) ->Image.Image|None:
    source=folder/f'{side}.png'
    if not source.is_file():return None
    rgb=np.asarray(_rgb_file(source)).copy()
    labels=_npz_masks(folder,'dpg_labels.npz')
    active=np.zeros(rgb.shape[:2],bool)
    for dom in ('L','VC','CC'):
        key=f'{side}_{dom}'
        if key in labels and np.max(labels[key])>0:
            active|=_edge_one_pixel(labels[key])
    rgb[active]=(BLUE if side=='left' else RED)
    return Image.fromarray(rgb)


def _midpoint_overlay(folder:Path)->Image.Image|None:
    filename=folder/'midpoint.png'
    if not filename.is_file():return None
    rgb=np.asarray(_rgb_file(filename)).copy()
    masks=_npz_masks(folder,'midpoint_boundaries.npz')
    left=np.zeros(rgb.shape[:2],bool);right=left.copy();common=left.copy()
    for dom in ('L','VC','CC'):
        for typ,dest in (('left',left),('right',right),('common',common)):
            k=f'{dom}_{typ}'
            if k in masks:dest|=np.asarray(masks[k],bool)
    rgb[left&~common]=BLUE
    rgb[right&~common]=RED
    rgb[common]=GREEN
    return Image.fromarray(rgb)




def _domain_keys(labels: dict[str,np.ndarray]) -> list[str]:
    doms=[]
    for k in labels.keys():
        if not k.startswith('left_') or k.endswith('_class'):
            continue
        dom=k.split('_',1)[1]
        if dom not in doms:
            doms.append(dom)
    return doms


def _load_left_coord_overlay(folder: Path) -> Image.Image|None:
    left_file=folder/'left.png'
    labels_file=folder/'dpg_labels.npz'
    world_file=folder/'world.npz'
    matches_file=folder/'boundary_matches.npz'
    if not (left_file.is_file() and labels_file.is_file() and world_file.is_file() and matches_file.is_file()):
        return None
    rgb=np.asarray(_rgb_file(left_file)).copy()
    h,w=rgb.shape[:2]
    labels=_npz_masks(folder,'dpg_labels.npz')
    matches=BoundaryMatches.load(matches_file)
    with np.load(world_file,allow_pickle=False) as z:
        planes=z['planes'].copy()
        left_plane=z['left_plane'].copy()
        right_plane=z['right_plane'].copy()
        sample_plane=z['sample_plane'].copy()
        focal=float(z['focal'])
        cx=float(z['cx'])
        cy=float(z['cy'])
        baseline=float(z['baseline'])
    surface_ids=None
    sid_file=folder/'surface_identity.npz'
    if sid_file.is_file():
        with np.load(sid_file,allow_pickle=False) as z:
            surface_ids={
                'left':z['left_surface_id'].copy(),
                'right':z['right_surface_id'].copy(),
            }
    geom_right=source_geometry(right_plane, planes, focal, cx, cy, baseline, 'right')
    midx_r, yy_r, z_r, valid_r = geom_right
    with np.errstate(divide='ignore',invalid='ignore'):
        leftx_from_right = midx_r + (0.5*focal*baseline)/z_r
    left_only=np.zeros((h,w),bool)
    right_only=np.zeros((h,w),bool)
    common=np.zeros((h,w),bool)
    ids=np.asarray(sample_plane,np.int32)
    kind=getattr(matches,'kind',None)
    if kind is None:
        kind=np.zeros(len(matches.left_xy),np.uint8)
    is_pair=(ids>=0)&(kind==0)&(matches.confidence>=.30)
    if surface_ids is not None and len(matches.left_xy):
        xleft=np.clip(np.rint(matches.left_xy[:,0]).astype(np.int32),0,w-1)
        yleft=np.clip(np.rint(matches.left_xy[:,1]).astype(np.int32),0,h-1)
        xright=np.clip(np.rint(matches.right_xy[:,0]).astype(np.int32),0,w-1)
        yright=np.clip(np.rint(matches.right_xy[:,1]).astype(np.int32),0,h-1)
        is_pair &= (surface_ids['left'][yleft,xleft]==surface_ids['right'][yright,xright])
    paired_by_domain={}
    dom_names=_domain_keys(labels)
    dom_index={name:i for i,name in enumerate(DOMAINS)}
    for dom in dom_names:
        good=is_pair & (matches.domain==dom_index.get(dom,0))
        paired={}
        if np.any(good):
            for side,xy in (('left',matches.left_xy),('right',matches.right_xy)):
                at=np.zeros((h,w),np.uint8)
                pts=xy[good]
                if len(pts):
                    x=np.clip(np.rint(pts[:,0]).astype(np.int32),0,w-1)
                    y=np.clip(np.rint(pts[:,1]).astype(np.int32),0,h-1)
                    at[y,x]=1
                paired[side]=cv2.dilate(at,np.ones((3,3),np.uint8))>0
                if side=='left' and len(pts):
                    common[y,x]=True
        paired_by_domain[dom]=paired
    for dom in dom_names:
        lkey=f'left_{dom}'
        rkey=f'right_{dom}'
        if lkey in labels:
            edge=canonical_seam_mask(labels[lkey])
            if 'left' in paired_by_domain.get(dom,{}):
                edge &= ~paired_by_domain[dom]['left']
            left_only |= edge
        if rkey in labels:
            edge=canonical_seam_mask(labels[rkey])
            if 'right' in paired_by_domain.get(dom,{}):
                edge &= ~paired_by_domain[dom]['right']
            mask=edge & valid_r & np.isfinite(leftx_from_right) & (leftx_from_right>=0) & (leftx_from_right<w)
            xi=np.clip(np.rint(leftx_from_right[mask]).astype(np.int32),0,w-1)
            yi=yy_r[mask].astype(np.int32)
            right_only[yi,xi]=True
    rgb[left_only & ~common]=BLUE
    rgb[right_only & ~common]=RED
    rgb[common]=GREEN
    return Image.fromarray(rgb)

def _gt_error_image(folder:Path)->Image.Image|None:
    for name in ('GT_SEGMENT_error_right.png','GT_DPG_error_right.png'):
        fn=folder/'GT_EVALUATION'/name
        if fn.is_file():return _rgb_file(fn)
    return None


def _vis_image(folder:Path)->Image.Image|None:
    path=folder/'midpoint_visibility.npy'
    if path.is_file():
        z=np.load(path,allow_pickle=False)
        palette=np.array([[24,28,34],[35,110,255],[255,55,65],[20,235,80]],np.uint8)
        return Image.fromarray(palette[np.clip(z,0,3)])
    return None


def image_for(method: str, item: Path, view: str) ->Image.Image|None:
    """Compute one full-resolution visualization, never a screenshot of GUI."""
    if method=='disparity':
        if view in ('Midpoint','Midpoint + boundaries'):
            return _rgb_file(item)
        if view=='Visibility':
            fn=item.parent/'diagnostics'/f'{item.stem}_visibility.png'
            return _rgb_file(fn) if fn.is_file() else None
        return None
    if item.is_file() and item.suffix.lower()=='.pdf':
        # A compact frame-range job retains PDFs instead of heavy arrays.
        if view=='Midpoint':
            return _pdf_rgb(item)
        if view=='Midpoint + boundaries':
            other=item.with_name(f'{method}__midpoint_boundaries.pdf')
            return _pdf_rgb(other) if other.is_file() else None
        return None
    folder=item
    if view=='Midpoint':
        fn=folder/'midpoint.png'
        return _rgb_file(fn) if fn.is_file() else None
    if view=='Midpoint + boundaries':return _midpoint_overlay(folder)
    if view=='Left RGB + boundaries':return _contour_rgb(folder,'left')
    if view=='Right RGB + boundaries':return _contour_rgb(folder,'right')
    if view=='Left-camera overlay (B/G/R)':return _load_left_coord_overlay(folder)
    if view=='GT error map':return _gt_error_image(folder)
    if view=='Visibility':return _vis_image(folder)
    return None


def gt_summary(method:str,item:Path)->str:
    if method=='disparity':return 'GT comparison unavailable for disparity-only preview'
    if item.is_file() and item.suffix.lower()=='.pdf':
        return 'Compact PDF-only result'
    for filename in ('GT_SEGMENT_REPORT.json','GT_DPG_REPORT.json'):
        path=item/'GT_EVALUATION'/filename
        if path.is_file():
            r=_read_json(path);t=r.get('total',{})
            return ('GT: n={n}, MAE={mae} px, mediaani={med} px, p90={p90} px, '
                    'coverage={cover} %').format(
                n=t.get('n','-'),mae=t.get('mae_px','-'),med=t.get('median_px','-'),
                p90=t.get('p90_px','-'),cover=r.get('GT_coverage_pct','-'))
    return 'GT has not been measured'


def write_single_image_pdf(image:Image.Image, target:Path):
    """One image, one page, native pixel shape, lossless PDF image encoding.

    1 image pixel = 1 PDF point. This is intentional; LaTeX scales the page
    via includegraphics[width=...], preserving the original sample array.
    """
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader
    image=image.convert('RGB')
    w,h=image.size
    target=Path(target)
    target.parent.mkdir(parents=True,exist_ok=True)
    tmp=target.with_suffix('.tmp.pdf')
    doc=canvas.Canvas(str(tmp),pagesize=(w,h),pageCompression=1)
    doc.setTitle(target.stem)
    doc.drawImage(ImageReader(image),0,0,width=w,height=h,mask=None)
    doc.showPage();doc.save()
    os.replace(tmp,target)
    return target


def _export_images_for_frame(record:dict[str,Path], include_details:bool=True):
    """Unique images for one frame, each to be written to a SEPARATE PDF."""
    images=[]
    found_source=None
    for method in METHODS[:-1]:
        if method in record:
            found_source=record[method]
            break
    if found_source is not None:
        for side in ('left','right'):
            fn=found_source/f'{side}.png'
            if fn.is_file():images.append(('original',f'{side}_rgb',lambda f=fn:_rgb_file(f)))
    for method in METHODS:
        if method not in record:continue
        item=record[method]
        if method=='disparity':
            images.append((method,'midpoint',lambda f=item:_rgb_file(f)))
            visibility=item.parent/'diagnostics'/f'{item.stem}_visibility.png'
            if include_details and visibility.is_file():
                images.append((method,'visibility',lambda f=visibility:_rgb_file(f)))
        else:
            images.append((method,'midpoint',lambda f=item:_rgb_file(f/'midpoint.png')))
            if include_details:
                images.append((method,'midpoint_boundaries',lambda f=item:_midpoint_overlay(f)))
                images.append((method,'left_segments',lambda f=item:_contour_rgb(f,'left')))
                images.append((method,'right_segments',lambda f=item:_contour_rgb(f,'right')))
                if _load_left_coord_overlay(item) is not None:
                    images.append((method,'left_coordinate_boundaries',lambda f=item:_load_left_coord_overlay(f)))
                if _gt_error_image(item) is not None:
                    images.append((method,'gt_error',lambda f=item:_gt_error_image(f)))
                if (item/'midpoint_visibility.npy').is_file():
                    images.append((method,'visibility',lambda f=item:_vis_image(f)))
    return images


def export_frame(record:dict[str,Path], dataset:str,frame:int,output_root:Path,
                 *,include_details=True,stop_requested:Callable[[],bool]=lambda:False,
                 progress:Callable[[str],None]=lambda _:None)->list[Path]:
    output_root=Path(output_root)
    target_dir=output_root/_safe(dataset)
    results=[]
    # A previous compact run has only PDFs: copy the original documents
    # directly instead of regenerating or rasterizing any image.
    if record and all(Path(p).suffix.lower()=='.pdf' for p in record.values()):
        import shutil
        target_dir.mkdir(parents=True,exist_ok=True)
        for method,item in record.items():
            for kind in (('midpoint','midpoint_boundaries') if include_details else ('midpoint',)):
                src=Path(item).with_name(f'{method}__{kind}.pdf')
                if not src.is_file(): continue
                dst=target_dir/f'{_safe(dataset)}__frame_{int(frame):06d}__{method}__{kind}.pdf'
                if src.resolve()!=dst.resolve():
                    shutil.copy2(src,dst)
                results.append(dst)
                progress(f'PDF: {dst.name}')
        return results
    for method,kind,build in _export_images_for_frame(record,include_details):
        if stop_requested():break
        picture=build()
        if picture is None:continue
        filename=f'{_safe(dataset)}__frame_{frame:06d}__{method}__{kind}.pdf'
        path=write_single_image_pdf(picture,target_dir/filename)
        results.append(path)
        progress(f'PDF: {path.name} ({picture.size[0]}x{picture.size[1]})')
    return results


def _report_for_method(item: Path) -> dict:
    if item is None or not Path(item).is_dir():
        return {}
    return _read_json(Path(item)/'REPORT.json')


def segment_count_for_method(method:str,item:Path)->int|None:
    if item is None or not Path(item).exists() or method=='disparity':
        return None
    rep=_report_for_method(item)
    counts=rep.get('dpg_elements',{}) or {}
    if method=='dpg':
        total=0
        for side in ('left','right'):
            for dom in ('L','VC','CC'):
                v=counts.get(f'{side}_{dom}')
                if v is not None:
                    total+=max(int(v)-1,0)
        return total or None
    total=0
    for side in ('left','right'):
        v=counts.get(f'{side}_L')
        if v is not None:
            total+=max(int(v)-1,0)
    return total or None


def metrics_for_method(method:str,item:Path)->dict:
    out={
        'segment_count':segment_count_for_method(method,item),
        'elapsed_seconds':None,'segmentation_and_input_seconds':None,
        'stereo_boundary_matching_seconds':None,'joint_geometry_seconds':None,
        'world_atlas_render_and_diagnostics_seconds':None,
        'evaluated_pixels':None,'mae_px':None,'median_px':None,'p90_px':None,
        'within_1px_pct':None,'within_2px_pct':None,'within_3px_pct':None,
        'GT_coverage_pct':None,'elements_evaluated':None,'pair_extrapolations_evaluated':None,
        'pair_extrap_pairs_with_GT':None,'pair_extrap_weighted_samples':None,
        'pair_extrap_weighted_mae_px':None,'pair_extrap_within_1px_pct':None,
        'boundary_gt_observable_pct':None,'boundary_checked_pct':None,
        'boundary_checked_pixels':None,'boundary_symmetric_mae_px':None,
        'boundary_source_indexed_mae_px':None,'boundary_f1_1px_pct':None,
        'boundary_f1_2px_pct':None,'boundary_f1_3px_pct':None,
        'GT_pair_checked_pct':None,'GT_pair_consistent_3px_pct':None,
        'GT_pair_error_mae_px':None,
        'gt_status':'missing','gt_name':None,
    }
    if method=='disparity' or item is None or not Path(item).is_dir():
        return out
    rep=_report_for_method(item)
    timing=rep.get('stage_times_seconds',{})
    out['elapsed_seconds']=rep.get('elapsed_seconds')
    for key in ('segmentation_and_input_seconds','stereo_boundary_matching_seconds',
                'joint_geometry_seconds','world_atlas_render_and_diagnostics_seconds'):
        out[key]=timing.get(key)
    report=None
    for filename in ('GT_SEGMENT_REPORT.json','GT_DPG_REPORT.json'):
        p=Path(item)/'GT_EVALUATION'/filename
        if p.is_file():
            report=_read_json(p)
            break
    if report is None:
        status=_read_json(Path(item)/'GT_AUTO_STATUS.json')
        out['gt_status']=str(status.get('reason','missing')) if status else 'missing'
        return out
    total=report.get('total',{}) or {}
    pairs=report.get('pair_extrapolation_summary',{}) or {}
    boundary=report.get('gt_boundary',{}) or {}
    out.update({
        'boundary_gt_observable_pct':boundary.get('GT_observable_boundary_pct'),
        'boundary_checked_pct':boundary.get('measured_boundary_pct'),
        'boundary_checked_pixels':boundary.get('checked_boundary_pixels'),
        'boundary_symmetric_mae_px':boundary.get('symmetric_boundary_mae_px'),
        'boundary_source_indexed_mae_px':boundary.get('source_indexed_error',{}).get('mae_px'),
        'boundary_f1_1px_pct':boundary.get('boundary_f1_1px_pct'),
        'boundary_f1_2px_pct':boundary.get('boundary_f1_2px_pct'),
        'boundary_f1_3px_pct':boundary.get('boundary_f1_3px_pct'),
        'GT_pair_checked_pct':boundary.get('GT_checked_pair_pct'),
        'GT_pair_consistent_3px_pct':boundary.get('GT_consistent_pair_pct'),
        'GT_pair_error_mae_px':boundary.get('GT_pair_error_mae_px'),
        'evaluated_pixels': total.get('n'),
        'mae_px': total.get('mae_px'),
        'median_px': total.get('median_px'),
        'p90_px': total.get('p90_px'),
        'within_1px_pct': total.get('within_1px_pct'),
        'within_2px_pct': total.get('within_2px_pct'),
        'within_3px_pct': total.get('within_3px_pct'),
        'GT_coverage_pct': report.get('GT_coverage_pct'),
        'elements_evaluated': report.get('elements_evaluated'),
        'pair_extrapolations_evaluated': report.get('pair_extrapolations_evaluated'),
        'pair_extrap_pairs_with_GT':pairs.get('pairs_with_GT'),
        'pair_extrap_weighted_samples':pairs.get('weighted_sample_count'),
        'pair_extrap_weighted_mae_px':pairs.get('weighted_mae_px'),
        'pair_extrap_within_1px_pct':pairs.get('weighted_within_1px_pct'),
        'gt_status':'OK' if total.get('n',0)>0 else 'NO_VALID_GT_PIXELS',
        'gt_name':report.get('gt_name'),
    })
    return out


def export_compact_frame(record:dict[str,Path], dataset:str, frame:int, output_root:Path,
                         *, stop_requested:Callable[[],bool]=lambda:False,
                         progress:Callable[[str],None]=lambda _:None)->list[Path]:
    """Write exactly 2 PDFs per method: clean midpoint + midpoint boundary overlay.

    Files go under output_root/frame_XXXXXX/. This is intended for the low-storage
    3-segmentation frame-range run.
    """
    output_root=Path(output_root)
    frame_dir=output_root/f'frame_{int(frame):06d}'
    frame_dir.mkdir(parents=True,exist_ok=True)
    results=[]
    for method in ('dpg','felzenszwalb','slic'):
        if method not in record:
            continue
        item=record[method]
        tasks=(('midpoint',lambda m=method,p=item:image_for(m,p,'Midpoint')),
               ('midpoint_boundaries',lambda m=method,p=item:image_for(m,p,'Midpoint + boundaries')))
        for kind,build in tasks:
            if stop_requested():
                break
            pic=build()
            if pic is None:
                continue
            path=write_single_image_pdf(pic, frame_dir/f'{method}__{kind}.pdf')
            results.append(path)
            progress(f'PDF: frame {frame} {method} {kind}')
    return results



def export_left_coordinate_boundary_frame(record:dict[str,Path], dataset:str, frame:int, output_root:Path,
                                         *, stop_requested:Callable[[],bool]=lambda:False,
                                         progress:Callable[[str],None]=lambda _:None)->list[Path]:
    """Write one PDF per method: left-camera RGB with L/G/R boundary overlay."""
    output_root=Path(output_root)
    target_dir=output_root/_safe(dataset)
    results=[]
    for method in ('dpg','felzenszwalb','slic'):
        if method not in record:
            continue
        if stop_requested():
            break
        pic=_load_left_coord_overlay(record[method])
        if pic is None:
            continue
        filename=f'{_safe(dataset)}__frame_{int(frame):06d}__{method}__left_coordinate_boundaries.pdf'
        path=write_single_image_pdf(pic,target_dir/filename)
        results.append(path)
        progress(f'PDF: {path.name} ({pic.size[0]}x{pic.size[1]})')
    return results


class _PicturePane(ttk.Frame):
    def __init__(self,parent,method:str):
        super().__init__(parent)
        self.method=method
        self.info=ttk.Label(self,text=TITLES[method],anchor='center')
        self.info.pack(fill='x')
        self.canvas=tk.Canvas(self,background='#15191e',highlightthickness=0)
        self.canvas.pack(fill='both',expand=True)
        self._img=None;self._photo=None
        self._scale=0.;self._pan=np.array([0.,0.])
        self._last=(0,0)
        self.canvas.bind('<Configure>',lambda _:self.draw())
        self.canvas.bind('<MouseWheel>',self.wheel)
        self.canvas.bind('<Button-4>',lambda e:self.wheel(e,1))
        self.canvas.bind('<Button-5>',lambda e:self.wheel(e,-1))
        self.canvas.bind('<ButtonPress-1>',lambda e:setattr(self,'_last',(e.x,e.y)))
        self.canvas.bind('<B1-Motion>',self.drag)
    def set_picture(self,image:Image.Image|None,gt:str=''):
        self._img=image
        self._scale=0.;self._pan[:]=0
        self.info.configure(text=TITLES[self.method]+ (' | '+gt if gt else ''))
        self.draw()
    def draw(self):
        cv=self.canvas;cv.delete('all')
        image=self._img
        if image is None:
            cv.create_text(max(10,cv.winfo_width()//2),max(10,cv.winfo_height()//2),
                           text='No result for the selected frame / view',fill='#c7cbd1')
            return
        iw,ih=image.size;cw=max(1,cv.winfo_width());ch=max(1,cv.winfo_height())
        if self._scale==0.:
            self._scale=max(.01,min(cw/iw,ch/ih))
            self._pan[:]=((cw-iw*self._scale)*.5,(ch-ih*self._scale)*.5)
        scale=float(np.clip(self._scale,.05,30.))
        xa=max(0,int(np.floor(-self._pan[0]/scale))-2)
        ya=max(0,int(np.floor(-self._pan[1]/scale))-2)
        xb=min(iw,int(np.ceil((cw-self._pan[0])/scale))+2)
        yb=min(ih,int(np.ceil((ch-self._pan[1])/scale))+2)
        if xa>=xb or ya>=yb:return
        crop=image.crop((xa,ya,xb,yb))
        w=max(1,int(round((xb-xa)*scale)))
        h=max(1,int(round((yb-ya)*scale)))
        method=Image.Resampling.NEAREST if scale>=1 else Image.Resampling.BILINEAR
        self._photo=ImageTk.PhotoImage(crop.resize((w,h),method))
        cv.create_image(int(round(self._pan[0]+xa*scale)),int(round(self._pan[1]+ya*scale)),
                        anchor='nw',image=self._photo)
    def wheel(self,event,force=None):
        if self._img is None:return
        direction=force if force is not None else (1 if event.delta>0 else -1)
        factor=1.2 if direction>0 else (1/1.2)
        old=max(.05,self._scale)
        new=float(np.clip(old*factor,.05,30.))
        cursor=np.array([event.x,event.y],np.float64)
        xy=(cursor-self._pan)/old
        self._pan=cursor-xy*new;self._scale=new
        self.draw()
    def drag(self,event):
        dx=event.x-self._last[0];dy=event.y-self._last[1]
        self._last=(event.x,event.y)
        self._pan+=np.array([dx,dy])
        self.draw()


class ResultBrowser:
    """Standalone Tk Toplevel for comparing result images and exporting PDFs."""
    def __init__(self,parent,initial_folder:Path|str|None=None):
        self.win=tk.Toplevel(parent)
        self.win.title('Structural Stereo - Result browser and PDF exports')
        self.win.geometry('1510x960')
        self.root_folder=tk.StringVar(value=str(initial_folder or Path.cwd()/'results'))
        self.dataset=tk.StringVar(value='')
        self.view=tk.StringVar(value='Midpoint')
        self.include_details=tk.BooleanVar(value=True)
        self.index={};self._keys=[];self._current=None
        self._events=queue.Queue();self._cancel=threading.Event();self._job=False
        line=ttk.Frame(self.win,padding=5);line.pack(fill='x')
        ttk.Label(line,text='Results directory').pack(side='left')
        ttk.Entry(line,textvariable=self.root_folder,width=60).pack(side='left',padx=5,fill='x',expand=True)
        ttk.Button(line,text='Choose folder',command=self.browse_root).pack(side='left',padx=3)
        ttk.Button(line,text='Scan results',command=self.scan).pack(side='left',padx=3)
        line2=ttk.Frame(self.win,padding=5);line2.pack(fill='x')
        ttk.Label(line2,text='Dataset').pack(side='left')
        self.dataset_combo=ttk.Combobox(line2,textvariable=self.dataset,values=[],width=28,state='readonly')
        self.dataset_combo.pack(side='left',padx=4)
        self.dataset_combo.bind('<<ComboboxSelected>>',lambda _:self.update_list())
        ttk.Label(line2,text='View').pack(side='left',padx=(13,2))
        combo=ttk.Combobox(line2,textvariable=self.view,values=VIEWS,width=23,state='readonly')
        combo.pack(side='left',padx=4)
        combo.bind('<<ComboboxSelected>>',lambda _:self.update_pictures())
        ttk.Button(line2,text='Previous',command=lambda:self.step(-1)).pack(side='left',padx=5)
        ttk.Button(line2,text='Next',command=lambda:self.step(1)).pack(side='left',padx=5)
        ttk.Checkbutton(line2,text='Include boundaries and GT diagnostics',variable=self.include_details).pack(side='left',padx=13)
        buttons=ttk.Frame(self.win,padding=5);buttons.pack(fill='x')
        self.export_one=ttk.Button(buttons,text='Export selected frame to PDFs',command=lambda:self.export(all_frames=False))
        self.export_one.pack(side='left',padx=3)
        self.export_all=ttk.Button(buttons,text='Export all frames to PDFs',command=lambda:self.export(all_frames=True))
        self.export_all.pack(side='left',padx=3)
        ttk.Button(buttons,text='Stop PDF export',command=self.stop_export).pack(side='left',padx=3)
        self.status=tk.StringVar(value='Choose a results directory and select Scan results.')
        ttk.Label(buttons,textvariable=self.status).pack(side='left',padx=12,fill='x',expand=True)
        content=ttk.Panedwindow(self.win,orient='horizontal');content.pack(fill='both',expand=True)
        left=ttk.Frame(content,width=160)
        content.add(left,weight=1)
        ttk.Label(left,text='Frames').pack(anchor='w',padx=4)
        lbframe=ttk.Frame(left);lbframe.pack(fill='both',expand=True)
        self.frame_list=tk.Listbox(lbframe,exportselection=False,width=14)
        self.frame_list.pack(side='left',fill='both',expand=True)
        scrollbar=ttk.Scrollbar(lbframe,orient='vertical',command=self.frame_list.yview)
        scrollbar.pack(side='right',fill='y')
        self.frame_list.configure(yscrollcommand=scrollbar.set)
        self.frame_list.bind('<<ListboxSelect>>',lambda _:self.update_pictures())
        right=ttk.Frame(content)
        content.add(right,weight=8)
        right.rowconfigure(0,weight=1);right.rowconfigure(1,weight=1)
        right.columnconfigure(0,weight=1);right.columnconfigure(1,weight=1)
        self.panes={}
        for i,method in enumerate(METHODS):
            pane=_PicturePane(right,method)
            pane.grid(row=i//2,column=i%2,sticky='nsew',padx=3,pady=3)
            self.panes[method]=pane
        self.win.after(100,self.poll)
        if initial_folder and Path(initial_folder).is_dir(): self.scan()

    def browse_root(self):
        p=filedialog.askdirectory(parent=self.win, title='Choose results directory',
                                  initialdir=self.root_folder.get())
        if p:
            self.root_folder.set(p)
            self.scan()

    def scan(self):
        if self._job:
            messagebox.showinfo('Result browser','A scan or export is still running.',parent=self.win)
            return
        root=self.root_folder.get().strip(' "')
        if not Path(root).is_dir():
            messagebox.showerror('Folder missing','Choose an existing results directory.',parent=self.win)
            return
        self._job=True;self.status.set('Scanning result subdirectories ...')
        def work():
            try:self._events.put(('scan_done',scan_results(root)))
            except Exception as exc:self._events.put(('error',str(exc)))
        threading.Thread(target=work,daemon=True).start()

    def update_list(self):
        ds=self.dataset.get();self._keys=[key for key in self.index if key[0]==ds]
        self.frame_list.delete(0,'end')
        for _,frame in self._keys:self.frame_list.insert('end',f'{frame:06d}')
        if self._keys:
            self.frame_list.selection_set(0);self.frame_list.see(0)
        self.update_pictures()

    def _selected(self):
        sels=self.frame_list.curselection()
        if not sels or sels[0]>=len(self._keys):return None
        return self._keys[sels[0]]

    def step(self,direction:int):
        if not self._keys:return
        s=self.frame_list.curselection()
        pos=s[0] if s else 0
        pos=max(0,min(len(self._keys)-1,pos+direction))
        self.frame_list.selection_clear(0,'end')
        self.frame_list.selection_set(pos);self.frame_list.see(pos)
        self.update_pictures()

    def update_pictures(self):
        key=self._selected()
        self._current=key
        if key is None:
            for pane in self.panes.values():pane.set_picture(None)
            return
        record=self.index[key]
        mode=self.view.get()
        for method,pane in self.panes.items():
            try:
                photo=image_for(method,record[method],mode) if method in record else None
                gt=gt_summary(method,record[method]) if method in record else ''
                pane.set_picture(photo,gt)
            except Exception as exc:
                pane.set_picture(None)
                self.status.set(f'{method}: could not open image: {exc}')
        self.status.set(f'{key[0]} | frame {key[1]} | methods {len(record)} / 4')

    def export(self,all_frames:bool):
        if self._job:return
        keys=self._keys if all_frames else ([self._selected()] if self._selected() else [])
        keys=[k for k in keys if k is not None]
        if not keys:return
        dest=filedialog.askdirectory(parent=self.win,title='Choose PDF export directory')
        if not dest:return
        self._cancel.clear();self._job=True
        self.export_one.configure(state='disabled');self.export_all.configure(state='disabled')
        self.status.set(f'Exporting {len(keys)} frames to individual PDF files ...')
        include=self.include_details.get()
        records=[(ds,frame,self.index[(ds,frame)].copy()) for ds,frame in keys]
        def work():
            all_paths=[];errors=[]
            try:
                for i,(ds,frame,rec) in enumerate(records):
                    if self._cancel.is_set():break
                    try:
                        all_paths.extend(export_frame(rec,ds,frame,Path(dest),include_details=include,
                            stop_requested=self._cancel.is_set,
                            progress=lambda msg,ix=i:self._events.put(('progress',f'{ix+1}/{len(records)}: {msg}'))))
                    except Exception as exc:errors.append(f'{ds} frame {frame}: {exc}')
                index_path=Path(dest)/'PDF_INDEX.csv'
                if all_paths:
                    with index_path.open('w',encoding='utf-8-sig',newline='') as f:
                        w=csv.writer(f);w.writerow(('pdf_path','latex_includegraphics'))
                        for path in all_paths:
                            rel=path.relative_to(Path(dest)).as_posix()
                            w.writerow((rel,r'\includegraphics[width=\linewidth]{'+rel+'}'))
                self._events.put(('export_done',(len(all_paths),len(records),str(dest),errors,self._cancel.is_set())))
            except Exception as exc:self._events.put(('error',str(exc)))
        threading.Thread(target=work,daemon=True).start()

    def stop_export(self):
        self._cancel.set()
        self.status.set('Stopping after the current PDF; completed files are retained.')

    def poll(self):
        try:
            while True:
                event,payload=self._events.get_nowait()
                if event=='progress': self.status.set(payload)
                elif event=='scan_done':
                    self._job=False;self.index=payload
                    datasets=sorted({ds for ds,_ in self.index})
                    self.dataset_combo.configure(values=datasets)
                    if datasets:
                        old=self.dataset.get()
                        self.dataset.set(old if old in datasets else datasets[0])
                    else:self.dataset.set('')
                    self.update_list()
                    self.status.set(f'{len(self.index)} frame-result groups | {len(datasets)} datasets')
                elif event=='export_done':
                    self._job=False
                    self.export_one.configure(state='normal');self.export_all.configure(state='normal')
                    count,total,folder,errors,stopped=payload
                    self.status.set(f'{count} PDF files ({total} frames) | '+
                                    ('stopped' if stopped else 'completed')+f' | {folder}')
                    if errors:messagebox.showwarning('Some PDF exports failed','\n'.join(errors[:10]),parent=self.win)
                elif event=='error':
                    self._job=False
                    self.export_one.configure(state='normal');self.export_all.configure(state='normal')
                    self.status.set('Error: '+payload)
                    messagebox.showerror('Result browser',payload,parent=self.win)
        except queue.Empty:pass
        try:
            if self.win.winfo_exists():self.win.after(100,self.poll)
        except tk.TclError:pass
